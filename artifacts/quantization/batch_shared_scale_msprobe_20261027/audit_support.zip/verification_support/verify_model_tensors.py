"""Independent CPU verification of captured native producer/consumer tensors."""
import argparse
import io
import json
from pathlib import Path, PurePosixPath
import zipfile
import numpy as np
from verify_quant_probe import TensorUnpickler, array, sha


def read_tensor(path):
    with zipfile.ZipFile(path) as archive:
        names=archive.namelist()
        assert len(names)==len(set(names))
        pickles=[n for n in names if n.endswith('/data.pkl')]
        assert len(pickles)==1
        prefix=pickles[0][:-8]
        assert archive.read(prefix+'byteorder')==b'little'
        data=TensorUnpickler(io.BytesIO(archive.read(pickles[0])),archive,prefix).load()
    assert set(data)=={'dtype','shape','raw'}
    return data


def verify(root):
    events=[]
    for path in sorted((root/'operators').glob('pid*.jsonl')):
        events.extend(json.loads(line) for line in path.read_text().splitlines() if line)
    cache={}
    files=set()
    def load(manifest):
        remote=PurePosixPath(manifest['path'])
        parts=remote.parts
        assert 'operators' in parts
        local=root/Path(*parts[parts.index('operators'):])
        assert local.resolve().is_relative_to(root.resolve())
        key=str(local)
        if key not in cache:
            blob=local.read_bytes()
            assert sha(blob)==manifest['file_sha256'],f'File SHA mismatch: {local}'
            tensor=read_tensor(local)
            assert sha(tensor['raw'])==manifest['logical_sha256'],f'Logical SHA mismatch: {local}'
            assert list(tensor['shape'])==manifest['shape']
            assert 'torch.'+tensor['dtype']==manifest['dtype']
            cache[key]=tensor
            files.add(key)
        return cache[key]
    captures={}
    logits={}
    for event in events:
        key=(event.get('generation_id'),event.get('rank'))
        if event['event']=='native_capture':
            stage=event['stage']; ordinal=event.get('ordinal',0)
            skey=(*key,stage,ordinal)
            assert skey not in captures,'Duplicate capture stage/ordinal'
            captures[skey]={name:load(value) for name,value in event['tensors'].items()}
        elif event['event']=='first_logits':
            assert key not in logits
            logits[key]=load(event['tensor'])
    results=[]
    for event in events:
        if event['event']!='native_bound_call':continue
        key=(event['generation_id'],event['rank'])
        binding=event['binding_event']
        assert binding['status']=='COMPLETE' and binding['input_unchanged']
        data=captures[(*key,'pair',0)]
        x,nq,ns,q,s=[array(data[k]) for k in ('input_x','native_q','native_scale','returned_q','returned_scale')]
        assert x.ndim==2 and q.shape==nq.shape==x.shape and ns.shape==s.shape==(x.shape[0],)
        for field,name in (('input_sha256','input_x'),('q_sha256','returned_q'),
                           ('scale_sha256','returned_scale'),('native_q_sha256','native_q'),
                           ('native_scale_sha256','native_scale')):
            assert binding[field]==sha(data[name]['raw'])
        rows=binding['rows']; rid=binding['target_request_id']
        target=[i for i,v in enumerate(rows['request_ids']) if v==rid and rows['valid_rows'][i]]
        assert len(target)==1
        i=target[0]; peers=[j for j in range(x.shape[0]) if j!=i]
        assert np.array_equal(q[peers],nq[peers]) and np.array_equal(s[peers],ns[peers])
        assert len(binding['consumers'])==1,'This verifier expects one selected down_proj consumer'
        for ordinal,consumer in enumerate(binding['consumers']):
            assert consumer['api']=='npu_quant_matmul'
            assert consumer['same_q_object'] and consumer['same_scale_object']
            assert consumer['q_sha256']==sha(data['returned_q']['raw'])
            assert consumer['scale_sha256']==sha(data['returned_scale']['raw'])
            output=captures[(*key,'consumer',ordinal)]['output']
            assert consumer['output_sha256']==sha(output['raw'])
            assert consumer['output_shape']==list(output['shape'])
        assert key in logits and logits[key]['shape'][0]==x.shape[0]
        xf=x.astype(np.float32); nd=nq.astype(np.float32)*ns[:,None]; rd=q.astype(np.float32)*s[:,None]
        expected_native_scale=np.max(np.abs(xf),axis=1)/np.float32(127)
        nonzero=expected_native_scale>0
        assert np.allclose(ns[nonzero],expected_native_scale[nonzero],rtol=1e-6,atol=0), 'Native scale not row-local absmax/127'
        native_mse=float(np.mean((nd[i]-xf[i])**2,dtype=np.float32))
        returned_mse=float(np.mean((rd[i]-xf[i])**2,dtype=np.float32))
        energy=float(np.mean(xf[i]**2,dtype=np.float32))
        metrics={'changed_codes':int(np.count_nonzero(q[i]!=nq[i])),
                 'changed_dequant_values':int(np.count_nonzero(rd[i]!=nd[i])),
                 'native_mse':native_mse,'returned_mse':returned_mse,
                 'native_nmse':native_mse/energy,'returned_nmse':returned_mse/energy,
                 'native_zero_ratio':float(np.mean(nq[i]==0)),
                 'returned_zero_ratio':float(np.mean(q[i]==0)),
                 'native_saturation_ratio':float(np.mean(np.abs(nq[i].astype(np.int16))>=127)),
                 'returned_saturation_ratio':float(np.mean(np.abs(q[i].astype(np.int16))>=127)),
                 'scale_ratio':float(s[i]/ns[i])}
        if 'target_metrics' in binding:
            for name,value in metrics.items():
                assert np.isclose(binding['target_metrics'][name],value,rtol=3e-6,atol=1e-10),name
        mode=binding.get('experiment_mode',event['mode'])
        if mode=='healthy':
            assert data['returned_q']['raw']==data['native_q']['raw']
            assert data['returned_scale']['raw']==data['native_scale']['raw']
        if binding.get('substitution_applied') and mode=='shared':
            maximum=float(np.max(np.abs(xf)))
            assert maximum>float(np.max(np.abs(xf[i])))
            assert np.isclose(s[i],np.float32(maximum/127),rtol=1e-6,atol=0)
            assert binding['artificial_multiplier']==1.0
        row_bytes=len(data['input_x']['raw'])//x.shape[0]
        results.append({'generation_id':key[0],'rank':key[1],'mode':mode,'target_row':i,
                        'rows':x.shape[0],'peer_pair_preserved':True,
                        'native_scale_row_absmax_close':True,
                        'native_scale_row_absmax_max_absdiff':float(np.max(np.abs(ns[nonzero]-expected_native_scale[nonzero]))) if np.any(nonzero) else 0.0,
                        'input_sha256':sha(data['input_x']['raw']),
                        'target_input_sha256':sha(data['input_x']['raw'][i*row_bytes:(i+1)*row_bytes]),
                        'logits_sha256':sha(logits[key]['raw']),**metrics})
    assert results,'No completed captured call'
    return {'status':'PASS','scope':'Independent raw tensor, metrics, hashes and recorded native-consumer consistency; CPU NumPy only',
            'tensor_files':len(files),'bound_rank_calls':len(results),'records':results}


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--run-dir',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();result=verify(args.run_dir)
    with args.output.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k!='records'}))
