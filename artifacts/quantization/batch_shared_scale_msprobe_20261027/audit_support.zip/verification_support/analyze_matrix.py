"""Independent CPU tensor validation and target-row causal matrix analysis.

Run after model_matrix exits, with torch available (CPU only). Recorded paths
are rebased beneath the supplied run root and their byte hashes are verified.
Logits G3 is strictly P0's real row; unrelated batch rows cannot satisfy G3.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
from decimal import Decimal


def objective_score(text,finish_reason,expected):
    """Separate strict requested format from an unambiguous numeric answer.

    Reasoning text is excluded. Ambiguous prose or unfinished output is unknown,
    not a numeric failure. All five frozen cases have integer/vector answers.
    """
    answer=text.rsplit('</think>',1)[-1].strip()
    record={'format_exact':finish_reason=='stop' and answer==expected,
            'objective_answer_correct':None,'numeric_answer':None,'expected':expected,
            'answer_region':answer,'extraction_method':None,'completed':finish_reason=='stop'}
    if finish_reason!='stop' or ('<think>' in text and '</think>' not in text):
        record['extraction_method']='unfinished';return record
    boxed=re.findall(r'\\boxed\{([^{}]*)\}',answer)
    candidate=boxed[-1] if boxed else answer
    numbers=re.findall(r'(?<![\w.])[-+]?\d+(?:\.\d+)?(?!\w)(?!\.\d)',candidate)
    expected_numbers=expected.split(',')
    if len(numbers)!=len(expected_numbers):
        record['extraction_method']='ambiguous_numeric_sequence';return record
    record['extraction_method']='explicit_boxed_answer' if boxed else 'unique_numeric_sequence_in_final_answer'
    record['numeric_answer']=numbers
    record['objective_answer_correct']=[Decimal(x) for x in numbers]==[Decimal(x) for x in expected_numbers]
    return record


FAULT_FIELDS=('case','batch','phase','rank','generation','stage','status','fault_executed',
    'fault_definition','actual_requests','healthy_native_repeat_exact','healthy_input_exact',
    'recovery_exact','fault_repeat_exact','G2','G3_repeatable_target_logits','external_range_increase',
    'scale_ratio','changed_target_codes','changed_target_dequant','target_native_mse','target_returned_mse',
    'target_native_nmse','target_returned_nmse','target_logits_changed','target_logits_max_abs_delta',
    'kl_native_to_fault','target_tokens_changed','first_target_token_difference_zero_based',
    'native_objective_answer_correct','result_objective_answer_correct','input_row_sha256')
SKIP_FIELDS=('case','batch','phase','rank','generation','stage','status','fault_executed','skip_reason',
    'baseline_generation','actual_requests','healthy_input_exact','external_range_increase',
    'target_reference_qualified','candidate_shared_range_ratio','scale_ratio','changed_target_codes',
    'target_native_mse','target_returned_mse','input_row_sha256')


def write_csv(path,rows,columns=()):
    keys=list(columns)
    for row in rows:
        for key in row:
            if key not in keys:keys.append(key)
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader()
        for row in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in row.items()})


def main():
    if sys.flags.optimize:
        raise RuntimeError('Evidence assertions must remain enabled; do not use Python optimization')
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path)
    args=p.parse_args();root=args.run.resolve();out=(args.output or root/'analysis').resolve();out.mkdir(parents=True,exist_ok=True)
    import torch
    torch.set_num_threads(1)
    result=json.loads((root/'result.json').read_text(encoding='utf-8'))
    events=[]
    for path in (root/'operators').glob('pid*.jsonl'):
        events.extend(json.loads(line) for line in path.read_text(encoding='utf-8').splitlines())
    checked={};cache={}
    def load(meta):
        original=meta['path'].replace('\\','/')
        relative=original.split('/operators/',1)[-1]
        if relative==original:raise ValueError('Tensor path has no operators boundary')
        path=(root/'operators'/relative).resolve()
        if not path.is_relative_to(root/'operators'):raise ValueError('Tensor path escapes run')
        key=str(path)
        if key in cache:return cache[key]
        file_sha=hashlib.sha256(path.read_bytes()).hexdigest()
        assert file_sha==meta['file_sha256'],'Tensor file SHA mismatch: '+key
        tensor=torch.load(path,map_location='cpu',weights_only=True).contiguous()
        assert list(tensor.shape)==meta['shape'] and str(tensor.dtype)==meta['dtype']
        logical=hashlib.sha256(tensor.view(torch.uint8).numpy().tobytes()).hexdigest()
        assert logical==meta['logical_sha256'],'Logical tensor SHA mismatch: '+key
        checked[key]={'file_sha256':file_sha,'logical_sha256':logical};cache[key]=tensor
        return tensor
    def same(a,b):return a.dtype==b.dtype and a.shape==b.shape and torch.equal(a.view(torch.uint8),b.view(torch.uint8))
    def sha(t):return hashlib.sha256(t.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()
    def byevent(generation,event):return [e for e in events if e.get('generation_id')==generation and e['event']==event]
    def request(run):return next(x for x in run['requests'] if x['logical_id']==run['target'])
    data={};errors=[];pair_rows=[];fault_rows=[];reference_rows=[];quality_rows=[];skip_rows=[]
    for run in result['runs']:
        generation=run['generation_id'];ranks={}
        if not generation.startswith('screen'):
            reply=request(run)
            score=objective_score(reply['text'],reply['finish_reason'],run['score']['expected'])
            run['independent_quality']=score
            quality_rows.append({'generation':generation,'target':run['target'],'mode':run['mode'],'phase':run.get('phase','full'),**score})
        captures=byevent(generation,'native_capture')
        raw_calls=byevent(generation,'native_bound_call')
        assert len(raw_calls)==2 and {e['rank'] for e in raw_calls}=={0,1}
        assert sorted(raw_calls,key=lambda e:e['rank'])==sorted(run['proof']['calls'],key=lambda e:e['rank']),'Driver proof differs from raw worker evidence'
        for call in raw_calls:
            rank=call['rank'];event=call['binding_event'];scheduler=call['scheduler']
            assert event['status']=='COMPLETE' and event['input_unchanged'] and event['non_target_pair_preserved']
            # Native healthy observation does not require a separate reference
            # to match every peer. Any replaced target must still qualify.
            if run['mode']!='healthy':
                calibration=event.get('target_calibration',event['calibration'])
                assert calibration['q_exact'] and calibration['scale_close']
            assert scheduler['pure_decode'] and scheduler['all_expected_present']
            assert scheduler['logits_indices']==list(range(len(run['logical_ids'])))
            target=scheduler['logical_ids'].index(run['target'])
            assert scheduler['request_ids'][target]==event['target_request_id']
            assert call['logical_mapping'][event['target_request_id']]==run['target']
            for internal_id,prefix in scheduler['prefixes'].items():
                returned=next(v for v in run['requests'] if v['logical_id']==prefix['logical_id'])
                assert returned['prompt_token_ids']==prefix['prompt_tokens']
                assert returned['token_ids'][:len(prefix['output_token_ids'])]==prefix['output_token_ids'], 'Observed generated prefix does not match returned request'
            target_prefix=scheduler['prefixes'][event['target_request_id']]['output_token_ids']
            pairs=[e for e in captures if e['rank']==rank and e['stage']=='pair']
            assert len(pairs)==1 and pairs[0]['ordinal']==0
            t={k:load(v) for k,v in pairs[0]['tensors'].items()}
            x,nq,ns,q,s=(t[k] for k in ('input_x','native_q','native_scale','returned_q','returned_scale'))
            assert x.ndim==2 and x.shape==nq.shape==q.shape and ns.shape==s.shape==(x.shape[0],)
            assert q.dtype==nq.dtype==torch.int8 and ns.dtype==s.dtype==torch.float32
            assert x.shape[0]==len(scheduler['logical_ids']) and torch.isfinite(x.float()).all()
            for key,tensor in [('input_sha256',x),('native_q_sha256',nq),('native_scale_sha256',ns),('q_sha256',q),('scale_sha256',s)]:
                assert sha(tensor)==event[key]
            peer=[i for i in range(x.shape[0]) if i!=target]
            assert same(q[peer],nq[peer]) and same(s[peer],ns[peer]),'Non-target pair changed'
            if 'reference_q' in t:
                all_q_exact=same(nq,t['reference_q'])
                target_q_exact=same(nq[target],t['reference_q'][target])
                target_scale_close=bool(torch.allclose(ns[target],t['reference_scale'][target],rtol=1e-6,atol=0)) if x[target].abs().max()>0 else True
                assert all_q_exact==event['calibration']['q_exact']
                assert target_q_exact==event['target_calibration']['q_exact']
                assert target_scale_close==event['target_calibration']['scale_close']
                assert event['target_calibration']['qualified']==(target_q_exact and target_scale_close)
                if run['mode']!='healthy':assert target_q_exact and target_scale_close
            if run['mode']=='healthy':assert same(q,nq) and same(s,ns)
            consumers=[e for e in captures if e['rank']==rank and e['stage']=='consumer']
            assert len(consumers)==len(event['consumers']) and 1<=len(consumers)<=4
            for index,e in enumerate(sorted(consumers,key=lambda e:e['ordinal'])):
                assert e['ordinal']==index
                y=load(e['tensors']['output']);c=event['consumers'][index]
                assert c['same_q_object'] and c['same_scale_object'] and sha(y)==c['output_sha256']
                assert c['q_sha256']==event['q_sha256'] and c['scale_sha256']==event['scale_sha256']
            logits=byevent(generation,'first_logits')
            logit=next(e for e in logits if e['rank']==rank)
            assert logit['logical_ids']==scheduler['logical_ids'] and logit['request_ids']==scheduler['request_ids']
            actual_logits=load(logit['tensor']);assert actual_logits.shape[0]==x.shape[0]
            xf=x.float();rowmax=xf.abs().amax(dim=1);globalmax=rowmax.max()
            native=nq[target].float()*ns[target];returned=q[target].float()*s[target]
            mse0=float((native-xf[target]).square().mean());mse1=float((returned-xf[target]).square().mean())
            power=float(xf[target].square().mean())
            extrema=[i for i,v in enumerate(rowmax) if v==globalmax]
            metrics={'scale_ratio':float(s[target]/ns[target]) if ns[target]>0 else None,
                'target_absmax':float(rowmax[target]),'batch_local_absmax':float(globalmax),
                'external_range_increase':bool(globalmax>rowmax[target]),
                'extremum_logical_ids':[scheduler['logical_ids'][i] for i in extrema],
                'target_native_scale':float(ns[target]),'target_returned_scale':float(s[target]),
                'changed_target_codes':int((q[target]!=nq[target]).sum()),
                'changed_target_dequant':int((returned!=native).sum()),
                'target_native_mse':mse0,'target_returned_mse':mse1,
                'target_native_nmse':mse0/power if power else None,'target_returned_nmse':mse1/power if power else None,
                'target_native_zero_ratio':float((nq[target]==0).float().mean()),
                'target_returned_zero_ratio':float((q[target]==0).float().mean()),
                'target_native_saturation_ratio':float((nq[target].to(torch.int16).abs()>=127).float().mean()),
                'target_returned_saturation_ratio':float((q[target].to(torch.int16).abs()>=127).float().mean()),
                'actual_internal_target_request_id':event['target_request_id'],
                'target_token_position':scheduler['row_token_positions'][target],
                'target_generated_prefix':target_prefix,
                'captured_logits_predict_output_index_zero_based':len(target_prefix),
                'non_target_q_scale_exact':True,'input_row_sha256':sha(x[target]),
                'all_rows_reference_q_exact':event['calibration']['q_exact'],
                'target_reference_qualified':event.get('target_calibration',{}).get('qualified',event['calibration']['q_exact'] and event['calibration']['scale_close']),
                'peer_reference_code_mismatches':int((nq[peer]!=t['reference_q'][peer]).sum()) if 'reference_q' in t else None,
                'native_q_row_sha256':sha(nq[target]),'native_scale_row_sha256':sha(ns[target:target+1])}
            if run['mode']=='shared' and metrics['external_range_increase']:
                assert torch.allclose(s[target],globalmax/127,rtol=1e-6,atol=0)
                recompute=torch.round(xf[target]/s[target]).clamp(-128,127).to(torch.int8)
                assert same(recompute,q[target]),'Stored target codes do not use actual batch scale'
                assert all(i!=target for i in extrema),'External stimulus not larger than target'
            ranks[str(rank)]={'call':call,'tensors':t,'target':target,'logits':actual_logits[target].double(),
                              'metrics':metrics,'target_input':x[target]}
        assert ranks['0']['call']['scheduler']['logical_ids']==ranks['1']['call']['scheduler']['logical_ids']
        data[generation]={'run':run,'ranks':ranks}
        # Keep only target-sized views and source tensor references while this
        # bounded matrix is analyzed. No device operations are performed.
    def exact_outputs(a,b):
        def clean(run):return {r['logical_id']:{k:r[k] for k in ('token_ids','text','finish_reason','logprobs')} for r in run['requests']}
        return clean(a)==clean(b)
    def logits_difference(base,fault):
        assert not torch.isnan(base).any() and not torch.isnan(fault).any(),'NaN logits cannot be scored'
        delta=torch.where(base==fault,torch.zeros_like(base),base-fault)
        logp=torch.log_softmax(base,dim=-1);logq=torch.log_softmax(fault,dim=-1)
        positive=logp.isfinite()
        top0=torch.topk(base,5);top1=torch.topk(fault,5)
        return {'target_logits_changed':bool((delta!=0).any()),'target_logits_bytes_changed':not same(base,fault),'target_logits_max_abs_delta':float(delta.abs().max()),
                'target_logits_l2':float(torch.linalg.vector_norm(delta)),
                'kl_native_to_fault':float((logp[positive].exp()*(logp[positive]-logq[positive])).sum()),
                'top1_native':int(top0.indices[0]),'top1_fault':int(top1.indices[0]),
                'top1_margin_native':float(top0.values[0]-top0.values[1]),
                'top1_margin_fault':float(top1.values[0]-top1.values[1]),
                'top5_native':top0.indices.tolist(),'top5_fault':top1.indices.tolist()}
    def first_difference(a,b):
        for i,(x,y) in enumerate(zip(a,b)):
            if x!=y:return i
        return min(len(a),len(b)) if len(a)!=len(b) else None
    native_input_confounded=0;native_identical_checked=0;native_identical_contaminated=0
    for generation,d in data.items():
        run=d['run']
        if generation.startswith('screen'):continue
        parts=generation.rsplit('_',2);parsed_case,parsed_batch,stage=parts
        case=run.get('case_id',parsed_case);batch=run.get('batch_id',parsed_batch);phase=run.get('phase','full')
        if 'fault_skipped' in run:
            prefix=run.get('matrix_prefix',case+'_'+batch)
            baseline=data.get(prefix+'_H0')
            assert run['mode']=='healthy' and stage=='H1' and baseline is not None
            reason=run['fault_skipped']
            if reason=='NO_EXTERNAL_RANGE_INCREASE_ON_EITHER_RANK':
                assert not any(v['metrics']['external_range_increase'] for v in baseline['ranks'].values()), 'Skip reason contradicted by healthy tensor range'
            if 'calibration' in reason.lower() and 'failed on at least one rank' in reason.lower():
                assert not all(v['metrics']['target_reference_qualified'] for item in (baseline,d) for v in item['ranks'].values()), 'Calibration skip contradicted by actual target tensors'
            for rank,r in d['ranks'].items():
                m=r['metrics'];b=baseline['ranks'][rank]
                assert same(r['tensors']['returned_q'],r['tensors']['native_q']) and same(r['tensors']['returned_scale'],r['tensors']['native_scale'])
                skip_rows.append({'case':case,'batch':batch,'phase':phase,'rank':rank,'generation':generation,
                    'stage':'H1_HEALTHY_SKIP_GATE','status':'NOT_TRIGGERED','fault_executed':False,
                    'skip_reason':reason,'baseline_generation':prefix+'_H0',
                    'actual_requests':run['logical_ids'],'healthy_input_exact':same(r['tensors']['input_x'],b['tensors']['input_x']),
                    'candidate_shared_range_ratio':m['batch_local_absmax']/m['target_absmax'] if m['target_absmax'] else None,
                    **m})
        if stage=='H0':
            baseline=data.get(run.get('solo_baseline_generation',case+'_B0_H0'))
            for rank,r in d['ranks'].items():
                m=r['metrics'];b=baseline['ranks'][rank] if baseline else None
                identical=b is not None and same(r['target_input'],b['target_input'])
                qsame=b is not None and m['native_q_row_sha256']==b['metrics']['native_q_row_sha256']
                ssame=b is not None and m['native_scale_row_sha256']==b['metrics']['native_scale_row_sha256']
                if batch!='B0':
                    native_input_confounded+=int(not identical);native_identical_checked+=int(identical)
                    native_identical_contaminated+=int(identical and not (qsame and ssame))
                pair_rows.append({'case':case,'batch':batch,'phase':phase,'rank':rank,'generation':generation,
                    'actual_batch_size':len(run['logical_ids']),'actual_requests':run['logical_ids'],
                    'target_input_exact_vs_B0':identical,'target_native_q_exact_vs_B0':qsame,
                    'target_native_scale_exact_vs_B0':ssame,'attribution':'same target input' if identical else 'upstream input changed; cannot attribute cross-sequence quantization',
                    'answer_correct':run.get('score',{}).get('exact_correct'),**m})
        elif stage in ('P','F'):
            prefix=run.get('matrix_prefix',case+'_'+batch);h0=data[prefix+'_H0'];h1=data.get(prefix+'_H1');recovery=data.get(prefix+'_R');repeat=data.get(prefix+'_F2')
            assert h1 is not None
            healthy_output_repeat=exact_outputs(h0['run'],h1['run'])
            recovery_output=recovery is not None and exact_outputs(h0['run'],recovery['run'])
            fault_repeat_output=repeat is not None and exact_outputs(run,repeat['run'])
            a,b=request(h0['run']),request(run)
            for rank,r in d['ranks'].items():
                baseline=h0['ranks'][rank];h=h1['ranks'][rank]
                input_exact=same(r['target_input'],baseline['target_input']) and same(r['tensors']['input_x'],baseline['tensors']['input_x'])
                assert input_exact,'Non-native run received changed healthy input'
                assert r['call']['contract']==baseline['call']['contract']
                healthy_exact=healthy_output_repeat and same(baseline['logits'],h['logits']) and all(same(baseline['tensors'][k],h['tensors'][k]) for k in baseline['tensors'])
                recovered=recovery_output and same(baseline['logits'],recovery['ranks'][rank]['logits']) and all(same(baseline['tensors'][k],recovery['ranks'][rank]['tensors'][k]) for k in baseline['tensors']) if recovery else False
                repeated=fault_repeat_output and same(r['logits'],repeat['ranks'][rank]['logits']) and all(same(r['tensors'][k],repeat['ranks'][rank]['tensors'][k]) for k in r['tensors']) if repeat else False
                diff=logits_difference(baseline['logits'],r['logits']);m=r['metrics']
                g2=stage=='F' and healthy_exact and input_exact and m['external_range_increase'] and m['scale_ratio'] is not None and m['scale_ratio']>1 and m['changed_target_codes']>0 and m['target_returned_mse']>m['target_native_mse']
                g3=g2 and diff['target_logits_changed'] and repeated and recovered
                row={'case':case,'batch':batch,'phase':phase,'rank':rank,'generation':generation,'stage':stage,
                    'status':'EXECUTED_F' if stage=='F' else 'REFERENCE_CONTROL','fault_executed':stage=='F',
                    'fault_definition':'controlled paired INT8 Q/scale substitution consumed by real W8A8 matmul; not a native quantizer defect' if stage=='F' else 'per-token reference recomputation and rounding control',
                    'actual_requests':run['logical_ids'],'healthy_native_repeat_exact':healthy_exact,'healthy_input_exact':input_exact,
                    'recovery_exact':recovered,'fault_repeat_exact':repeated,
                    'first_target_token_difference_zero_based':first_difference(a['token_ids'],b['token_ids']),
                    'target_tokens_changed':a['token_ids']!=b['token_ids'],'target_text_changed':a['text']!=b['text'],
                    'native_answer_correct':h0['run'].get('score',{}).get('exact_correct'),
                    'result_answer_correct':run.get('score',{}).get('exact_correct'),
                    'native_objective_answer_correct':h0['run']['independent_quality']['objective_answer_correct'],
                    'result_objective_answer_correct':run['independent_quality']['objective_answer_correct'],
                    'native_answer_extraction':h0['run']['independent_quality']['extraction_method'],
                    'result_answer_extraction':run['independent_quality']['extraction_method'],
                    'native_completed':h0['run'].get('score',{}).get('completed'),'result_completed':run.get('score',{}).get('completed'),
                    'G2':bool(g2),'G3_repeatable_target_logits':bool(g3),**m,**diff}
                (fault_rows if stage=='F' else reference_rows).append(row)
    cases=sorted({r['case'] for r in pair_rows})
    damage_cases=sorted({r['case'] for r in fault_rows if r['G3_repeatable_target_logits'] and r['native_objective_answer_correct'] is True and r['result_objective_answer_correct'] is False})
    format_damage_cases=sorted({r['case'] for r in fault_rows if r['G3_repeatable_target_logits'] and r['native_answer_correct'] is True and r['result_answer_correct'] is False})
    g1=len(cases)==5 and all({r['batch'] for r in pair_rows if r['case']==c}=={'B0','B1','B2','B3','B4'} for c in cases)
    complete_batch_cases=[c for c in cases if {r['batch'] for r in pair_rows if r['case']==c}=={'B0','B1','B2','B3','B4'}]
    summary={'status':'ANALYZED','execution_status':result['status'],'complete_run':result['status']=='completed',
        'analyzer_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'analysis_runtime':{'python':sys.version,'torch':torch.__version__,'device':'CPU only'},
        'checked_tensor_files':len(checked),'native_bound_calls':sum(len(v['ranks']) for v in data.values()),
        'candidate_count':len(result.get('selection',{}).get('measurements',{})),
        'selected_candidates':result.get('selection',{}).get('selected'),
        'candidate_selection':result.get('selection',{}),
        'long_answer_plan':result.get('long_answer_plan'),
        'run_phase_counts':{phase:sum(r.get('phase','screen' if r['generation_id'].startswith('screen') else 'full')==phase for r in result['runs']) for phase in ('screen','short','answer','full')},
        'strong_outliers_both_ranks':result.get('selection',{}).get('strong_outliers_both_ranks'),
        'scale_domain':'rank-local TP feature shard; no artificial multiplier or added cross-rank max',
        'fault_definition':'Controlled paired INT8 Q/scale replacement on the real npu_dynamic_quant -> npu_quant_matmul consumption chain; native producer still runs and is recorded.',
        'native_defect_claim':'No native quantizer defect inferred from reference rounding mismatches or controlled substitution.',
        'operator_proof_boundary':'Python torch_npu producer/consumer APIs; no independent ACLNN kernel-symbol trace claimed.',
        'G0':bool(data),'G1':bool(complete_batch_cases),'G1_complete_batch_cases':complete_batch_cases,'G1_full_five_case_batch_matrix':g1,
        'G2':any(r['G2'] for r in fault_rows),'G3':any(r['G3_repeatable_target_logits'] for r in fault_rows),
        'G4_at_least_five_objective_cases_degraded':len(damage_cases)>=5,
        'objective_damage_cases':damage_cases,
        'strict_format_damage_cases':format_damage_cases,
        'native_batch_comparisons_with_changed_upstream_input':native_input_confounded,
        'native_batch_comparisons_with_identical_target_input':native_identical_checked,
        'native_changed_pair_with_identical_target_input':native_identical_contaminated,
        'fault_runs':len({r['generation'] for r in fault_rows}),
        'fault_results_table':{'file':'fault_injection_results.csv','executed_F_rank_rows':len(fault_rows),
            'status':'EXECUTED_F_PRESENT' if fault_rows else ('NO_F_DISPATCHED_GATES_RECORDED' if skip_rows else 'NO_F_EVIDENCE_RECORDED'),
            'fixed_header':True,'contains_only_actual_F':True},
        'fault_skip_table':{'file':'fault_skip_results.csv','healthy_rank_rows':len(skip_rows),
            'conditions':len({r['generation'] for r in skip_rows}),'all_fault_executed_false':True},
        'fault_skipped_runs':[{'generation':r['generation_id'],'reason':r['fault_skipped']} for r in result['runs'] if 'fault_skipped' in r],
        'healthy_repeat_failed_runs':[r['generation_id'] for r in result['runs'] if r.get('healthy_native_repeat_exact') is False],
        'recovery_failed_runs':[r['generation_id'] for r in result['runs'] if r.get('recovery_exact') is False],
        'reference_rounding_nonidentity_runs':[r['generation_id'] for r in result['runs'] if r.get('reference_matches_native_exactly') is False],
        'target_token_change_runs':sorted({r['generation'] for r in fault_rows if r['target_tokens_changed']}),
        'target_logit_change_runs':sorted({r['generation'] for r in fault_rows if r['target_logits_changed']}),
        'reproducible_target_logit_runs':sorted({r['generation'] for r in fault_rows if r['G3_repeatable_target_logits']}),
        'quality_warning':'Strict requested format and objective numeric correctness are separate. Numeric scoring uses only unambiguous final answer values; unfinished or ambiguous answers are unknown, never silently counted numerically wrong.',
        'normal_engine_defect_proven':False}
    summary['conclusion']='B_CONTROLLED_SHARED_SCALE_MODEL_EFFECT' if all(summary[k] for k in ('G0','G1','G2','G3')) else 'C_MODEL_EFFECT_NOT_FULLY_PROVEN'
    write_csv(out/'batch_pair_comparison.csv',pair_rows,('case','batch','phase','rank','generation','target_input_exact_vs_B0','target_native_q_exact_vs_B0','target_native_scale_exact_vs_B0'))
    write_csv(out/'fault_injection_results.csv',fault_rows,FAULT_FIELDS)
    write_csv(out/'fault_skip_results.csv',skip_rows,SKIP_FIELDS)
    write_csv(out/'per_token_reference_results.csv',reference_rows,FAULT_FIELDS)
    write_csv(out/'objective_quality_results.csv',quality_rows)
    (out/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'tensor_manifest_verified.json').write_text(json.dumps(checked,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
