#!/usr/bin/env python3
"""CPU-only raw-storage/CSV verification of quant_probe.py v2 evidence.

Requires NumPy, never imports torch, torch_npu or initializes an accelerator.
PyTorch ZIP tensors are decoded through a small allowlist of tensor rebuilders;
arbitrary pickle globals and non-CPU storage locations are rejected.
"""
import argparse
from collections import OrderedDict
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import pickle
import zipfile

import numpy as np


STORAGE = {
    "HalfStorage": ("float16", 2), "BFloat16Storage": ("bfloat16", 2),
    "FloatStorage": ("float32", 4), "CharStorage": ("int8", 1),
    "ByteStorage": ("uint8", 1),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rebuild_tensor(storage, offset, size, stride, *unused):
    dtype, itemsize, payload, storage_numel = storage
    size, stride = tuple(size), tuple(stride)
    if not size or any(type(n) is not int or n <= 0 for n in size):
        raise ValueError("Unsupported tensor shape")
    dense = []
    step = 1
    for extent in reversed(size):
        dense.append(step)
        step *= extent
    if stride != tuple(reversed(dense)):
        raise ValueError("Only the probe's contiguous CPU tensors are accepted")
    if type(offset) is not int or offset < 0 or offset + step > storage_numel:
        raise ValueError("Invalid tensor storage offset/size")
    if len(payload) != storage_numel * itemsize:
        raise ValueError("Storage payload length does not match typed storage")
    return {"dtype": dtype, "shape": size,
            "raw": payload[offset * itemsize:(offset + step) * itemsize]}


class TensorUnpickler(pickle.Unpickler):
    def __init__(self, stream, archive, prefix):
        super().__init__(stream)
        self.archive, self.prefix = archive, prefix

    def find_class(self, module, name):
        if module == "torch._utils" and name in ("_rebuild_tensor", "_rebuild_tensor_v2"):
            return rebuild_tensor
        if module == "torch" and name in STORAGE:
            return STORAGE[name]
        if module == "collections" and name == "OrderedDict":
            return OrderedDict
        raise pickle.UnpicklingError(f"Unapproved tensor archive global {module}.{name}")

    def persistent_load(self, persistent_id):
        if (not isinstance(persistent_id, tuple) or len(persistent_id) != 5
                or persistent_id[0] != "storage"):
            raise pickle.UnpicklingError("Unapproved persistent storage record")
        _, descriptor, key, location, count = persistent_id
        if descriptor not in STORAGE.values() or location != "cpu":
            raise pickle.UnpicklingError("Only supported typed CPU storage is accepted")
        if not isinstance(key, str) or not key.isdecimal() or type(count) is not int or count < 1:
            raise pickle.UnpicklingError("Invalid storage key/element count")
        dtype, itemsize = descriptor
        payload = self.archive.read(self.prefix + "data/" + key)
        return dtype, itemsize, payload, count


def read_tensors(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate entries in tensor ZIP")
        pickles = [name for name in names if name.endswith("/data.pkl")]
        if len(pickles) != 1:
            raise ValueError("Expected exactly one PyTorch tensor dictionary")
        prefix = pickles[0][:-len("data.pkl")]
        if prefix + "byteorder" not in names or archive.read(prefix + "byteorder") != b"little":
            raise ValueError("Explicit little-endian storage required")
        data = TensorUnpickler(io.BytesIO(archive.read(pickles[0])), archive, prefix).load()
    if not isinstance(data, dict) or set(data) != {"canonical_input", "input", "input_post", "q", "scale"}:
        raise ValueError("Unexpected probe tensor dictionary")
    return data


def array(tensor):
    dtype = tensor["dtype"]
    if dtype == "bfloat16":
        result = (np.frombuffer(tensor["raw"], dtype="<u2").astype(np.uint32) << 16).view(np.float32)
    else:
        result = np.frombuffer(tensor["raw"], dtype={
            "float16": "<f2", "float32": "<f4", "int8": "i1", "uint8": "u1"}[dtype])
    return result.reshape(tensor["shape"])


def metrics(x, q, scale):
    xf, qf = x.astype(np.float32), q.astype(np.float32)
    sf = scale.astype(np.float32).reshape(-1, 1)
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        mul, div = qf * sf, qf / sf
        error = mul - xf
        mse_mul = float(np.mean(error ** 2, dtype=np.float32))
        mse_div = float(np.mean((div - xf) ** 2, dtype=np.float32))
        return {
            "multiply_mse": mse_mul, "divide_mse": mse_div,
            "dequant_direction": "multiply" if mse_mul < mse_div else "divide_or_ambiguous",
            "nmse": mse_mul / max(float(np.mean(xf ** 2, dtype=np.float32)), 1e-30),
            "max_abs_error": float(np.max(np.abs(error))),
            "mean_abs_error": float(np.mean(np.abs(error), dtype=np.float32)),
            "zero_ratio": float(np.mean(q == 0, dtype=np.float32)),
            "saturation_ratio": float(np.mean(np.abs(q.astype(np.int16)) >= 127, dtype=np.float32)),
        }


def bool_field(row, name):
    if row[name] not in ("True", "False"):
        raise ValueError(f"Invalid CSV Boolean {name}")
    return row[name] == "True"


def verify(root):
    root = Path(root)
    summary = json.loads((root / "summary.json").read_text(encoding="utf-8"))
    if summary["schema"] != "batch_outlier_quant_probe_v2":
        raise ValueError("Probe evidence predates per-round tensor capture")
    if summary["dtypes"] != ["torch.float16", "torch.bfloat16"]:
        raise ValueError("Unexpected dtype matrix")
    with (root / "quant_scale_probe.csv").open(newline="", encoding="utf-8-sig") as stream:
        records = list(csv.DictReader(stream))
    if len(records) != summary["calls"]:
        raise ValueError("CSV/summary call count mismatch")
    expected_keys = {(dtype, case, iteration) for dtype in summary["dtypes"]
                     for case in summary["cases"] for iteration in range(summary["iterations"])}
    actual_keys = [(r["dtype"], r["case"], int(r["iteration"])) for r in records]
    if len(actual_keys) != len(set(actual_keys)) or set(actual_keys) != expected_keys:
        raise ValueError("Missing/duplicate dtype/case/iteration records")
    # The first complete A0 tensor is the independently re-read per-dtype baseline.
    records.sort(key=lambda r: (summary["dtypes"].index(r["dtype"]),
                                summary["cases"].index(r["case"]), int(r["iteration"])))
    if summary["cases"][0] != "A0":
        raise ValueError("Expected A0 fixed-target baseline first")
    expected_cases = ["A0", "A1", "A2_x4", "A2_x16", "A2_x64", "A2_x256", "A2_x1024", "A3_x1024"]
    if summary["cases"] != expected_cases:
        raise ValueError("Unexpected native experiment matrix")
    baseline, first, first_full = {}, {}, {}
    reviews = []
    numeric_fields = ("target_scale", "absmax_over_127", "scale_reference_absdiff",
                      "all_rows_scale_reference_max_absdiff")
    for row in records:
        dtype, case, iteration = row["dtype"], row["case"], int(row["iteration"])
        if int(row["logical_device"]) != summary["logical_device"]:
            raise ValueError("CSV/summary logical device mismatch")
        if row["physical_device"] != ("" if summary["physical_device"] is None else str(summary["physical_device"])):
            raise ValueError("CSV/summary caller-declared physical mapping mismatch")
        short_dtype = dtype.removeprefix("torch.")
        filename = f"{short_dtype}_{case}.round{iteration:04d}.pt"
        if row["tensor_file"] != filename:
            raise ValueError("Unexpected or unsafe tensor filename")
        path = root / filename
        archive = path.read_bytes()
        if len(archive) != int(row["tensor_file_bytes"]) or sha(archive) != row["tensor_file_sha256"]:
            raise ValueError(f"Tensor archive size/hash mismatch: {filename}")
        data = read_tensors(path)
        count = int(row["rows"])
        expected_count = 1 if case == "A0" else (8 if case.startswith("A3") else 2)
        if count != expected_count:
            raise ValueError("Case row count differs from specified matrix")
        for name in ("canonical_input", "input", "input_post"):
            if data[name]["dtype"] != short_dtype or data[name]["shape"] != (count, 1024):
                raise ValueError(f"Input dtype/shape mismatch: {filename}/{name}")
        if data["q"]["dtype"] != "int8" or data["q"]["shape"] != (count, 1024):
            raise ValueError("Q contract mismatch")
        if data["scale"]["dtype"] != "float32" or data["scale"]["shape"] != (count,):
            raise ValueError("Native scale must be FP32 [rows]")
        if row["scale_shape"] != str([count]) or row["scale_dtype"] != "torch.float32":
            raise ValueError("CSV scale shape/dtype disagrees with raw tensor")
        x, q, scale = array(data["input"]), array(data["q"]), array(data["scale"])
        if not np.isfinite(x).all() or not np.isfinite(scale).all() or not (scale > 0).all():
            raise ValueError("Nonfinite input or invalid native scale")
        raw_hashes = {
            "canonical_input_sha256": sha(data["canonical_input"]["raw"]),
            "input_pre_sha256": sha(data["input"]["raw"]),
            "input_post_sha256": sha(data["input_post"]["raw"]),
            "all_q_sha256": sha(data["q"]["raw"]),
            "all_scale_sha256": sha(data["scale"]["raw"]),
            "target_input_sha256": sha(data["input"]["raw"][:2048]),
            "target_q_sha256": sha(data["q"]["raw"][:1024]),
            "target_scale_sha256": sha(data["scale"]["raw"][:4]),
        }
        if any(row[key] != value for key, value in raw_hashes.items()):
            raise ValueError(f"Raw storage hash mismatch: {filename}")
        target = (data["input"]["raw"][:2048], data["q"]["raw"][:1024], data["scale"]["raw"][:4])
        full = (data["input"]["raw"], data["q"]["raw"], data["scale"]["raw"])
        baseline.setdefault(dtype, target)
        first.setdefault((dtype, case), target)
        first_full.setdefault((dtype, case), full)
        if target[0] != baseline[dtype][0]:
            raise ValueError("Target input row is not bit-identical to the single-row baseline")
        input_unchanged = data["input"]["raw"] == data["input_post"]["raw"] == data["canonical_input"]["raw"]
        expected_scale = np.max(np.abs(x.astype(np.float32)), axis=-1) / np.float32(127)
        stats = metrics(x[:1], q[:1], scale[:1])
        stats.update({"target_scale": float(scale[0]), "absmax_over_127": float(expected_scale[0]),
                      "scale_reference_absdiff": float(abs(scale[0] - expected_scale[0])),
                      "all_rows_scale_reference_max_absdiff": float(np.max(np.abs(scale - expected_scale)))})
        for field, value in stats.items():
            if isinstance(value, str):
                same = row[field] == value
            else:
                # FP32 reductions may have different CPU summation order between
                # PyTorch and NumPy; hashes and Boolean equality remain exact.
                same = math.isfinite(float(row[field])) and math.isclose(float(row[field]), value, rel_tol=2e-6, abs_tol=1e-10)
            if not same:
                raise ValueError(f"CSV statistic mismatch: {filename}/{field}, csv={row[field]}, recomputed={value}")
        facts = {"input_unchanged": input_unchanged,
                 "target_same_as_single": target == baseline[dtype],
                 "repeat_identical": target == first[(dtype, case)],
                 "full_repeat_identical": full == first_full[(dtype, case)],
                 "all_rows_scale_reference_close": bool(np.allclose(scale, expected_scale, rtol=1e-6, atol=0))}
        for field, value in facts.items():
            if bool_field(row, field) != value:
                raise ValueError(f"CSV Boolean contradicts raw tensors: {filename}/{field}")
        reference_q = np.clip(np.rint(x.astype(np.float32) / scale[:, None]), -128, 127).astype(np.int8)
        reviews.append({"dtype": dtype, "case": case, "iteration": iteration,
                        "file": filename, "archive_sha256": sha(archive), "raw_hashes": raw_hashes,
                        **facts, **stats, "native_vs_cpu_divide_round_clip_q_mismatches": int(np.count_nonzero(q != reference_q))})
    aggregate = {"all_input_unchanged": all(r["input_unchanged"] for r in reviews),
                 "all_target_same_as_single": all(r["target_same_as_single"] for r in reviews),
                 "all_repeats_identical": all(r["repeat_identical"] for r in reviews),
                 "all_full_repeats_identical": all(r["full_repeat_identical"] for r in reviews),
                 "all_rows_scale_reference_close": all(r["all_rows_scale_reference_close"] for r in reviews),
                 "all_dequant_multiply": all(r["dequant_direction"] == "multiply" for r in reviews)}
    if any(summary[key] != value for key, value in aggregate.items()):
        raise ValueError("Summary flags contradict independently re-read tensor evidence")
    expected_files = {row["tensor_file"] for row in records}
    if {p.name for p in root.glob("*.pt")} != expected_files:
        raise ValueError("Unexpected/missing tensor files outside CSV matrix")
    return {"schema": "batch_outlier_quant_cpu_review_v1", "status": "PASS",
            "verification_scope": "Local CPU NumPy plus restricted PyTorch ZIP storage decoder; no torch/NPU imports",
            "native_result": "TARGET_INDEPENDENT_IN_TESTED_MATRIX" if all(aggregate.values()) else "NATIVE_DIFFERENCE_REQUIRES_REVIEW",
            "calls": len(reviews), "tensor_files": len(expected_files), "aggregate": aggregate,
            "cpu_formula_q_mismatch_diagnostic": {
                "max_per_call": max(r["native_vs_cpu_divide_round_clip_q_mismatches"] for r in reviews),
                "total_across_calls": sum(r["native_vs_cpu_divide_round_clip_q_mismatches"] for r in reviews),
                "calls_with_difference": sum(r["native_vs_cpu_divide_round_clip_q_mismatches"] != 0 for r in reviews)},
            "input_fixed_target_bitwise_verified": True,
            "native_scale_contract": "FP32 [rows], compared with row absmax/127; q*scale vs q/scale error independently recomputed",
            "cpu_statistic_tolerance": {"relative": 2e-6, "absolute": 1e-10},
            "quant_formula_note": "CPU divide/round/clip comparison is diagnostic; backend tie behavior is not silently assumed equivalent.",
            "source_probe_sha256_recorded": summary["source_sha256"],
            "csv_sha256": sha((root / "quant_scale_probe.csv").read_bytes()),
            "summary_sha256": sha((root / "summary.json").read_bytes()),
            "scope": "Synthetic rows only; no real Prompt, scheduler, model propagation or AIME claim", "records": reviews}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = verify(args.root)
    except Exception as error:
        report = {"schema": "batch_outlier_quant_cpu_review_v1", "status": "FAIL",
                  "error": f"{type(error).__name__}: {error}"}
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({key: report.get(key) for key in ("status", "native_result", "calls", "tensor_files", "aggregate", "cpu_formula_q_mismatch_diagnostic", "error")}))
    if report["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
