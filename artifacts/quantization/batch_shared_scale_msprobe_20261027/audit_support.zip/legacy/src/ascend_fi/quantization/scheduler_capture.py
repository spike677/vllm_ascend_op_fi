"""Bounded row provenance at the vLLM-Ascend 0.23 eager runner boundary.

The execute wrapper owns the lifetime only. Row order is captured *after* the
original _prepare_inputs returns, following _update_states and any batch reorder.
The reviewed source builds req_indices by repeating current input_batch indices
and positions as num_computed_tokens + per-request query offsets. Both prepared
CPU buffers are checked here. No membership is inferred from activation shape.

This adapter supports text-only, synchronous, nonspeculative TP/PP/DP/PCP/DCP=1
execution. It does not find a worker, launch requests, change scheduling, or
install quantization hooks. A different runner source requires explicit review
and its expected_source_sha256; a matching hash alone is not a model-level test.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import hashlib
import inspect
from numbers import Integral
from pathlib import Path
import threading
from typing import Any
import uuid

from .batch_rows import BatchRowContext


AUDITED_RUNNER_SHA256 = "94d75dbeb5d23ab5b383cdc69114167392b967994bb21342cf748b733ba9a968"
_MISSING = object()


class SchedulerCaptureError(RuntimeError):
    """The observed runner no longer proves the required row mapping."""


def _integer(value: Any, name: str, *, positive: bool = False) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise SchedulerCaptureError(f"{name}:REQUIRES_INTEGER")
    result = int(value)
    if result < (1 if positive else 0):
        raise SchedulerCaptureError(f"{name}:OUT_OF_RANGE")
    return result


def _ids(value: Any, name: str) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)) or not value:
        raise SchedulerCaptureError(f"{name}:REQUIRES_NONEMPTY_SEQUENCE")
    result = tuple(value)
    if any(not isinstance(item, str) or not item for item in result) or len(set(result)) != len(result):
        raise SchedulerCaptureError(f"{name}:REQUIRES_UNIQUE_REQUEST_IDS")
    return result


def _prefix(value: Any, size: int, name: str) -> tuple[int, ...]:
    try:
        values = list(value[:size])
    except (AttributeError, TypeError, IndexError) as exc:
        raise SchedulerCaptureError(f"{name}:CPU_BUFFER_UNAVAILABLE") from exc
    if len(values) != size:
        raise SchedulerCaptureError(f"{name}:CPU_BUFFER_TOO_SHORT")
    return tuple(_integer(item, name) for item in values)


@dataclass(frozen=True)
class StepSnapshot:
    step: int
    request_ids: tuple[str, ...]
    scheduled_tokens: tuple[int, ...]
    computed_tokens: tuple[int, ...]
    prompt_tokens: tuple[int, ...]
    row_request_indices: tuple[int, ...]
    row_token_positions: tuple[int, ...]
    phase: str
    skip_reason: str | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "step": self.step, "request_ids": list(self.request_ids),
            "scheduled_tokens": list(self.scheduled_tokens),
            "computed_tokens": list(self.computed_tokens),
            "prompt_tokens": list(self.prompt_tokens),
            "row_request_indices": list(self.row_request_indices),
            "row_token_positions": list(self.row_token_positions),
            "phase": self.phase, "skip_reason": self.skip_reason,
            "capture_point": "after_original_prepare_inputs",
        }


class SchedulerCapture:
    def __init__(self, runner: Any, *, expected_request_ids: list[str] | tuple[str, ...],
                 expected_source_sha256: str = AUDITED_RUNNER_SHA256,
                 max_contexts: int = 1, max_steps: int = 256,
                 allow_single_request: bool = False):
        self.runner = runner
        self.expected_request_ids = _ids(expected_request_ids, "expected_request_ids")
        if type(allow_single_request) is not bool:
            raise SchedulerCaptureError("ALLOW_SINGLE_REQUEST_MUST_BE_BOOL")
        if len(self.expected_request_ids) == 1 and not allow_single_request:
            raise SchedulerCaptureError("SINGLE_REQUEST_REQUIRES_EXPLICIT_CONTROL")
        if (not isinstance(expected_source_sha256, str) or len(expected_source_sha256) != 64
                or any(c not in "0123456789abcdef" for c in expected_source_sha256)):
            raise SchedulerCaptureError("EXPLICIT_RUNNER_SOURCE_SHA256_REQUIRED")
        self.expected_source_sha256 = expected_source_sha256
        self.allow_single_request = allow_single_request
        self.max_contexts = _integer(max_contexts, "max_contexts", positive=True)
        self.max_steps = _integer(max_steps, "max_steps", positive=True)
        if self.max_contexts > 256 or self.max_steps > 1024:
            raise SchedulerCaptureError("CAPTURE_BUDGET_TOO_LARGE")
        self.capture_id = uuid.uuid4().hex
        self.events: list[dict[str, Any]] = []
        self.source_evidence: dict[str, Any] = {}
        self.context_count = 0
        self._step = 0
        self._installed = False
        self._active = False
        self._snapshot: StepSnapshot | None = None
        self._active_event: dict[str, Any] | None = None
        self._scheduler = None
        self._prepared = False
        self._issued_modules: set[str] = set()
        self._execute_lock = threading.Lock()
        self._thread_id = None

    def _validate_runtime(self) -> None:
        runner = self.runner
        model = getattr(runner, "model_config", None)
        parallel = getattr(runner, "parallel_config", None)
        for name in ("tensor_parallel_size", "pipeline_parallel_size", "data_parallel_size"):
            if _integer(getattr(parallel, name, None), name, positive=True) != 1:
                raise SchedulerCaptureError(f"{name}:ONLY_SINGLE_RANK_SUPPORTED")
        for name in ("dp_size", "pcp_size", "dcp_size"):
            if _integer(getattr(runner, name, None), name, positive=True) != 1:
                raise SchedulerCaptureError(f"{name}:ONLY_SINGLE_RANK_SUPPORTED")
        if getattr(model, "enforce_eager", None) is not True:
            raise SchedulerCaptureError("EAGER_REQUIRED")
        for obj, name in (
            (parallel, "enable_dbo"), (parallel, "enable_expert_parallel"),
            (model, "is_encoder_decoder"), (model, "is_hybrid"),
            (runner, "use_async_scheduling"), (runner, "supports_mm_inputs"),
            (runner, "uses_mrope"),
        ):
            if getattr(obj, name, None) is not False:
                raise SchedulerCaptureError(f"{name}:MUST_BE_EXPLICITLY_DISABLED")
        if getattr(runner, "speculative_config", _MISSING) is not None:
            raise SchedulerCaptureError("SPECULATIVE_DECODING_UNSUPPORTED")
        for name in ("num_spec_tokens", "uses_xdrope_dim"):
            if _integer(getattr(runner, name, None), name) != 0:
                raise SchedulerCaptureError(f"{name}:MUST_BE_ZERO")

    def _validate_source(self) -> None:
        evidence = {}
        for name in ("execute_model", "_prepare_inputs"):
            method = getattr(self.runner, name, None)
            if not callable(method):
                raise SchedulerCaptureError(f"{name}:MISSING_RUNNER_METHOD")
            raw = inspect.unwrap(method)
            try:
                path = inspect.getsourcefile(raw)
                if path is None:
                    raise OSError("source unavailable")
                digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
            except (OSError, TypeError) as exc:
                raise SchedulerCaptureError(f"{name}:RUNNER_SOURCE_UNAVAILABLE") from exc
            if digest != self.expected_source_sha256:
                raise SchedulerCaptureError(f"{name}:RUNNER_SOURCE_HASH_MISMATCH")
            params = inspect.signature(method).parameters
            required = ("scheduler_output", "num_scheduled_tokens") if name == "_prepare_inputs" else ("scheduler_output",)
            if not all(item in params for item in required):
                raise SchedulerCaptureError(f"{name}:RUNNER_SIGNATURE_MISMATCH")
            evidence[name] = {"module": getattr(raw, "__module__", None),
                              "source_file": str(path), "sha256": digest}
        self.source_evidence = evidence

    def __enter__(self):
        if self._installed or getattr(self.runner, "_batch_scale_scheduler_capture", None) is not None:
            raise SchedulerCaptureError("RUNNER_ALREADY_CAPTURED")
        self._validate_runtime()
        self._validate_source()
        self._saved = {}
        self._wrappers = {"execute_model": self._execute, "_prepare_inputs": self._prepare}
        try:
            for name, wrapper in self._wrappers.items():
                self._saved[name] = (self.runner.__dict__.get(name, _MISSING), getattr(self.runner, name))
                setattr(self.runner, name, wrapper)
            self.runner._batch_scale_scheduler_capture = self
            self._installed = True
        except BaseException:
            self._restore()
            raise
        return self

    def _restore(self) -> None:
        collisions = []
        for name, (own, _original) in getattr(self, "_saved", {}).items():
            if getattr(self.runner, name) is not self._wrappers[name]:
                collisions.append(name)
                continue
            if own is _MISSING:
                delattr(self.runner, name)
            else:
                setattr(self.runner, name, own)
        marker = getattr(self.runner, "_batch_scale_scheduler_capture", None)
        if marker is self:
            delattr(self.runner, "_batch_scale_scheduler_capture")
        elif marker is not None:
            collisions.append("capture_owner")
        self._installed = False
        if collisions:
            raise SchedulerCaptureError("RUNNER_RESTORE_COLLISION:" + ",".join(collisions))

    def __exit__(self, exc_type, exc, traceback):
        if self._active:
            raise SchedulerCaptureError("CANNOT_RESTORE_DURING_EXECUTION")
        self._restore()

    @staticmethod
    def _argument(args, kwargs, position, name):
        if name in kwargs:
            return kwargs[name]
        if len(args) > position:
            return args[position]
        raise SchedulerCaptureError(f"{name}:RUNNER_ARGUMENT_MISSING")

    def _execute(self, *args, **kwargs):
        if not self._execute_lock.acquire(blocking=False):
            raise SchedulerCaptureError("CONCURRENT_OR_REENTRANT_RUNNER_CALL")
        try:
            if self._step >= self.max_steps:
                raise SchedulerCaptureError("STEP_BUDGET_EXHAUSTED")
            self._validate_runtime()
            self._step += 1
            self._scheduler = self._argument(args, kwargs, 0, "scheduler_output")
            self._active = True
            self._prepared = False
            self._snapshot = None
            self._issued_modules = set()
            self._thread_id = threading.get_ident()
            self._active_event = {"step": self._step, "contexts": [], "status": "EXECUTING"}
            self.events.append(self._active_event)
            try:
                result = self._saved["execute_model"][1](*args, **kwargs)
                self._active_event["status"] = "RETURNED"
                return result
            except BaseException as exc:
                self._active_event.update(status="FAILED", error=type(exc).__name__ + ":" + str(exc))
                raise
        finally:
            self._active = False
            self._snapshot = None
            self._scheduler = None
            self._thread_id = None
            self._active_event = None
            self._execute_lock.release()

    def _prepare(self, *args, **kwargs):
        if not self._active:
            return self._saved["_prepare_inputs"][1](*args, **kwargs)
        if threading.get_ident() != self._thread_id:
            raise SchedulerCaptureError("PREPARE_ON_DIFFERENT_THREAD")
        if self._prepared:
            raise SchedulerCaptureError("MULTIPLE_PREPARE_CALLS_IN_ONE_EXECUTE")
        scheduler = self._argument(args, kwargs, 0, "scheduler_output")
        counts = self._argument(args, kwargs, 1, "num_scheduled_tokens")
        if scheduler is not self._scheduler:
            raise SchedulerCaptureError("SCHEDULER_OUTPUT_CHANGED")
        result = self._saved["_prepare_inputs"][1](*args, **kwargs)
        self._snapshot = self._capture(scheduler, counts, result)
        self._prepared = True
        self._active_event["snapshot"] = self._snapshot.to_dict()
        return result

    def _capture(self, scheduler, ordered_counts, prepared_result) -> StepSnapshot:
        batch = self.runner.input_batch
        ids = _ids(batch.req_ids, "input_batch.req_ids")
        self._active_event['observed_request_ids'] = list(ids)
        n = _integer(batch.num_reqs, "num_reqs", positive=True)
        if len(ids) != n:
            raise SchedulerCaptureError("REQUEST_COUNT_ORDER_MISMATCH")
        if set(ids) - set(self.expected_request_ids):
            raise SchedulerCaptureError("UNEXPECTED_REQUEST_IN_EXECUTION_BATCH")
        schedule = scheduler.num_scheduled_tokens
        if not isinstance(schedule, Mapping) or set(schedule) != set(ids):
            raise SchedulerCaptureError("SCHEDULE_KEYS_DO_NOT_MATCH_RUNNER")
        counts = tuple(_integer(schedule[req], "scheduled_tokens", positive=True) for req in ids)
        if tuple(_integer(item, "ordered_counts") for item in ordered_counts) != counts:
            raise SchedulerCaptureError("PREPARE_COUNTS_DO_NOT_MATCH_RUNNER_ORDER")
        total = _integer(scheduler.total_num_scheduled_tokens, "total_scheduled_tokens", positive=True)
        if sum(counts) != total:
            raise SchedulerCaptureError("TOTAL_SCHEDULED_TOKEN_MISMATCH")
        if not isinstance(prepared_result, tuple) or len(prepared_result) != 3:
            raise SchedulerCaptureError("PREPARE_RETURN_CONTRACT_MISMATCH")
        if prepared_result[1] is not None or _integer(prepared_result[2], "prepared_total") != total:
            raise SchedulerCaptureError("PREPARE_SPEC_OR_TOKEN_COUNT_MISMATCH")
        for name in ("scheduled_spec_decode_tokens", "scheduled_encoder_inputs"):
            value = getattr(scheduler, name, None)
            if not isinstance(value, Mapping) or value:
                raise SchedulerCaptureError(f"{name}:MUST_BE_EMPTY_MAPPING")
        computed = _prefix(batch.num_computed_tokens_cpu, n, "computed_tokens")
        prompts = _prefix(batch.num_prompt_tokens, n, "prompt_tokens")
        for i, req in enumerate(ids):
            state = self.runner.requests.get(req)
            if state is None or getattr(state, "req_id", None) != req:
                raise SchedulerCaptureError("REQUEST_STATE_ID_MISMATCH")
            if _integer(getattr(state, "num_computed_tokens", None), "request_computed_tokens") != computed[i]:
                raise SchedulerCaptureError("REQUEST_COMPUTED_STATE_MISMATCH")
            prompt = getattr(state, "prompt_token_ids", None)
            if not isinstance(prompt, list) or len(prompt) != prompts[i]:
                raise SchedulerCaptureError("REQUEST_PROMPT_LENGTH_MISMATCH")
            if getattr(state, "prompt_embeds", _MISSING) is not None or getattr(state, "mm_features", _MISSING):
                raise SchedulerCaptureError("TEXT_TOKEN_REQUEST_REQUIRED")
        expected_indices = tuple(i for i, count in enumerate(counts) for _ in range(count))
        expected_positions = tuple(computed[i] + offset for i, count in enumerate(counts) for offset in range(count))
        indices = _prefix(self.runner.req_indices.np, total, "prepared_req_indices")
        positions = _prefix(self.runner._positions_np_buf, total, "prepared_positions")
        if indices != expected_indices or positions != expected_positions:
            raise SchedulerCaptureError("PREPARED_ROW_PROVENANCE_MISMATCH")
        if _prefix(self.runner.num_scheduled_tokens.np, n, "prepared_counts") != counts:
            raise SchedulerCaptureError("PREPARED_TOKEN_COUNTS_MISMATCH")
        phase = "decode" if all(c >= p for c, p in zip(computed, prompts)) else "prefill_or_mixed"
        reason = None
        if phase != "decode":
            reason = "PREFILL_OR_MIXED_BATCH"
        elif set(ids) != set(self.expected_request_ids):
            reason = "EXPECTED_BATCH_NOT_READY"
        elif any(count != 1 for count in counts):
            reason = "MULTITOKEN_DECODE_UNSUPPORTED"
        elif len(ids) == 1 and not self.allow_single_request:
            reason = "SINGLE_REQUEST_NOT_ENABLED"
        return StepSnapshot(self._step, ids, counts, computed, prompts, indices, positions, phase, reason)

    def context_for(self, x: Any, *, module_name: str, mode: str,
                    target_request_id: str) -> dict[str, Any] | None:
        """Return NativePairBinding.scope kwargs for one eligible module call.

        Call this from bind_module's context_provider in the runner thread.
        Prefill, incomplete expected batches, and exhausted context budgets pass
        through. Missing/contradictory provenance fails, rather than guessing.
        """
        if mode not in ("healthy", "shared") or not isinstance(module_name, str) or not module_name:
            raise SchedulerCaptureError("INVALID_MODULE_OR_MODE")
        if target_request_id not in self.expected_request_ids:
            raise SchedulerCaptureError("TARGET_REQUEST_NOT_EXPECTED")
        if not self._active:
            return None
        if threading.get_ident() != self._thread_id:
            raise SchedulerCaptureError("CONTEXT_ON_DIFFERENT_THREAD")
        if self._snapshot is None:
            raise SchedulerCaptureError("MODEL_CALL_WITHOUT_PREPARED_ROW_MAPPING")
        snapshot = self._snapshot
        if snapshot.skip_reason is not None:
            return None
        if module_name in self._issued_modules:
            raise SchedulerCaptureError("DUPLICATE_TARGET_MODULE_IN_STEP")
        if self.context_count >= self.max_contexts:
            self._active_event["context_skip_reason"] = "CONTEXT_BUDGET_EXHAUSTED"
            return None
        shape = getattr(x, "shape", ())
        if len(shape) != 2:
            raise SchedulerCaptureError("TARGET_INPUT_MUST_BE_TWO_DIMENSIONAL")
        rows = _integer(shape[0], "tensor_rows", positive=True)
        # Eager TP1 has no certified padding adapter here. Extra rows might be
        # padding, a reshape, or another layout; shape alone cannot distinguish it.
        if rows != len(snapshot.row_token_positions):
            raise SchedulerCaptureError("UNVERIFIED_TARGET_ROW_LAYOUT")
        context = BatchRowContext.from_scheduler(
            req_ids=snapshot.request_ids,
            num_scheduled_tokens=dict(zip(snapshot.request_ids, snapshot.scheduled_tokens)),
            num_computed_tokens=dict(zip(snapshot.request_ids, snapshot.computed_tokens)),
            padded_rows=rows, expected_request_ids=self.expected_request_ids,
            call_id=f"{self.capture_id}:step{snapshot.step}:{module_name}:call{self.context_count + 1}",
            rank=0, tp_size=1, phase="decode", allow_single_request=self.allow_single_request,
        )
        self._issued_modules.add(module_name)
        self.context_count += 1
        self._active_event["contexts"].append({"module_name": module_name, "mode": mode,
                                               "target_request_id": target_request_id,
                                               "rows": context.to_dict()})
        return {"rows": context, "mode": mode, "target_request_id": target_request_id}


__all__ = ["AUDITED_RUNNER_SHA256", "SchedulerCaptureError", "SchedulerCapture", "StepSnapshot"]
