"""Immutable row provenance for controlled, single-token decode experiments.

This module consumes scheduler/runner metadata supplied by an integration; it
does not infer execution batches from client requests. Only single-rank decode
with exactly one valid row per request is supported. A context is evidence of
the supplied mapping, not independent proof that a runner supplied it correctly.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any


def _items(value: Any, name: str) -> tuple[Any, ...]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise ValueError(f"{name} must be an ordered sequence")
    return tuple(value)


def _identifier(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a nonempty string")
    return value


def _nonnegative_int(value: Any, name: str) -> int:
    if type(value) is not int or value < 0:
        raise ValueError(f"{name} must be a nonnegative integer")
    return value


def _request_list(value: Any, name: str) -> tuple[str, ...]:
    result = _items(value, name)
    if not result:
        raise ValueError(f"{name} must not be empty")
    for item in result:
        _identifier(item, name)
    if len(set(result)) != len(result):
        raise ValueError(f"{name} must contain unique request IDs")
    return result


@dataclass(frozen=True)
class BatchRowContext:
    """Row labels and mask for one explicit quantization call.

    Sequence inputs are defensively copied into tuples. Invalid rows may occur
    anywhere; their optional labels never count toward request membership. The
    scheduler factory uses ``None`` for both labels on appended padding rows.
    ``expected_request_ids`` compares membership, not row order: actual order is
    always ``request_ids``. ``allow_single_request`` enables an explicit healthy
    control but does not authorize a cross-request injection into that control.
    """

    call_id: str
    request_ids: tuple[str | None, ...]
    token_positions: tuple[int | None, ...]
    valid_rows: tuple[bool, ...]
    expected_request_ids: tuple[str, ...]
    phase: str = "decode"
    rank: int = 0
    tp_size: int = 1
    allow_single_request: bool = False

    def __post_init__(self) -> None:
        _identifier(self.call_id, "call_id")
        if self.phase != "decode":
            raise ValueError("only controlled decode is supported; prefill is rejected")
        if type(self.allow_single_request) is not bool:
            raise ValueError("allow_single_request must be a boolean")
        _nonnegative_int(self.rank, "rank")
        _nonnegative_int(self.tp_size, "tp_size")
        if self.tp_size != 1 or self.rank != 0:
            raise ValueError("only tp_size=1 and rank=0 are supported")
        for name in ("request_ids", "token_positions", "valid_rows"):
            object.__setattr__(self, name, _items(getattr(self, name), name))
        expected = _request_list(self.expected_request_ids, "expected_request_ids")
        object.__setattr__(self, "expected_request_ids", expected)
        rows = len(self.request_ids)
        if not rows or len(self.token_positions) != rows or len(self.valid_rows) != rows:
            raise ValueError("row metadata must have the same nonzero length")
        actual: list[str] = []
        for index, (request_id, position, valid) in enumerate(
            zip(self.request_ids, self.token_positions, self.valid_rows)
        ):
            if type(valid) is not bool:
                raise ValueError(f"valid_rows[{index}] must be an explicit boolean")
            if request_id is not None:
                _identifier(request_id, f"request_ids[{index}]")
            if position is not None:
                _nonnegative_int(position, f"token_positions[{index}]")
            if valid:
                if request_id is None or position is None:
                    raise ValueError(f"valid row {index} needs a request ID and token position")
                actual.append(request_id)
        if not actual:
            raise ValueError("at least one valid row is required")
        if len(set(actual)) != len(actual):
            raise ValueError("decode requires exactly one valid row per request")
        if set(actual) != set(expected):
            raise ValueError("valid request membership does not match expected_request_ids")
        if len(actual) == 1 and not self.allow_single_request:
            raise ValueError("single-request control requires allow_single_request=True")

    @property
    def tensor_rows(self) -> int:
        return len(self.request_ids)

    @property
    def valid_indices(self) -> tuple[int, ...]:
        return tuple(i for i, valid in enumerate(self.valid_rows) if valid)

    @property
    def valid_request_ids(self) -> tuple[str, ...]:
        return tuple(self.request_ids[i] for i in self.valid_indices)  # type: ignore[misc]

    def for_tensor_rows(self, rows: int) -> BatchRowContext:
        """Validate the observed tensor row count and return this immutable context."""
        _nonnegative_int(rows, "tensor rows")
        if rows != self.tensor_rows:
            raise ValueError(f"tensor has {rows} rows, mapping has {self.tensor_rows}")
        return self

    def to_dict(self) -> dict[str, Any]:
        return {
            "call_id": self.call_id,
            "request_ids": list(self.request_ids),
            "token_positions": list(self.token_positions),
            "valid_rows": list(self.valid_rows),
            "expected_request_ids": list(self.expected_request_ids),
            "phase": self.phase,
            "rank": self.rank,
            "tp_size": self.tp_size,
            "allow_single_request": self.allow_single_request,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> BatchRowContext:
        if not isinstance(data, Mapping):
            raise ValueError("context must be a mapping")
        required = {"call_id", "request_ids", "token_positions", "valid_rows", "expected_request_ids"}
        allowed = required | {"phase", "rank", "tp_size", "allow_single_request"}
        if not required.issubset(data) or set(data) - allowed:
            raise ValueError("context contains missing required fields or unknown fields")
        return cls(**dict(data))

    @classmethod
    def from_scheduler(
        cls,
        req_ids: Sequence[str],
        num_scheduled_tokens: Mapping[str, int],
        num_computed_tokens: Mapping[str, int],
        padded_rows: int,
        expected_request_ids: Sequence[str],
        call_id: str,
        rank: int = 0,
        tp_size: int = 1,
        *,
        phase: str = "decode",
        allow_single_request: bool = False,
    ) -> BatchRowContext:
        """Build a context in the actual runner's request order.

        ``padded_rows`` is the TOTAL tensor row count, including valid rows, not
        the number of padding rows to add. Each request must schedule one token.
        Its zero-based token position is ``num_computed_tokens[request_id]``.
        The caller must label the observed phase; scheduling one token by itself
        cannot distinguish decode from a one-token prefill. Computed-token state
        may contain other cached requests, but scheduled-token keys must match
        ``req_ids`` exactly so an unrepresented scheduled request is rejected.
        """
        ids = _request_list(req_ids, "req_ids")
        expected = _request_list(expected_request_ids, "expected_request_ids")
        _nonnegative_int(padded_rows, "padded_rows")
        if not isinstance(num_scheduled_tokens, Mapping) or not isinstance(num_computed_tokens, Mapping):
            raise ValueError("scheduler token counts must be mappings")
        if set(num_scheduled_tokens) != set(ids):
            raise ValueError("scheduled-token keys must exactly match runner req_ids")
        if set(ids) != set(expected):
            raise ValueError("runner req_ids do not match expected_request_ids")
        positions: list[int | None] = []
        for request_id in ids:
            scheduled = _nonnegative_int(num_scheduled_tokens[request_id], "num_scheduled_tokens")
            if scheduled != 1:
                raise ValueError("controlled decode requires one scheduled token per request")
            if request_id not in num_computed_tokens:
                raise ValueError(f"missing computed-token count for {request_id!r}")
            positions.append(_nonnegative_int(num_computed_tokens[request_id], "num_computed_tokens"))
        if padded_rows < len(ids):
            raise ValueError("padded_rows is smaller than the valid decode row count")
        padding = padded_rows - len(ids)
        return cls(
            call_id=call_id,
            request_ids=ids + (None,) * padding,
            token_positions=tuple(positions) + (None,) * padding,
            valid_rows=(True,) * len(ids) + (False,) * padding,
            expected_request_ids=expected,
            phase=phase,
            rank=rank,
            tp_size=tp_size,
            allow_single_request=allow_single_request,
        )


def from_scheduler(
    req_ids: Sequence[str],
    num_scheduled_tokens: Mapping[str, int],
    num_computed_tokens: Mapping[str, int],
    padded_rows: int,
    expected_request_ids: Sequence[str],
    call_id: str,
    rank: int = 0,
    tp_size: int = 1,
    *,
    phase: str = "decode",
    allow_single_request: bool = False,
) -> BatchRowContext:
    """Module-level convenience equivalent to :meth:`BatchRowContext.from_scheduler`."""
    return BatchRowContext.from_scheduler(
        req_ids, num_scheduled_tokens, num_computed_tokens, padded_rows,
        expected_request_ids, call_id, rank, tp_size,
        phase=phase, allow_single_request=allow_single_request,
    )
