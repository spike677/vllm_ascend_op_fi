"""Explicit quantization experiments; importing this package installs no hooks."""
