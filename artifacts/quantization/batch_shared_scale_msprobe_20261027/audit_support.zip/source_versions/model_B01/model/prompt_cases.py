"""Frozen real text candidates and five objective tasks; no activation scaling."""
CASES=[
 {'id':'arithmetic','text':'Calculate 17 + 28. Reply with the integer only, without explaining your reasoning.','expected':'45'},
 {'id':'letter_counts','text':'Count a, b and c in the exact string aabcccbbab. Reply only as a,b,c counts separated by commas, without spaces or explanation.','expected':'3,4,3'},
 {'id':'sort','text':'Sort the integers 19, -3, 7, 0, 12 in increasing order. Reply only with the sorted integers separated by commas, without spaces or explanation.','expected':'-3,0,7,12,19'},
 {'id':'filter_sum','text':'Rows are (year,quantity): (2023,8), (2024,4), (2024,5), (2024,2), (2025,9). Sum quantity only where year=2024 and quantity>=4. Reply with the integer only, without explanation.','expected':'9'},
 {'id':'even_count','text':'How many even integers are in [2,7,12,19,22,35,40,51]? Reply with the integer only, without explanation.','expected':'4'},
]
ORDINARY={'id':'ordinary','text':'Describe in one sentence what a public library does for its local community. Use everyday language.'}
CANDIDATES=[
 ('C00','Translate into English: 清晨的列车穿过山谷，乘客透过窗户看见河流与村庄。保留句子的主要信息。'),
 ('C01','Summarize this weather note in one sentence: A cold front arrives overnight. Rain ends before dawn, but exposed bridges may remain icy during the morning commute.'),
 ('C02','Explain what this Python function returns: def f(xs): return sum(x*x for x in xs if x % 2 == 0). Give a short example using [1,2,3,4].'),
 ('C03','A sensor log reads: t=0.000001 s, v=3.14159265 V; t=0.000002 s, v=-2.71828183 V; t=0.000003 s, v=0.00000001 V. Describe the sign changes.'),
 ('C04','Convert this JSON object to a short sentence: {"region":"west","units":1200,"change_percent":-7.5,"status":"provisional","updated":"2026-10-01"}.'),
 ('C05','Explain this SQL query: SELECT category, COUNT(*) FROM orders WHERE created_at >= DATE \'2026-01-01\' GROUP BY category HAVING COUNT(*) > 10;'),
 ('C06','Read this nucleotide sample and describe its alphabet: ACGTTGCAAGTCCGATGCTAGCTTGACCGTAACGGTTCAGGCTAACGT. Do not infer personal or medical information.'),
 ('C07','Summarize this mathematical identity in plain English: exp(i*pi)+1=0. Mention which familiar constants appear and avoid a long derivation.'),
 ('C08','Explain this regular expression for a beginner: ^[A-Za-z][A-Za-z0-9_]{2,15}$. Describe the allowed first character and total length.'),
 ('C09','A shipment contains 8 boxes of blue pens, 13 boxes of black pens, and 5 boxes of red pens. Each box has 24 pens. Explain how to calculate the total.'),
 ('C10','Compare the meanings of these German words in English: der Bahnhof, die Fahrkarte, der Anschluss, die Verspätung. Use one short sentence for each.'),
 ('C11','请把这段伪代码解释为自然语言：队列非空时取出队首节点，访问该节点，将尚未访问的相邻节点加入队尾。'),
 ('C12','Review this small YAML fragment: service: catalog; replicas: 3; timeout_ms: 2500; retry_limit: 2. Explain how these configuration fields differ.'),
 ('C13','Explain the difference between a byte and a bit. Then explain why a file of 1048576 bytes may be described as one mebibyte.'),
 ('C14','List the first four powers of two greater than 100. Give only the four values, separated by commas.'),
 ('C15','Describe this chess position notation without attempting a move: 8/8/8/3k4/8/3K4/8/8 w - - 0 1. What pieces remain?'),
 ('C16','Explain why a negative feedback loop can stabilize room temperature. Use a thermostat as the example and keep the explanation brief.'),
 ('C17','Proofread this sentence while preserving its meaning: The results was recorded yesterday, and each of the samples were carefully labelled.'),
 ('C18','Describe the structure of this fictional path: /archive/2026/quarter_03/measurements/run_0042/results.json. Do not claim to access any file.'),
 ('C19','Given latitude 31.2304 and longitude 121.4737, explain what latitude and longitude measure. You do not need to identify the city.'),
 ('C20','Explain this JavaScript expression: items.filter(x => x.active).map(x => x.name).join(", "). Describe each stage in one sentence.'),
 ('C21','Read this inventory table: apples=12, pears=7, plums=18, oranges=9. Identify the item with the largest count and state that count.'),
 ('C22','Explain the difference between the fractions 1/3, 0.333, and 33.3 percent. Discuss approximation using ordinary language.'),
 ('C23','将下面的时间安排概括为一句话：09:15开会，10:40检查设备，13:30整理记录，16:05提交报告。不要添加没有列出的活动。'),
]


def score(text,finish_reason,expected):
    # A truncated reasoning trace is never counted as a correct answer merely
    # because the expected digits occurred somewhere inside it.
    answer=text.rsplit('</think>',1)[-1].strip()
    return {'expected':expected,'answer_region':answer,'finish_reason':finish_reason,
            'completed':finish_reason=='stop','exact_correct':finish_reason=='stop' and answer==expected,
            'replacement_characters':text.count('\ufffd'),
            'contains_c0_controls':any(ord(c)<32 and c not in '\n\r\t' for c in text)}
