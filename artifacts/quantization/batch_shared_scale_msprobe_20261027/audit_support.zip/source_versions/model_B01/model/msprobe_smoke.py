"""Standalone real msprobe interface smoke; synthetic data, no model evidence."""
import argparse
import json
import os
from pathlib import Path
from types import SimpleNamespace


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    p.add_argument('--legacy-root',default='/audit/legacy');p.add_argument('--device',default='cpu');args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    os.environ.update(BATCH_OUTLIER_LEGACY_ROOT=args.legacy_root,BATCH_OUTLIER_OUTPUT=str(args.output/'operators'),
                     BATCH_MSPROBE_CAPTURE='1',BATCH_MSPROBE_DUMP_ROOT=str(args.output/'msprobe_dump'))
    from native_capture_hook import legacy_binder
    legacy_binder()
    import torch
    import torch_npu
    from msprobe_capture_bridge import begin,finish
    x=torch.arange(32,device=args.device,dtype=torch.float32).reshape(2,16).to(torch.bfloat16)
    q=x.to(torch.int8);scale=torch.ones(2,device=args.device,dtype=torch.float32)
    rows={'request_ids':['synthetic_P0','synthetic_C0'],'logical_ids':['P0','C0'],'row_token_positions':[5,7]}
    session=begin(SimpleNamespace(model=None),None,'synthetic.interface.only','interface_smoke',0,'healthy',rows,
                  {'synthetic':True,'not_model_validation':True},'interface_smoke:rank0')
    error=None
    try:
        session.record('pair',metadata={'call_id':'interface_smoke:rank0'},tensors={
            'input_x':x,'native_q':q,'native_scale':scale,'returned_q':q.clone(),'returned_scale':scale.clone()})
        session.record('consumer',metadata={'call_id':'interface_smoke:rank0'},tensors={'output':x.clone()})
        session.record_logits(x.float(),metadata={'call_id':'interface_smoke:rank0'})
    except BaseException as exc:
        error=exc;raise
    finally:finish(session,error)
    print(json.dumps({'status':'MSPROBE_REAL_INTERFACE_PASS','model_evidence':False,
                      'manifest':str(session.output_dir/'manifest.json')}))


if __name__=='__main__':main()
