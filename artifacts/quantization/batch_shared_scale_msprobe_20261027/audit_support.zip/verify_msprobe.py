#!/usr/bin/env python3
"""CPU-only verification of genuine msProbe debug tensor capture and TP2 pairs.

Input is the bounded two-case capture, never an automatic API trace:
  operators/pid*.jsonl and canonical .pt files
  msprobe_dump/rank{0,1}/sessions/{generation}/manifest.json
  msprobe_dump/rank{0,1}/native_msprobe/stepN/rankN/debug.json + .debug.pt

H/H1/F/F2/R are mandatory for letter_counts_B2 and even_count_B4. Optional
--off-run checks all nine canonical tensors and complete responses against
independent msprobe-OFF B runs (canonical native observer remains active).
The original dtype storage is decoded by a restricted CPU pickle reader. No
torch, torch_npu, msprobe, model, or accelerator runtime is imported here.
"""
import argparse
from collections import Counter
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import pickle
import re
import sys
import zipfile

import numpy as np

TOOLS = Path(__file__).resolve().parent / "verification_support"
if not TOOLS.is_dir():
    TOOLS = Path(__file__).resolve().parent.parent / "batch_outlier_20261027"
SUPPORT_HASHES = {
    "verify_model_tensors.py": "c5da3d45675d2e58b863e7fda8d2b6f323fe4eb44b683fe60ee14f87ee083a51",
    "verify_quant_probe.py": "60d042bafb7f0a58e2d3fd00884fb238b5e538c7f537263a157f6bf4446f32fa",
}
for support_name, support_digest in SUPPORT_HASHES.items():
    if hashlib.sha256((TOOLS / support_name).read_bytes()).hexdigest() != support_digest:
        raise RuntimeError("Unreviewed verification dependency: " + support_name)
sys.path.insert(0, str(TOOLS))
from verify_model_tensors import read_tensor, verify as verify_canonical
from verify_quant_probe import array, sha, TensorUnpickler, STORAGE, rebuild_tensor
for support_name in SUPPORT_HASHES:
    imported = Path(sys.modules[Path(support_name).stem].__file__).resolve()
    if imported != (TOOLS / support_name).resolve():
        raise RuntimeError("Cached verifier dependency came from a different directory: " + support_name)

CASES = ("letter_counts_B2", "even_count_B4")
LABELS = ("H", "H1", "F", "F2", "R")
PAIR_KEYS = {"input_x", "native_q", "native_scale", "returned_q", "returned_scale"}
SOURCE_HASHES = {
    "msprobe.pytorch.dump.debugger.precision_debugger": "43bb9d834c736ebeb5c7c89e4770c23e1c6fc813000d12aeee8c2b72753a02fb",
    "msprobe.pytorch.dump.pytorch_service": "12799d280f17c82cefeb8463e272376828e2239e6e057dfd4ca8e4cf62ce9036",
    "msprobe.core.dump.service": "d51804b819a07453733e52eb81ec132f2cfa9934bfa5b243aaf7ceecd8ad97b3",
}
METHOD_SHA = "1dd59f6f8114e19824d559b99cc4a22fed04e54ff0ecd9e853aa3b6a574699e2"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path):
    def no_duplicates(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=no_duplicates)


def rebase(path, root, anchor):
    """Only rebase beneath an observed, unique task-owned directory boundary."""
    text = str(path).replace("\\", "/")
    parts = PurePosixPath(text).parts
    require(parts.count(anchor) == 1 and ".." not in parts, "Missing, ambiguous or unsafe path boundary: " + text)
    target = (root / Path(*parts[parts.index(anchor):])).resolve()
    require(target.is_relative_to(root), "Evidence path escaped its run root")
    return target


def generation_key(name):
    match = re.fullmatch(r"(letter_counts_B2|even_count_B4)_(H0|H|H1|F|F2|R|B)", name)
    require(match is not None, "Unexpected generation outside the bounded two-case profile: " + name)
    case, label = match.groups()
    return case, "H" if label == "H0" else label


def exact(a, b):
    return a["dtype"] == b["dtype"] and a["shape"] == b["shape"] and a["raw"] == b["raw"]


def rebuild_msprobe_tensor(storage, offset, size, stride, *extra):
    """Decode the actual NPU-tagged ND archive as bytes, without a device load."""
    dtype, itemsize, payload, count, location = storage
    if location.startswith("npu:"):
        require(offset == 0 and count == int(np.prod(size)), "Padded/view NPU storage is not supported")
        require(len(extra) == 3 and extra[0] is False and not extra[1] and isinstance(extra[2], dict),
                "Unreviewed NPU serialization metadata")
        def dims(values):
            return "/".join(str(n) for n in values) + "/"
        expected = {"npu_format_/ND": True, "origin_format_/ND": True,
                    "storage_sizes_/" + dims(size): True,
                    "base_strides_/" + dims(stride): True,
                    "base_sizes_/" + dims(size): True}
        require(extra[2] == expected, "Only the real contiguous ND NPU serialization layout is accepted")
    return rebuild_tensor((dtype, itemsize, payload, count), offset, size, stride)


class MsprobeTensorUnpickler(TensorUnpickler):
    def find_class(self, module, name):
        if module == "torch._utils" and name in ("_rebuild_tensor", "_rebuild_tensor_v2"):
            return rebuild_msprobe_tensor
        return super().find_class(module, name)

    def persistent_load(self, persistent_id):
        if not isinstance(persistent_id, tuple) or len(persistent_id) != 5 or persistent_id[0] != "storage":
            raise pickle.UnpicklingError("Unapproved persistent storage record")
        _, descriptor, key, location, count = persistent_id
        require(descriptor in STORAGE.values() and location in ("cpu", "npu:0", "npu:1"),
                "Only reviewed CPU or two-rank NPU typed storage is accepted")
        require(isinstance(key, str) and key.isdecimal() and type(count) is int and count > 0,
                "Invalid storage key/count")
        dtype, itemsize = descriptor
        return dtype, itemsize, self.archive.read(self.prefix + "data/" + key), count, location


def read_msprobe_tensor(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "Duplicate tensor ZIP entries")
        pickles = [n for n in names if n.endswith("/data.pkl")]
        require(len(pickles) == 1, "Expected one tensor pickle")
        prefix = pickles[0][:-len("data.pkl")]
        require(archive.read(prefix + "byteorder") == b"little", "Expected explicit little-endian tensor storage")
        tensor = MsprobeTensorUnpickler(io.BytesIO(archive.read(pickles[0])), archive, prefix).load()
    require(isinstance(tensor, dict) and set(tensor) == {"dtype", "shape", "raw"}, "Expected one actual saved tensor")
    return tensor


def row_tensor(tensor, index):
    require(len(tensor["shape"]) >= 1 and 0 <= index < tensor["shape"][0], "Invalid target tensor row")
    size = len(tensor["raw"]) // tensor["shape"][0]
    return {"dtype": tensor["dtype"], "shape": tensor["shape"][1:], "raw": tensor["raw"][index * size:(index + 1) * size]}


def response_map(run):
    requests = run["requests"]
    mapped = {r["logical_id"]: {k: r[k] for k in ("prompt_token_ids", "token_ids", "text", "finish_reason", "logprobs")}
              for r in requests}
    require(len(mapped) == len(requests) and set(mapped) == set(run["logical_ids"]), "Incomplete or duplicate actual responses")
    return mapped


def validate_debug_tensor(info, root, cache):
    """Read a standard msProbe debug index and its exact tensor payload."""
    path = rebase(info["file"], root, "msprobe_dump")
    debug_path = rebase(info["debug_json"], root, "msprobe_dump")
    require(path.parent.name == "dump_tensor_data" and path.parent.parent / "debug.json" == debug_path,
            "Tensor is not in its native debug.json dump_tensor_data directory")
    require(path.name == info["save_name"] + ".0.debug.pt"
            and info["debug_key"] == info["save_name"] + ".0.debug", "Unexpected msProbe debug save naming")
    require(info.get("readback_verified") is True and path.stat().st_size == info["file_bytes"], "Runtime readback or file size missing")
    require(file_sha(path) == info["file_sha256"], "msProbe tensor file SHA mismatch")
    if debug_path not in cache:
        cache[debug_path] = read_json(debug_path), file_sha(debug_path)
    document, digest = cache[debug_path]
    require(digest == info["debug_json_sha256"], "msProbe native debug index SHA mismatch")
    require(set(document) == {"task", "level", "framework", "dump_data_dir", "data"}
            and document["task"] == "tensor" and document["level"] == "debug"
            and document["framework"] == "pytorch", "Not the reviewed native debug tensor format")
    entry = document["data"].get(info["debug_key"])
    require(isinstance(entry, dict) and entry.get("type") == "torch.Tensor", "Native debug index lacks this tensor")
    require(entry["dtype"] == info["dtype"] and entry["shape"] == info["shape"]
            and entry["data_name"] == path.name and PurePosixPath(entry["data_name"]).name == entry["data_name"],
            "Debug tensor identity/dtype/shape differs from manifest")
    require(rebase(document["dump_data_dir"], root, "msprobe_dump") == path.parent, "Native debug dump directory mismatch")
    require(all(k in entry for k in ("Max", "Min", "Mean", "Norm", "requires_grad")), "Native tensor statistics fields are incomplete")
    tensor = read_msprobe_tensor(path)
    require("torch." + tensor["dtype"] == info["dtype"] and list(tensor["shape"]) == info["shape"], "Original saved dtype/shape mismatch")
    require(len(tensor["raw"]) == info["tensor_bytes"] and sha(tensor["raw"]) == info["tensor_sha256"], "msProbe tensor storage bytes mismatch")
    values = array(tensor)
    require(not np.isnan(values).any(), "NaN tensor requires a separate comparison policy")
    require(float(np.max(values)) == entry["Max"] and float(np.min(values)) == entry["Min"], "Native debug min/max differs from stored original tensor")
    return tensor, path, debug_path


def load_canonical(meta, root):
    path = rebase(meta["path"], root, "operators")
    require(file_sha(path) == meta["file_sha256"], "Canonical tensor file SHA mismatch")
    tensor = read_tensor(path)
    require(sha(tensor["raw"]) == meta["logical_sha256"]
            and "torch." + tensor["dtype"] == meta["dtype"] and list(tensor["shape"]) == meta["shape"],
            "Canonical tensor original storage metadata mismatch")
    return tensor


def native_events(root):
    return [json.loads(line) for path in sorted((root / "operators").glob("pid*.jsonl"))
            for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def check_native_context(run, call, events):
    """Check logical contracts without equating random cross-process request IDs."""
    rank, pid = call["rank"], call["pid"]
    binding, scheduler = call["binding_event"], call["scheduler"]
    count = len(run["logical_ids"])
    require(call["generation_id"] == run["generation_id"] and call["mode"] == run["mode"]
            and call["local_feature_domain"] is True and binding["status"] == "COMPLETE"
            and binding["input_unchanged"] is True, "Actual bound call context incomplete")
    require(scheduler["pure_decode"] is True and scheduler["all_expected_present"] is True
            and scheduler["logical_ids"] == run["logical_ids"]
            and scheduler["logits_indices"] == list(range(count))
            and scheduler["counts"] == [1] * count and scheduler["total"] == count
            and scheduler["row_request_indices"] == list(range(count)), "Actual decode row contract differs")
    request_ids = scheduler["request_ids"]
    require(len(request_ids) == len(set(request_ids)) == count
            and call["logical_mapping"] == dict(zip(request_ids, run["logical_ids"])), "Internal/logical request mapping mismatch")
    rows = binding["rows"]
    require(rows["rank"] == rank and rows["tp_size"] == 2 and rows["phase"] == "decode"
            and rows["call_id"] == binding["call_id"]
            and rows["request_ids"] == rows["expected_request_ids"] == request_ids
            and rows["token_positions"] == scheduler["row_token_positions"] == scheduler["computed"]
            and rows["valid_rows"] == [True] * count, "Actual TP2 bound row metadata differs")
    responses = response_map(run)
    require(set(scheduler["prefixes"]) == set(request_ids), "Missing actual scheduler prefixes")
    expected_prefixes = {}
    for index, request_id in enumerate(request_ids):
        prefix = scheduler["prefixes"][request_id]
        logical = call["logical_mapping"][request_id]
        reply = responses[logical]
        require(prefix["logical_id"] == logical and prefix["prompt_tokens"] == reply["prompt_token_ids"]
                and prefix["output_token_ids"] == reply["token_ids"][:len(prefix["output_token_ids"])]
                and prefix["computed_tokens"] == scheduler["computed"][index]
                and scheduler["prompt_lengths"][index] == len(prefix["prompt_tokens"]), "Actual prefix/position differs from response")
        prompt_sha = sha(json.dumps(reply["prompt_token_ids"], separators=(",", ":")).encode())
        require(prefix["prompt_sha256"] == prompt_sha, "Prompt token SHA mismatch")
        expected_prefixes[logical] = {"prompt_sha256": prompt_sha, "output_token_ids": prefix["output_token_ids"]}
    expected_contract = {"input_sha256": binding["input_sha256"], "shape": [count, 13824], "dtype": "torch.bfloat16",
                         "logical_ids": run["logical_ids"], "positions": scheduler["row_token_positions"],
                         "prefixes": expected_prefixes}
    require(call["contract"] == expected_contract, "Frozen actual input and logical prefix contract mismatch")
    require(run["proof"]["contracts"][str(rank)] == call["contract"]
            and [c for c in run["proof"]["calls"] if c["rank"] == rank] == [call], "Result proof differs from original worker call")
    target = run["logical_ids"].index(run["target"])
    require(binding["target_request_id"] == request_ids[target], "Wrong actual target row")
    loaded = [e for e in events if e["event"] == "loaded_layer" and e["pid"] == pid and e["rank"] == rank]
    require(len(loaded) == 1 and loaded[0]["weight_dtype"] == "torch.int8"
            and loaded[0]["weight_shape"] == [13824, 5120] and loaded[0]["tp_size"] == 2
            and loaded[0]["tp_rank"] == rank and loaded[0]["module"] == binding["module"]
            and any(m["sha256"] == METHOD_SHA for m in loaded[0]["method_chain"]), "Actual INT8 layer source identity missing")
    return target


def canonical_call_tensors(root, events, run, rank):
    generation = run["generation_id"]
    selected = [e for e in events if e.get("generation_id") == generation and e.get("rank") == rank]
    pair = [e for e in selected if e["event"] == "native_capture" and e["stage"] == "pair"]
    consumers = [e for e in selected if e["event"] == "native_capture" and e["stage"] == "consumer"]
    logits = [e for e in selected if e["event"] == "first_logits"]
    require(len(pair) == len(consumers) == len(logits) == 1, "Wrong canonical per-call stage cardinality")
    require(pair[0]["ordinal"] == consumers[0]["ordinal"] == 0
            and set(pair[0]["tensors"]) == PAIR_KEYS | {"reference_q", "reference_scale"}
            and set(consumers[0]["tensors"]) == {"output"}, "Wrong canonical tensor inventory")
    require(run["proof"]["logits"][str(rank)] == logits[0]["tensor"], "Result logits proof differs from original worker event")
    metas = {**pair[0]["tensors"], **consumers[0]["tensors"], "logits": logits[0]["tensor"]}
    tensors = {name: load_canonical(meta, root) for name, meta in metas.items()}
    calls = [e for e in selected if e["event"] == "native_bound_call"]
    require(len(calls) == 1, "Missing canonical calibration owner")
    binding = calls[0]["binding_event"]
    native_q, native_scale, reference_q, reference_scale = [array(tensors[n]) for n in
                ("native_q", "native_scale", "reference_q", "reference_scale")]
    calibration = binding["calibration"]
    require(len(calibration["rows"]) == native_q.shape[0], "Missing actual reference calibration row")
    for index, item in enumerate(calibration["rows"]):
        mismatch = int(np.count_nonzero(native_q[index] != reference_q[index]))
        maximum = int(np.max(np.abs(native_q[index].astype(np.int16) - reference_q[index].astype(np.int16))))
        close = bool(np.isclose(native_scale[index], reference_scale[index], rtol=calibration["scale_rtol"], atol=0))
        require(item["row"] == index and item["request_id"] == calls[0]["scheduler"]["request_ids"][index]
                and item["q_exact"] == (mismatch == 0) and item["q_mismatch_count"] == mismatch
                and item["q_max_abs_delta"] == maximum and item["scale_close"] == close
                and item["scale_exact"] == (native_scale[index].tobytes() == reference_scale[index].tobytes()),
                "Recorded reference calibration differs from actual saved tensors")
    return tensors


def validate_msprobe_identity(manifest, root, rank, pid, generation, call):
    require(manifest["schema"] == "ascend_fi.msprobe_capture.v1" and manifest["status"] == "PASS"
            and manifest.get("cleanup_error") is None, "msProbe session did not finalize successfully")
    require(manifest["module"] == call["binding_event"]["module"], "Capture module differs from bound module")
    runtime = manifest["msprobe"]
    require(runtime["version"] == "26.1.0" and runtime["automatic_model_api_dump_requested"] is False,
            "Unreviewed msProbe version or automatic API-hook mode")
    for module, digest in SOURCE_HASHES.items():
        require(runtime["sources"][module]["sha256"] == digest, "Recorded msProbe producer source differs: " + module)
    config = runtime["configuration"]
    require(config["task"] == "tensor" and config["level"] == "debug" and config["async_dump"] is False
            and config["custom_op_namespaces"] == [], "msProbe save-only configuration changed")
    dump_root = rebase(manifest["dump_root"], root, "msprobe_dump")
    require(dump_root == root / "msprobe_dump" / f"rank{rank}" / "native_msprobe", "Runtime dump root is not rank-owned")
    require(rebase(config["dump_path"], root, "msprobe_dump") == dump_root, "Configured dump root differs")
    config_path = dump_root / "capture_config.json"
    require(read_json(config_path) == config and file_sha(config_path) == runtime["config_sha256"], "Actual msProbe configuration file mismatch")
    metadata = manifest["run_metadata"]
    require(metadata["generation_id"] == generation and metadata["rank"] == rank and metadata["pid"] == pid
            and metadata["tp_size"] == 2, "Session generation/rank/process identity mismatch")
    require(metadata["mode"] == call["mode"] and metadata["actual_contract"] == call["contract"],
            "Session mode/frozen actual call contract differs")
    require(metadata["logical_mapping"] == call["logical_mapping"], "Session actual request mapping differs")
    require(metadata["call_id"] == call["binding_event"]["call_id"] and metadata["phase"] == "decode"
            and metadata["scheduler"] == call["scheduler"] and metadata["experiment_mode"] == call["mode"],
            "Session actual decode binding context differs")
    return dump_root


def verify(on_root, off_root=None, source_dir=None):
    require(__debug__ and not sys.flags.optimize, "Evidence checks cannot run with Python optimization")
    root = on_root.resolve()
    result = read_json(root / "result.json")
    require(result["status"] == "completed", "Capture run is incomplete")
    require(result["capture_enabled"] is True and result["mode"] == "capture", "Not a capture-enabled run")
    require(source_dir is not None and source_dir.is_dir(), "Provide the actual frozen model source directory")
    actual_sources = {p.name: file_sha(p) for p in source_dir.glob("*.py")}
    require(actual_sources == result["source_sha256"], "Recorded ON sources differ from actual frozen source files")
    require(result.get("default_disarmed") is True and result.get("no_artificial_amplitude") is True,
            "Expected default-disabled/no-artificial-amplitude contract is missing")
    control = read_json(root / "control.json")
    require(control.get("active") is False and not control.get("armed", False), "Final capture control remains active")
    run_map = {generation_key(run["generation_id"]): run for run in result["runs"]}
    require(len(run_map) == len(result["runs"]) and set(run_map) == {(case, label) for case in CASES for label in LABELS},
            "Incomplete or duplicate H/H1/F/F2/R capture matrix")
    # This checks independent canonical tensor bytes, producer/consumer hashes,
    # target metrics, peer preservation and row-local native scale semantics.
    canonical_review = verify_canonical(root)
    require(canonical_review["status"] == "PASS" and canonical_review["bound_rank_calls"] == 20
            and canonical_review["tensor_files"] == 180
            and len(list((root / "operators").rglob("*.pt"))) == 180,
            "Independent canonical CPU verification failed")
    canonical_rows = {(r["generation_id"], r["rank"]): r for r in canonical_review["records"]}
    events, source_logs = [], []
    for path in sorted((root / "operators").glob("pid*.jsonl")):
        source_logs.append({"path": str(path), "sha256": file_sha(path)})
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                events.append(json.loads(line))
    calls = {(e["generation_id"], e["rank"]): e for e in events if e["event"] == "native_bound_call"}
    require(len(calls) == sum(e["event"] == "native_bound_call" for e in events) == 20, "Duplicate/missing bound call")
    captures, logits = {}, {}
    for event in events:
        key = event.get("generation_id"), event.get("rank")
        if event["event"] == "native_capture":
            ckey = (*key, event["stage"], event.get("ordinal", 0))
            require(ckey not in captures, "Duplicate raw stage/ordinal")
            captures[ckey] = event
        if event["event"] == "first_logits":
            require(key not in logits, "Duplicate first-logits capture")
            logits[key] = event
    manifest_files = set()
    tensor_files, debug_cache, debug_used_keys = set(), {}, {}
    review_records, data = [], {}
    for key, run in run_map.items():
        case, label = key
        generation = run["generation_id"]
        responses = response_map(run)
        target_name = case.rsplit("_", 1)[0]
        require(run["target"] == target_name, "Unexpected target request")
        mode = "shared" if label in ("F", "F2") else "healthy"
        require(run["mode"] == mode, "Matrix label and actual mode differ")
        for rank in (0, 1):
            call = calls[(generation, rank)]
            check_native_context(run, call, events)
            binding, scheduler, pid = call["binding_event"], call["scheduler"], call["pid"]
            require(call["mode"] == mode and call["local_feature_domain"] is True
                    and binding["status"] == "COMPLETE" and binding["input_unchanged"] is True,
                    "Bound quantization call is not complete and unchanged")
            require(scheduler["pure_decode"] is True and scheduler["all_expected_present"] is True
                    and scheduler["logical_ids"] == run["logical_ids"]
                    and scheduler["logits_indices"] == list(range(len(run["logical_ids"]))), "Actual scheduler/logits row mapping mismatch")
            target = scheduler["logical_ids"].index(target_name)
            require(scheduler["request_ids"][target] == binding["target_request_id"], "Actual target row identity mismatch")
            rows = binding["rows"]
            require(rows["rank"] == rank and rows["tp_size"] == 2 and rows["phase"] == "decode"
                    and rows["request_ids"] == scheduler["request_ids"]
                    and rows["token_positions"] == scheduler["row_token_positions"]
                    and all(rows["valid_rows"]), "Bound TP2 decode rows mismatch")
            for request_id, prefix in scheduler["prefixes"].items():
                require(call["logical_mapping"][request_id] == prefix["logical_id"], "Actual internal ID logical mapping differs")
                reply = responses[prefix["logical_id"]]
                require(prefix["prompt_tokens"] == reply["prompt_token_ids"]
                        and prefix["output_token_ids"] == reply["token_ids"][:len(prefix["output_token_ids"])],
                        "Actual scheduler prefix does not match returned request")
            loaded = [e for e in events if e["event"] == "loaded_layer" and e["pid"] == pid and e["rank"] == rank]
            require(len(loaded) == 1 and loaded[0]["weight_dtype"] == "torch.int8"
                    and loaded[0]["weight_shape"] == [13824, 5120] and loaded[0]["tp_size"] == 2
                    and any(m["sha256"] == METHOD_SHA for m in loaded[0]["method_chain"]), "Actual INT8 layer identity missing")
            manifest_path = root / "msprobe_dump" / f"rank{rank}" / "sessions" / generation / "manifest.json"
            manifest = read_json(manifest_path)
            session_refs = [r for r in run["msprobe_sessions"] if r["rank"] == rank]
            require(len(run["msprobe_sessions"]) == 2 and len(session_refs) == 1
                    and rebase(session_refs[0]["manifest"], root, "msprobe_dump") == manifest_path
                    and session_refs[0]["sha256"] == file_sha(manifest_path), "Driver session reference/hash mismatch")
            closed = [e for e in events if e["event"] == "msprobe_session_closed"
                      and e.get("generation_id") == generation and e.get("rank") == rank]
            require(len(closed) == 1 and closed[0]["pid"] == pid
                    and rebase(closed[0]["manifest"], root, "msprobe_dump") == manifest_path, "Missing actual worker session closure")
            dump_root = validate_msprobe_identity(manifest, root, rank, pid, generation, call)
            manifest_files.add(manifest_path)
            records = manifest["records"]
            require(Counter(r["stage"] for r in records) == Counter({"pair": 1, "consumer": 1, "logits": 1})
                    and [r["stage"] for r in records] == ["pair", "consumer", "logits"], "Wrong stage coverage or order")
            collected, payload_bytes, saved_bytes = {}, 0, 0
            for record in records:
                stage, metadata = record["stage"], record["metadata"]
                expected_names = PAIR_KEYS if stage == "pair" else {"output"} if stage == "consumer" else {"logits"}
                require(record["status"] == "SAVED" and set(record["tensors"]) == expected_names, "Missing true msProbe stage tensors")
                require(metadata["call_id"] == binding["call_id"], "msProbe stage is not tied to the actual bound call")
                if stage != "logits":
                    require(metadata["rows"] == rows, "msProbe stage row context differs")
                    for field in ("input_sha256", "q_sha256", "scale_sha256", "native_q_sha256", "native_scale_sha256"):
                        require(metadata[field] == binding[field], "msProbe snapshot differs from complete call: " + field)
                if stage == "consumer":
                    require(metadata["consumers"] == binding["consumers"] and len(binding["consumers"]) == 1,
                            "msProbe consumer identity is not the original completed consumer")
                if stage == "logits":
                    require(metadata["request_ids"] == scheduler["request_ids"], "msProbe logits row mapping differs")
                for name, info in record["tensors"].items():
                    tensor, tensor_path, debug_path = validate_debug_tensor(info, root, debug_cache)
                    require(tensor_path.is_relative_to(dump_root), "Tensor belongs to a different rank runtime")
                    require(tensor_path not in tensor_files, "One stored msProbe tensor is reused across captures")
                    tensor_files.add(tensor_path)
                    used = debug_used_keys.setdefault(debug_path, set())
                    require(info["debug_key"] not in used, "Duplicate msProbe debug entry reference")
                    used.add(info["debug_key"])
                    raw_meta = (logits[(generation, rank)]["tensor"] if stage == "logits"
                                else captures[(generation, rank, stage, 0)]["tensors"][name])
                    canonical = load_canonical(raw_meta, root)
                    require(exact(tensor, canonical), "Actual msProbe tensor differs from canonical raw capture")
                    collected[name] = tensor
                    payload_bytes += len(tensor["raw"])
                    saved_bytes += info["file_bytes"]
            require(payload_bytes == manifest["tensor_bytes"] and saved_bytes == manifest["file_bytes"]
                    and payload_bytes <= manifest["max_bytes"] and saved_bytes <= manifest["max_disk_bytes"],
                    "msProbe raw/disk capture accounting mismatch")
            x, nq, ns, q, s = [array(collected[n]) for n in ("input_x", "native_q", "native_scale", "returned_q", "returned_scale")]
            require(collected["input_x"]["dtype"] == "bfloat16" and nq.dtype == q.dtype == np.dtype("int8")
                    and ns.dtype == s.dtype == np.dtype("float32") and x.shape[1] == 13824,
                    "Actual local TP feature or Q/scale dtype differs")
            peers = [i for i in range(x.shape[0]) if i != target]
            require(q[peers].tobytes() == nq[peers].tobytes() and s[peers].tobytes() == ns[peers].tobytes(), "Actual non-target Q/scale changed")
            require(binding["artificial_multiplier"] == 1.0 and binding["non_target_pair_preserved"] is True, "Artificial amplitude or peer substitution detected")
            if mode == "healthy":
                require(exact(collected["native_q"], collected["returned_q"])
                        and exact(collected["native_scale"], collected["returned_scale"]), "Healthy path altered native pair")
            else:
                require(binding["target_calibration"]["qualified"] is True, "Replaced target failed reference calibration")
                maximum = np.max(np.abs(x.astype(np.float32)))
                target_maximum = np.max(np.abs(x[target].astype(np.float32)))
                if maximum > target_maximum:
                    require(np.isclose(s[target], np.float32(maximum / np.float32(127)), rtol=1e-6, atol=0), "Fault target scale did not come from actual same-call rank-local batch")
                    reference = np.clip(np.rint(x[target].astype(np.float32) / s[target]), -128, 127).astype(np.int8)
                    require(reference.tobytes() == q[target].tobytes(), "Returned target Q does not use its actual replacement scale")
                else:
                    require(q.tobytes() == nq.tobytes() and s.tobytes() == ns.tobytes(), "Rank with no external range changed its native pair")
            consumer = binding["consumers"][0]
            require(consumer["api"] == "npu_quant_matmul" and consumer["same_q_object"] is True
                    and consumer["same_scale_object"] is True and consumer["q_sha256"] == sha(collected["returned_q"]["raw"])
                    and consumer["scale_sha256"] == sha(collected["returned_scale"]["raw"])
                    and consumer["output_sha256"] == sha(collected["output"]["raw"]), "Original consumer did not consume this exact pair")
            require(collected["logits"]["shape"] == (len(run["logical_ids"]), 152064), "Actual logits row shape differs")
            data[(case, label, rank)] = {"tensors": collected, "target": target, "contract": call["contract"], "run": run,
                                         "canonical": canonical_call_tensors(root, events, run, rank),
                                         "raw_metrics": canonical_rows[(generation, rank)]}
            review_records.append({"case": case, "label": label, "generation_id": generation, "rank": rank, "pid": pid,
                                   "manifest": str(manifest_path), "manifest_sha256": file_sha(manifest_path),
                                   "target_row": target, "actual_mode": mode, "msprobe_tensors": 7,
                                   "same_as_canonical_raw_storage": True,
                                   "native_peer_reference_q_mismatches": sum(r["q_mismatch_count"] for r in binding["calibration"]["rows"] if not r["is_target"]),
                                   "target_reference_qualified": binding["target_calibration"]["qualified"],
                                   "metrics": canonical_rows[(generation, rank)]})
    require(manifest_files == set((root / "msprobe_dump").glob("rank*/sessions/*/manifest.json")), "Unexpected/missing msProbe session manifest")
    require(tensor_files == set((root / "msprobe_dump").rglob("*.pt")), "Unreferenced or missing native msProbe tensor payload")
    require(set(debug_cache) == set((root / "msprobe_dump").rglob("debug.json")), "Unreferenced native msProbe debug index")
    for path, (document, _) in debug_cache.items():
        require(set(document["data"]) == debug_used_keys[path], "Native debug index contains unaccounted tensors")
    comparisons = []
    for case in CASES:
        for rank in (0, 1):
            h, f = data[(case, "H", rank)], data[(case, "F", rank)]
            for first, second in (("H", "H1"), ("F", "F2"), ("H", "R")):
                left, right = data[(case, first, rank)], data[(case, second, rank)]
                require(left["contract"] == right["contract"], "Repeated/recovery frozen call contract changed")
                require(all(exact(left["tensors"][k], right["tensors"][k]) for k in left["tensors"]), "msProbe raw repetition/recovery differs")
                require(all(exact(left["canonical"][k], right["canonical"][k]) for k in left["canonical"]),
                        "Canonical raw repetition/recovery differs")
                require(response_map(left["run"]) == response_map(right["run"]), "Complete responses differ on repeat/recovery")
            require(h["contract"] == f["contract"] and exact(h["tensors"]["input_x"], f["tensors"]["input_x"]), "Fault run has different upstream input/context")
            hl = array(row_tensor(h["tensors"]["logits"], h["target"])).astype(np.float64)
            fl = array(row_tensor(f["tensors"]["logits"], f["target"])).astype(np.float64)
            with np.errstate(invalid="ignore"):
                delta = np.where(hl == fl, 0.0, hl - fl)
            require(not np.isnan(delta).any(), "Undefined logits comparison")
            metrics = f["raw_metrics"]
            g2 = metrics["scale_ratio"] > 1 and metrics["changed_codes"] > 0 and metrics["returned_mse"] > metrics["native_mse"]
            comparisons.append({"case": case, "rank": rank, "healthy_repeat_exact": True, "fault_repeat_exact": True,
                                "recovery_exact": True, "healthy_fault_input_exact": True,
                                "G2_target_activation_damage": g2, "target_logits_changed": bool(np.any(delta != 0)),
                                "target_logits_max_abs_delta": float(np.max(np.abs(delta))),
                                "G3_repeatable_target_logits": g2 and bool(np.any(delta != 0))})
    transparency = {"status": "NOT_ASSESSED", "scope": "No independent observer-OFF run supplied"}
    if off_root:
        off_root = off_root.resolve()
        off = read_json(off_root / "result.json")
        require(off["status"] == "completed" and off["capture_enabled"] is False and off["mode"] == "baseline"
                and off["fault_permission"] is False, "OFF baseline incomplete or msprobe/fault was enabled")
        for field in ("model", "layer", "prior_result_sha256", "source_sha256", "conditions", "max_tokens", "prompts"):
            require(off[field] == result[field], "OFF/ON frozen identity differs: " + field)
        require(result["baseline_result_sha256"] == file_sha(off_root / "result.json"), "ON did not bind this exact baseline result")
        require(off["default_disarmed"] is True and off["no_artificial_amplitude"] is True,
                "Baseline default-disabled/no-amplitude contract missing")
        off_control = read_json(off_root / "control.json")
        require(off_control["active"] is False and off_control["armed"] is False, "OFF baseline final control active")
        require(not (off_root / "msprobe_dump").exists(), "OFF baseline contains unexpected msprobe dump")
        off_runs = {generation_key(r["generation_id"]): r for r in off["runs"]}
        require(len(off_runs) == len(off["runs"]) == 2 and set(off_runs) == {(case, "B") for case in CASES},
                "OFF baseline must contain exactly the two real B runs")
        off_review = verify_canonical(off_root)
        require(off_review["status"] == "PASS" and off_review["bound_rank_calls"] == 4 and off_review["tensor_files"] == 36,
                "Independent baseline canonical verification incomplete")
        off_events = native_events(off_root)
        off_calls = {(e["generation_id"], e["rank"]): e for e in off_events if e["event"] == "native_bound_call"}
        require(len(off_calls) == sum(e["event"] == "native_bound_call" for e in off_events) == 4, "Wrong baseline native call cardinality")
        off_records = []
        for case in CASES:
            baseline = off_runs[(case, "B")]
            require(baseline["mode"] == "healthy" and baseline["msprobe_sessions"] == [], "Baseline mode/session record differs")
            require(response_map(baseline) == response_map(run_map[(case, "H")]), "Observer OFF/ON actual responses differ")
            for rank in (0, 1):
                call = off_calls[(baseline["generation_id"], rank)]
                check_native_context(baseline, call, off_events)
                no_import = [e for e in off_events if e["event"] == "msprobe_baseline_not_imported"
                             and e.get("generation_id") == baseline["generation_id"] and e.get("rank") == rank]
                require(len(no_import) == 1 and no_import[0]["pid"] == call["pid"], "Missing actual baseline worker msprobe-not-imported gate")
                healthy = data[(case, "H", rank)]
                require(call["contract"] == healthy["contract"], "Independent B/H actual full logical contract differs")
                before = canonical_call_tensors(off_root, off_events, baseline, rank)
                require(set(before) == set(healthy["canonical"])
                        and all(exact(tensor, healthy["canonical"][name]) for name, tensor in before.items()),
                        "Independent B/H original input/Q/scale/consumer/logits storage differs")
                off_records.append({"case": case, "rank": rank, "baseline_generation_id": baseline["generation_id"],
                                    "capture_generation_id": healthy["run"]["generation_id"], "canonical_tensors_exact": 9,
                                    "full_logical_contract_exact": True, "full_response_exact": True,
                                    "baseline_worker_msprobe_not_imported_recorded": True,
                                    "tensor_logical_sha256": {name: sha(tensor["raw"]) for name, tensor in before.items()}})
        transparency = {"status": "RAW_AND_RESPONSE_EXACT", "cases": list(CASES), "off_result": str(off_root / "result.json"),
                        "off_result_sha256": file_sha(off_root / "result.json"),
                        "canonical_tensor_files": off_review["tensor_files"], "bound_rank_calls": off_review["bound_rank_calls"],
                        "frozen_identity_fields_equal": ["model", "layer", "prior_result_sha256", "source_sha256", "conditions", "max_tokens", "prompts"],
                        "records": off_records,
                        "scope": "Independent msprobe-OFF B still uses the canonical native observer. B/H full logical input/prefix contracts, all nine original-dtype tensors (input, native/returned/reference Q and scale, local consumer contribution, first logits), complete returned prompt/output IDs, text, finish reason and top-5 logprobs are equal. This bounded observation does not prove absence of all global instrumentation side effects."}
    return {"schema": "batch_outlier_msprobe_cpu_verification_v1", "status": "PASS",
            "scope": "Real msProbe 26.1 debug tensor save records, original dtype bytes, canonical native producer/consumer identity and mapped TP2 outputs. Not automatic API-hook dump or independent ACLNN kernel tracing.",
            "capture_type": "PrecisionDebugger.save: debug.json and .debug.pt", "automatic_api_hook_capture": False,
            "sessions": len(manifest_files), "ranks": [0, 1], "cases": list(CASES), "labels": list(LABELS),
            "msprobe_tensor_files": len(tensor_files), "debug_json_files": len(debug_cache),
            "canonical_tensor_files": canonical_review["tensor_files"], "bound_rank_calls": canonical_review["bound_rank_calls"],
            "all_msprobe_raw_bytes_match_canonical": True, "observer_transparency": transparency,
            "records": review_records, "comparisons": comparisons, "source_logs": source_logs,
            "actual_frozen_source_directory": str(source_dir.resolve()), "actual_frozen_source_sha256": actual_sources,
            "verification_support": {name: {"path": str((TOOLS / name).resolve()), "sha256": digest}
                                     for name, digest in SUPPORT_HASHES.items()},
            "on_result_sha256": file_sha(root / "result.json"), "verifier_source_sha256": file_sha(__file__),
            "limitations": ["Recorded msProbe producer source hashes are pinned; file format alone is not cryptographic producer attestation.",
                            "Reference rounding may differ on real peer activations; only replaced target calibration is a strict gate.",
                            "Per-rank local TP feature range only; no artificial multiplier or added cross-rank maximum.",
                            "A logits or token change is not an objective answer error; no full-answer quality claim is made by this capture verifier."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--on-run", type=Path, required=True)
    parser.add_argument("--off-run", type=Path)
    parser.add_argument("--source-dir", type=Path, required=True, help="Actual archived/frozen model source used by BOTH runs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "Refusing to overwrite an existing verification result")
    report = verify(args.on_run, args.off_run.resolve() if args.off_run else None, args.source_dir.resolve())
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({k: report[k] for k in ("status", "sessions", "msprobe_tensor_files", "debug_json_files", "bound_rank_calls", "observer_transparency")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
