"""Install/restore a bounded file bind over Docker CLI; original bytes intact."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import time

BASE = Path('/home/fault28-fullop-graph-20261110/resource_lease')
TARGET = Path('/usr/bin/docker')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):
            h.update(block)
    return h.hexdigest()


def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')


def mount_id():
    matches = [line.split() for line in Path('/proc/self/mountinfo').read_text().splitlines()
               if line.split()[4] == str(TARGET)]
    if len(matches)>1:
        raise RuntimeError('Multiple Docker CLI mounts; refusing to replace/unmount')
    return matches[0][0] if matches else None


def restore_unlocked(root):
    receipt = json.loads((root/'install_receipt.json').read_text())
    if (root/'restore_receipt.json').exists():
        return json.loads((root/'restore_receipt.json').read_text())
    current = mount_id()
    if current is not None:
        assert current == receipt['mount_id'] and sha(TARGET) == receipt['wrapper_sha256']
        subprocess.run(['umount',str(TARGET)],check=True)
    assert mount_id() is None and sha(TARGET) == receipt['original_sha256']
    assert TARGET.stat().st_uid == receipt['original_uid'] and (TARGET.stat().st_mode&0o7777) == receipt['original_mode']
    assert TARGET.stat().st_gid == receipt['original_gid'] and TARGET.stat().st_ino == receipt['original_inode']
    result = {'status':'RESTORED_ORIGINAL_DOCKER_CLI','time':time.time(),
              'original_sha256':sha(TARGET),'file_bind_removed':True,
              'daemon_or_SSH_configuration_changed':False}
    save(root/'restore_receipt.json',result)
    return result


def restore(root):
    with (root/'restore.lock').open('a') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
        return restore_unlocked(root)


def install(root,seconds):
    assert 300 <= seconds <= 3600 and os.geteuid() == 0
    assert not root.exists() and root.parent.resolve() == BASE.resolve()
    assert mount_id() is None and not TARGET.is_symlink()
    root.mkdir(mode=0o755)
    original_stat = TARGET.stat()
    backup = root/'docker.real'
    shutil.copy2(str(TARGET),str(backup))
    original = sha(TARGET)
    assert sha(backup) == original
    wrapper = root/'docker.wrapper'
    wrapper.write_text('#!/usr/bin/python3\nimport sys\nsys.path.insert(0,'+repr(str(BASE))+')\nimport docker_guard\nraise SystemExit(docker_guard.main('+repr(str(root))+'))\n')
    wrapper.chmod(0o755)
    key = secrets.token_hex(32)
    state = {'schema':'fault28.card2_resource_lease.v1','card':2,'task':'fault28-fullop-graph-20261110',
             'created_at':time.time(),'expires_at':time.time()+seconds,'token_sha256':hashlib.sha256(key.encode()).hexdigest(),
             'authorization':'User explicitly requested isolation from external stop and ATK interference until B/F collection completes.'}
    save(root/'lease.json',state)
    (root/'lease.json').chmod(0o444)
    fd = os.open(str(root/'credential.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:
        json.dump({'key':key},stream)
    bound = False
    try:
        subprocess.run(['mount','--bind',str(wrapper),str(TARGET)],check=True)
        bound = True
        receipt = {'schema':'fault28.card2_resource_lease_install.v1','status':'INSTALLED_BOUNDED_CARD2_CLI_LEASE',
                   'time':time.time(),'expires_at':state['expires_at'],'card':2,'target':str(TARGET),
                   'mount_id':mount_id(),'original_sha256':original,'wrapper_sha256':sha(wrapper),
                   'original_uid':original_stat.st_uid,'original_gid':original_stat.st_gid,
                   'original_inode':original_stat.st_ino,'original_mode':original_stat.st_mode&0o7777,
                   'policy_sha256':sha(BASE/'docker_guard.py'),'installer_sha256':sha(Path(__file__)),
                   'token_sha256':state['token_sha256'],
                   'scope':'Only selected-card allocations/capture-container mutations; read-only commands and unrelated devices delegate.',
                   'daemon_or_SSH_configuration_changed':False,
                   'limitation':'Observed Docker CLI callers; not a defense against privileged direct Docker-API or host-PID callers.'}
        assert receipt['mount_id'] and sha(TARGET) == receipt['wrapper_sha256']
        save(root/'install_receipt.json',receipt)
        with (root/'watchdog.log').open('x') as stream:
            watcher = subprocess.Popen(['/usr/bin/python3',str(Path(__file__)), 'watch','--directory',str(root)],
                stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        save(root/'watchdog_identity.json',{'pid':watcher.pid,'start_ticks':Path('/proc',str(watcher.pid),'stat').read_text().rsplit(')',1)[1].split()[19]})
        return receipt
    except BaseException:
        if bound:
            subprocess.run(['umount',str(TARGET)],check=True)
        assert sha(TARGET) == original
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('install','restore','watch'))
    parser.add_argument('--directory',type=Path,required=True)
    parser.add_argument('--seconds',type=int,default=2700)
    args = parser.parse_args()
    assert args.directory.parent.resolve() == BASE.resolve()
    if args.action == 'install':
        result = install(args.directory,args.seconds)
    elif args.action == 'restore':
        (args.directory/'RELEASE').write_text('Explicit release after authorized capture work.\n')
        result = restore(args.directory)
    else:
        state = json.loads((args.directory/'lease.json').read_text())
        while time.time() < state['expires_at'] and not (args.directory/'RELEASE').exists():
            time.sleep(1)
        result = restore(args.directory)
    print(json.dumps(result))


if __name__ == '__main__':
    main()
