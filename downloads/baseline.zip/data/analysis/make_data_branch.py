"""Build the reviewed data-only publication tree; does not mutate git refs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import zipfile


def extended(path):
    path = path.absolute()
    return Path('\\\\?\\'+str(path)) if os.name == 'nt' and not str(path).startswith('\\\\?\\') else path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data', type=Path, required=True)
    p.add_argument('--destination', type=Path, required=True)
    a = p.parse_args()
    data, out = extended(a.data).resolve(strict=True), extended(a.destination)
    assert not out.exists()
    files = sorted(p for p in data.rglob('*') if p.is_file())
    sums = {}
    for line in (data/'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert name not in sums
        sums[name] = digest
    assert {p.relative_to(data).as_posix() for p in files} == set(sums)|{'SHA256SUMS'}
    for path in files:
        if path.name != 'SHA256SUMS':
            assert sha(path) == sums[path.relative_to(data).as_posix()]
    acceptance = json.loads((data/'reports/acceptance.json').read_bytes())
    lease = json.loads((data/'resource_lease/operation_summary.json').read_bytes())
    assert lease['restored'] is True and lease['raw_credential_exported'] is False
    assert acceptance['status'] == 'PASS_RECOLLECTION_WITH_OBSERVABILITY_LIMITS'
    assert {p.name for p in (data/'cases').iterdir()} == {'baseline','fault'}
    independent = json.loads((data/'reports/restored_independent_first_difference.json').read_bytes())
    out.mkdir(parents=True)
    (out/'downloads').mkdir()
    archives, previews, indexes, observations = [], [], [], {}
    for role in ('baseline','fault'):
        selected = [p for p in files if p.relative_to(data).parts[:2] == ('cases',role)
                    or (role == 'baseline' and p.relative_to(data).parts[0] != 'cases')]
        archive = out/'downloads'/(role+'.zip')
        with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
            for path in selected:
                name = 'data/'+path.relative_to(data).as_posix()
                entry = zipfile.ZipInfo(name, date_time=(2026,11,10,0,0,0))
                entry.compress_type = zipfile.ZIP_DEFLATED
                entry.external_attr = 0o100644 << 16
                stream.writestr(entry, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        archives.append({'role': role, 'path': 'downloads/'+role+'.zip',
                         'bytes': archive.stat().st_size, 'sha256': sha(archive),
                         'files': len(selected), 'includes_common_verification_files': role == 'baseline'})
        case = data/'cases'/role
        names = ['case.json','config.json','graph_config.json','collector_provenance.json',
                 'statistics_receipt.json','native_csv_inventory.json']
        names += [f'observation/step{step}/rank0/{kind}.json' for step in (0,1) for kind in ('dump','stack','construct')]
        for name in names:
            source, target = case/name, out/role/name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            previews.append({'published': role+'/'+name, 'original': 'cases/'+role+'/'+name,
                             'bytes': target.stat().st_size, 'sha256': sha(target)})
        for step in (0,1):
            rel = f'cases/{role}/derived/step{step}/rank0/operators.json'
            source = data/rel
            d = json.loads(source.read_bytes())
            path = f'{role}/derived/step{step}/rank0/index.json'
            save(out/path, {'schema': 'fault28.DERIVED_GE_operator_index.v1',
                            'generated_index': True, 'is_native_msprobe_dump_json': False,
                            'source': 'data/'+rel, 'source_sha256': sha(source),
                            **{k: d[k] for k in ('actual_graph_call_id','actual_msprobe_step','all_optimized_graph_nodes','model_graph_native_csv_files','status_counts','unobservable_node_types')},
                            'operators': [{k: op[k] for k in ('graph_index','name','type','status')} for op in d['operators']],
                            'detail': 'Full descriptors, original statistics, source provenance and missing boundaries are in the ZIP operators.json, not omitted from delivery.'})
            indexes.append({'published': path, 'original': rel})
            if step == 0:
                observations[role] = {k: d[k] for k in ('all_optimized_graph_nodes','model_graph_native_csv_files','status_counts','unobservable_node_types')}
    first = []
    for step, record in enumerate(independent['independent_first_producer']):
        first.append({'step': step, 'first': record['first'],
                      'native_csv_missing_nodes_before_chosen_first': record['native_csv_missing_nodes_before_chosen_first'],
                      'prior_native_unobservable_boundary_count': len(record['prior_native_unobservable_fields']),
                      'scope': record['scope']})
    summary = {'schema': 'fault28.fullgraph_independent_first_difference.public_summary.v2',
               'generated_summary': True, 'steps': first,
               'native_GE_CSV_first': [{'call': row['call'], 'status': row['status'],
                                        'first': row['first_observed_difference']} for row in independent['ge']],
               'all_steps_same_first_node': len({r['first']['node'] for r in first}) == 1,
               'full_report': 'data/reports/restored_independent_first_difference.json',
               'full_report_sha256': sha(data/'reports/restored_independent_first_difference.json'),
               'observation_coverage': observations, 'limits': independent['limits'],
               'all_prior_tensors_proven_equal': False, 'unique_physical_root_cause_proven': False}
    save(out/'reports/independent_first_difference.json', summary)
    save(out/'first_difference.json', summary)
    for name in ('acceptance.json','complete_output_comparison.json'):
        source = data/'reports'/name
        target = out/'reports'/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        previews.append({'published': 'reports/'+name, 'original': 'reports/'+name,
                         'bytes': target.stat().st_size, 'sha256': sha(target)})
    shutil.copyfile(Path(__file__).with_name('verify_downloads.py'), out/'verify_downloads.py')
    manifest = {'schema': 'fault28.fia_fullgraph_operator_statistics.data_branch.v2',
                'branch': 'codex/fault28-fia-statistics-data-20261110',
                'group_names': ['baseline','fault'], 'case_ids': ['baseline','fault'],
                'actual_steps': [0,1], 'actual_warmup_calls': [0], 'actual_compiled_graph_calls': [0,1,2],
                'physical_card': acceptance['physical_card'],
                'temporary_card2_lease': lease,
                'source': {'implementation_parent_commit': '6dad85c480255829b0a4e74657a7e2ff2ce390b3',
                           'data_sha256sums_sha256': sha(data/'SHA256SUMS'),
                           'source_mapping_sha256': sha(data/'source_mapping.json')},
                'data_files': len(files), 'data_bytes': sum(p.stat().st_size for p in files),
                'archives': archives, 'previews': previews, 'derived_indexes': indexes,
                'capture_date': '2026-11-10', 'raw_statistics_bytes_changed': False,
                'real_single_FIA_graph': True, 'converted_JSON_is_native_msprobe_dump': False,
                'observation_coverage': observations, 'limits': acceptance['limits']}
    save(out/'manifest.json', manifest)
    numerical = json.loads((data/'reports/complete_output_comparison.json').read_bytes())
    first_record = first[0]['first']
    first_edge = first_record.get('graph_edge', first_record['node']+':'+str(first_record['index']))
    fields = '\n'.join(f"| `{v.get('path',v.get('field'))}` | `{v['B']}` | `{v['F']}` |" for v in first_record['fields'])
    README = f'''# 故障28：完整模型FIA整图的B/F逐算子统计

这是2026-11-10在124物理卡{acceptance['physical_card']}的新采集。仅保留`baseline`、`fault`两组；两组都是完整Qwen3-0.6B的真实单一FIA GE fullgraph，Batch8、2048-token causal prefill、FP16。原始statistics/mix保留真实step0、step1，不改写成单一step，也不将warmup冒充生成token。

用户已选择“原生GE逐算子统计＋明确标注为转换结果的逐算子JSON”。B/F统一关闭GraphFusion和UBFusion，提高逐算子可见度；这与旧版融合开启的采集有区别。TorchAir FX dump会回退eager，本次未使用。原始module dump仍是GraphBoundary记录，内部算子的来源是原生GE CSV，派生JSON明确标记`is_native_msprobe_dump_json=false`。

下载[baseline.zip](downloads/baseline.zip)及[fault.zip](downloads/fault.zip)。两个ZIP合并恢复到`data/cases/baseline`和`data/cases/fault`；baseline.zip同时包含共同分析源码、报告、构建/collector身份及校验清单。网页的小JSON是原始预览或明确派生的索引，完整内容均在ZIP中。

```text
data/cases/<baseline|fault>/
  observation/step0/rank0/{{dump,stack,construct}}.json  原生module统计
  observation/step1/rank0/{{dump,stack,construct}}.json
  msprobe_graph/raw/graph_1/1/<0|1|2>/*.csv            全部模型GE统计
  msprobe_graph/auxiliary/*.csv                      观察器辅助统计
  derived/step0/rank0/operators.json                 明确派生的逐算子详情
  derived/step1/rank0/operators.json
  derived/warmup/rank0/operators.json
```

## 首个可观测差异

独立复核的step0、step1首差均为`{first_record['node']}`（`{first_record['type']}`）的`{first_record['boundary']}`，输出索引{first_record['index']}。实际来源为`{first_record['source']}`，对应GE输出边`{first_edge}`；不使用注入命中日志或期望profile指定首差。

| 原始字段/序列化路径 | baseline | fault |
| --- | --- | --- |
{fields}

详见[独立首差报告](reports/independent_first_difference.json)。其完整逐项比较、不可观测项及原始文件SHA在ZIP的`data/reports/restored_independent_first_difference.json`中。高精度依据为统一披露的CPU-FP64 module collector及真实GE输出别名；原生GE CSV保持原来的舍入精度，不能单独声称高精度首差。

每组的优化图共{observations['baseline']['all_optimized_graph_nodes']}个节点，每次图执行有{observations['baseline']['model_graph_native_csv_files']}份模型CSV；覆盖状态逐组记录于[manifest](manifest.json)。所有节点均索引，缺失/NA/null/空输出保持不可观测。`Const`、形状节点和冗余操作可能没有独立CSV，统计相等也不能证明完整张量相等。

## 实际机制与验证范围

B/F共用模型、请求、causal尾块规则、collector和融合配置。正常B选择M512，受控F选择M128，均由真实host生成依赖tiling并运行真实FIA kernel；不改写Q/K/V或输出。独立机制审查验证最终public raw/POD、编译元数据和真实节点/任务/迭代证据。host编译命中计数不等于模型运行覆盖。

两组共6次完整图执行、168次FIA节点执行，覆盖28层及全部8请求行。每组三次forward的全部113个返回张量重复一致。对完整8请求数组的独立精确比较确认首个变化Attention的Q/K/V一致，Attention差异传播到{numerical['logits_changed_requests']}个请求的首token logits；Top-1变化请求数为{numerical['top1_changed_requests']}。[完整数组比较摘要](reports/complete_output_comparison.json)仅提供计数和必要小索引，不上传完整张量。

本次按用户明确授权，在采集期间使用临时卡2Docker-CLI资源租约，保护本轮容器并拒绝新增卡2任务；实际运行中拦截的操作统计保存在ZIP的`data/resource_lease/operation_summary.json`。采集验收后已解除文件绑定，原Docker入口SHA256恢复为`{lease['original_binary_sha256']}`。Docker daemon、SSH配置及模型数值路径没有修改。该租约针对已确认的CLI清理/派发路径；私有凭据和原始可执行文件不上传。

这是本轮B8受控策略和统计可见性的补采验收。没有重新测试默认SDPA等价性、B1/B8完整因果矩阵、连续生成、任务正确率或新的OFF组。不能唯一归因到某条Reduce指令，也不能认定复刻历史盘古版本缺陷。此前外部stop/kill中断的attempt未混入这两组数据。

## 本地核验

```bash
python verify_downloads.py --extract-to restored
python restored/data/analysis/graph_evidence.py --baseline restored/data/cases/baseline --fault restored/data/cases/fault --output independent_recheck.json
```

`verify_downloads.py`核对两个ZIP、完整清单、原始字节、网页预览及派生索引。完整私有张量、权重、编译二进制和多GB DEBUG日志不在公开数据中。ZIP中保留全部实际采集的原生CSV、两步原生triplets、真实图、派生逐算子JSON和独立报告，未按首差算子筛选输出。
'''
    (out/'README.md').write_text(README, encoding='utf-8', newline='\n')
    all_files = sorted(p for p in out.rglob('*') if p.is_file())
    (out/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.relative_to(out).as_posix()+'\n' for p in all_files), encoding='utf-8')
    print(json.dumps({'status': 'BUILT_TWO_GROUP_DATA_ONLY_TREE', 'destination': str(out),
                      'files': len(all_files)+1, 'data_files': len(files), 'archives': archives}))


if __name__ == '__main__':
    main()
