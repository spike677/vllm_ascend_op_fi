"""Publish only a reviewed data staging tree, preserving source HEAD/index."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

BRANCH = 'codex/fault28-fia-statistics-data-20261110'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--staging',type=Path,required=True)
    p.add_argument('--expected-parent',required=True)
    p.add_argument('--receipt',type=Path,required=True)
    a = p.parse_args()
    repo = Path.cwd().resolve()
    stage = a.staging.absolute()
    assert not a.receipt.exists()
    def run(args,env=None,data=None):
        q = subprocess.run(args,cwd=repo,env=env,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if q.returncode:
            raise RuntimeError(q.stderr.decode('utf-8',errors='replace'))
        return q.stdout
    gitdir = Path(run(['git','rev-parse','--absolute-git-dir']).decode().strip())
    current = run(['git','symbolic-ref','--short','HEAD']).decode().strip()
    assert current != BRANCH
    head = run(['git','rev-parse','HEAD']).decode().strip()
    original_index = digest(gitdir/'index')
    ref = 'refs/heads/'+BRANCH
    remote = run(['git','ls-remote','origin',ref]).decode().strip().split()[0]
    assert remote == a.expected_parent, 'Remote data branch changed; inspect before publishing.'
    assert run(['git','rev-parse',ref]).decode().strip() == a.expected_parent
    files = {f.relative_to(stage).as_posix():f for f in stage.rglob('*') if f.is_file()}
    allowed_root = {'README.md','SHA256SUMS','manifest.json','first_difference.json','verify_downloads.py'}
    assert files and all(name.split('/')[0] in {'baseline','fault','downloads','reports'} or name in allowed_root for name in files)
    assert not any(f.is_symlink() for f in files.values())
    manifest = json.loads((stage/'manifest.json').read_bytes())
    assert manifest['physical_card'] == 2 and manifest['group_names'] == ['baseline','fault']
    assert manifest['temporary_card2_lease']['restored'] is True
    assert json.loads((stage/'reports/acceptance.json').read_bytes())['status'] == 'PASS_RECOLLECTION_WITH_OBSERVABILITY_LIMITS'
    import importlib.util
    spec = importlib.util.spec_from_file_location('fault28_data_verify',stage/'verify_downloads.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    verified = verifier.verify(stage)
    index = a.receipt.with_suffix('.index').absolute()
    assert not index.exists()
    env = dict(os.environ,GIT_INDEX_FILE=str(index))
    base = ['git','-C',str(stage),'--git-dir',str(gitdir),'--work-tree',str(stage),
            '-c','core.autocrlf=false','-c','core.safecrlf=false','-c','core.longpaths=true']
    run(base+['read-tree','--empty'],env)
    run(base+['add','-f','--all','--','.'],env)
    entries = run(base+['ls-files','--stage','-z'],env).split(b'\0')
    blobs = {}
    for entry in entries:
        if not entry:
            continue
        header,name = entry.split(b'\t',1)
        mode,oid,number = header.decode().split()
        assert number == '0' and mode == '100644'
        rel = name.decode('utf-8')
        payload = files[rel].read_bytes()
        expected = hashlib.sha1(b'blob '+str(len(payload)).encode()+b'\0'+payload).hexdigest()
        assert oid == expected, 'Git normalization changed original bytes: '+rel
        blobs[rel] = oid
    assert set(blobs) == set(files)
    run(base+['diff','--cached','--check',a.expected_parent],env)
    tree = run(base+['write-tree'],env).decode().strip()
    message = ('Collect complete fault28 FIA graph statistics on card2\n\n'
               'Replace the data-only branch with the newly captured baseline/fault pair, all native GE CSV, '
               'explicitly derived per-operator JSON and independently checked first difference. '
               'Retain unobservable fields and document the restored temporary card2 resource lease.\n')
    commit = run(['git','commit-tree',tree,'-p',a.expected_parent],data=message.encode()).decode().strip()
    run(['git','update-ref',ref,commit,a.expected_parent])
    run(['git','push','origin',commit+':'+ref])
    published = run(['git','ls-remote','origin',ref]).decode().strip().split()[0]
    assert published == commit
    assert run(['git','rev-parse','HEAD']).decode().strip() == head
    assert digest(gitdir/'index') == original_index
    receipt = {'status':'PUBLISHED_REVIEWED_CARD2_DATA_ONLY_BRANCH','branch':BRANCH,
               'parent':a.expected_parent,'commit':commit,'tree':tree,'files':len(files),
               'every_git_blob_verified_exact_bytes':True,'download_verification':verified,
               'source_HEAD_unchanged':head,'source_index_unchanged':True}
    a.receipt.parent.mkdir(parents=True,exist_ok=True)
    with a.receipt.open('x',encoding='utf-8') as f:
        json.dump(receipt,f,indent=2)
        f.write('\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
