"""Separate runtime/mechanism audit from independent statistics localization."""
import argparse
import hashlib
import json
from pathlib import Path
from coverage import audit
from compare_model import compare as complete_compare
from graph_evidence import compare as independent_compare, graph, observed_rows, compare_row

ROOT = Path('/home/fault28-fullop-graph-20261110')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def graph_config(path):
    cfg = json.loads(path.read_bytes())
    assert cfg['fullgraph'] and not cfg['dynamic'] and cfg['FX_eager_dump_forbidden']
    options = cfg['options']
    assert options[0]['run_eagerly'] == '0'
    assert options[1]['ge.exec.dumpData'] == 'stats'
    assert options[1]['ge.exec.dumpMode'] == 'all'
    assert options[1]['ge.fusionSwitchFile'] == '/audit/setup/fusion_off.json'
    del options[1]['ge.exec.dumpPath']
    return cfg


def native_repeat(folder):
    nodes, meta = graph(folder)
    differences, boundaries, unavailable = [], 0, 0
    for node in nodes:
        if node['type'] in ('Const','NetOutput'):
            continue
        first, _ = observed_rows(folder,node,0)
        for call in (1,2):
            other, _ = observed_rows(folder,node,call)
            assert first.keys() == other.keys()
            for key in first:
                row = compare_row(first[key],other[key])
                assert not row['metadata']
                boundaries += 1
                unavailable += len(row['unobservable'])
                if row['differences']:
                    differences.append({'node':node['name'],'type':node['type'],
                                        'call_id':call,'boundary':key,'fields':row['differences']})
    return {'schema':'fault28.native_GE_statistics_repeat.v1',
            'finite_statistics_identical':not differences,'compared_boundaries':boundaries,
            'unobservable_fields_or_empty_boundaries':unavailable,'differences':differences,
            'actual_graph':meta,'native_calls':0,
            'scope':'Within-arm warmup and two replays; NA/null/empty fields are not counted as equal.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline-attempt', required=True)
    p.add_argument('--fault-attempt', required=True)
    p.add_argument('--card', type=int, choices=(2,5), required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.output.mkdir(parents=True, exist_ok=False)
    b = ROOT/'outputs'/a.baseline_attempt/'baseline'
    f = ROOT/'outputs'/a.fault_attempt/'fault'
    # Localization deliberately runs first and only reads the independent
    # function's statistical/graph inputs. Acceptance expectations are below.
    independent = independent_compare(b, f)
    save(a.output/'independent_first_difference.json', independent)
    print(json.dumps({'phase': 'independent_localization', 'first': [x['first'] for x in independent['independent_first_producer']]}), flush=True)
    controls_path = ROOT/'outputs/analysis_checks_a1/report.json'
    controls = json.loads(controls_path.read_bytes())
    assert controls['status'] == 'PASS_SELF_COMPARE_EARLIER_NON_FIA_DIFFERENCE_AND_OPTIONAL_INPUT_MAPPING'
    for name in ('graph_evidence.py','derive_operators.py','statistics_values.py'):
        assert controls['analysis_sha256'][name] == sha(Path(__file__).with_name(name))
    assert json.loads((b.parent/'source_manifest.json').read_bytes()) == json.loads((f.parent/'source_manifest.json').read_bytes())
    assert graph_config(b/'graph_config.json') == graph_config(f/'graph_config.json')
    assert json.loads((ROOT/'setup/fusion_off.json').read_bytes()) == {'Switch': {'GraphFusion': {'ALL': 'off'}, 'UBFusion': {'ALL': 'off'}}}
    coverage = []
    for role, attempt in [('baseline', a.baseline_attempt), ('fault', a.fault_attempt)]:
        record = audit(attempt, expected_card=a.card)
        save(a.output/('coverage_'+role+'.json'), record)
        coverage.append(record)
    numerical = complete_compare(b, f)
    save(a.output/'complete_output_comparison.json', numerical)
    repeat = {'baseline':native_repeat(b),'fault':native_repeat(f)}
    save(a.output/'native_statistics_repeat.json',repeat)
    firsts = independent['independent_first_producer']
    first_fia = all(row['first'] and row['first']['type'] == 'FusedInferAttentionScore'
                    and row['first']['boundary'] == 'output' for row in firsts)
    assert coverage[0]['actual_m'] == 512 and coverage[1]['actual_m'] == 128
    assert all(row['no_splitkv'] and row['batch'] == 8 for row in coverage)
    assert numerical['first_changed_attention_inputs_equal'] is True
    passed = first_fia and numerical['first_changed_attention_layer'] == 0
    report = {
        'schema': 'fault28.fullgraph_per_operator_recollection_acceptance.v1',
        'status': 'PASS_RECOLLECTION_WITH_OBSERVABILITY_LIMITS' if passed else 'INCONCLUSIVE_FIRST_LOCATION_OR_NUMERICAL_MECHANISM',
        'cases': 2, 'roles': ['baseline','fault'],
        'physical_card': a.card,
        'attempts': {'baseline': a.baseline_attempt, 'fault': a.fault_attempt},
        'real_single_ge_fullgraph': True, 'eager_fx_dump_used': False,
        'graph_and_UB_fusion': 'OFF in both arms for per-operator visibility',
        'same_checkpoint_inputs_fusion_and_collector': True,
        'same_parameters_before_after': True, 'repeated_all_returned_outputs_equal': True,
        'native_finite_statistics_repeat_identical':{k:r['finite_statistics_identical'] for k,r in repeat.items()},
        'model_graph_executions': 6, 'fia_node_executions': 168,
        'layer_request_executions': 1344, 'all_28_layers_all_8_request_rows_covered': True,
        'baseline_m': coverage[0]['actual_m'], 'fault_m': coverage[1]['actual_m'],
        'independent_first_observed_at_fia_output': first_fia,
        'first_changed_attention_layer': numerical['first_changed_attention_layer'],
        'first_attention_QKV_exactly_equal': numerical['first_changed_attention_inputs_equal'],
        'logits_changed_requests': numerical['logits_changed_requests'],
        'top1_changed_requests': numerical['top1_changed_requests'],
        'independent_report_sha256': sha(a.output/'independent_first_difference.json'),
        'complete_comparison_sha256': sha(a.output/'complete_output_comparison.json'),
        'independent_falsification_controls_sha256': sha(controls_path),
        'analysis_source_sha256': {p.name: sha(p) for p in Path(__file__).parent.glob('*.py')},
        'limits': [
            'Earliest OBSERVED statistic, with missing/unobservable boundaries preserved; not a proof of equality of all prior tensors.',
            'Original statistics/mix module triplets are not per-Python-API records inside GE. Native GE CSV provides the per-op route, with explicitly derived JSON.',
            'Native CSV finite summaries are rounded. Uniform disclosed CPU-FP64 module output statistics need direct GE output-edge mapping.',
            'This same-B8 B/F recollection verifies the controlled M strategy and propagation; it does not repeat the prior B1/B8 causal matrix.',
            'Both arms disable GraphFusion/UBFusion, a disclosed observation configuration change from the old collection.',
            'No new OFF case or continuous generation is included; the two replays test repeat stability within each arm.',
            'M changes causal inner reduction widths and other native BMM paths; no unique Reduce-instruction or historical Pangu attribution.',
            'Default SDPA equivalence, model task accuracy and continuous text generation are outside this recollection.'
        ]}
    save(a.output/'acceptance.json', report)
    print(json.dumps({k: report[k] for k in ('status','independent_first_observed_at_fia_output','logits_changed_requests','top1_changed_requests')}), flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
