"""CPU falsification controls on real capture copies; never an NPU capture group."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import shutil
from derive_operators import derive
from graph_evidence import compare, graph, observed_rows, csv_inventory


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline', type=Path, required=True)
    p.add_argument('--destination', type=Path, required=True)
    a = p.parse_args()
    a.destination.mkdir(parents=True, exist_ok=False)
    fixture = a.destination/'synthetic_statistic_mutation'
    fixture.mkdir()
    for name in ('config.json','collector_provenance.json','fx_graph_0.json'):
        shutil.copyfile(a.baseline/name, fixture/name)
    for name in ('observation','msprobe_graph'):
        shutil.copytree(a.baseline/name, fixture/name)
    nodes, _ = graph(a.baseline)
    selected = None
    for node in nodes:
        if node['type'] != 'Data':
            continue
        rows, source = observed_rows(a.baseline, node, 1)
        if not source or 'path' not in source:
            continue
        for key, row in rows.items():
            try:
                value = float(row['AvgValue'])
            except (ValueError,TypeError):
                continue
            if key[0] == 'Output' and math.isfinite(value):
                selected = (node, source, key, value)
                break
        if selected:
            break
    assert selected, 'No suitable earlier finite Data output for a falsification control'
    node, source, key, value = selected
    path = fixture/source['path']
    source_hash = sha(a.baseline/source['path'])
    with path.open(newline='') as stream:
        reader = csv.DictReader(stream)
        names, rows = reader.fieldnames, list(reader)
    header = next(name for name in names if name.replace(' ','') == 'AvgValue')
    for row in rows:
        if (row['Input/Output'], int(row['Index'])) == key:
            row[header] = repr(value+max(1.0,abs(value)))
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=names)
        writer.writeheader()
        writer.writerows(rows)
    assert sha(a.baseline/source['path']) == source_hash
    self_report = compare(a.baseline, a.baseline)
    assert all(r['first'] is None for r in self_report['independent_first_producer'])
    mutation_report = compare(a.baseline, fixture)
    first = mutation_report['independent_first_producer'][0]['first']
    assert first['node'] == node['name'] and first['type'] == 'Data'
    assert first['boundary'] == 'output' and first['index'] == key[1]
    assert mutation_report['independent_first_producer'][1]['first'] is None
    d = derive(a.baseline, 1)
    fia = next(o for o in d['operators'] if o['type'] == 'FusedInferAttentionScore')
    mapping = {p['index']: p['ge_descriptor_index'] for p in fia['native_csv_ports'] if p['boundary'] == 'input'}
    assert mapping == {0:0,1:1,2:2,3:4,4:5,5:6}
    result = {'schema': 'fault28.independent_locator_falsification_controls.v1',
              'status': 'PASS_SELF_COMPARE_EARLIER_NON_FIA_DIFFERENCE_AND_OPTIONAL_INPUT_MAPPING',
              'native_calls': 0, 'synthetic_fixture_is_real_fault_capture': False,
              'original_source_bytes_unchanged': True,
              'self_comparison_first': [r['first'] for r in self_report['independent_first_producer']],
              'synthetic_earlier_difference_first': first,
              'unmodified_step1_first': mutation_report['independent_first_producer'][1]['first'],
              'mutated_fixture_source': source['path'], 'original_source_sha256': source_hash,
              'mutated_fixture_sha256': sha(path), 'fia_native_to_GE_input_index': mapping,
              'purpose': 'Demonstrate that independent analysis can report no difference or an earlier non-FIA difference, without forcing the expected mechanism location.',
              'analysis_sha256': {p.name: sha(p) for p in Path(__file__).parent.glob('*.py')}}
    (a.destination/'report.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: result[k] for k in ('status','native_calls','self_comparison_first','synthetic_earlier_difference_first')}))


if __name__ == '__main__':
    main()
