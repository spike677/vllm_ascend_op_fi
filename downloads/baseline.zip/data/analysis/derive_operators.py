"""Lossless, explicitly derived GE per-operator view; never a native API dump.

Every actual optimized-graph node is included. Original CSV strings and their
SHA256 provenance remain available. Native module statistics are attached only
through independently checked direct NetOutput edges. No policy/result/host
events or desired first-difference name are consulted.
"""
import argparse
from collections import Counter
import hashlib
import heapq
import json
import math
from pathlib import Path
import re
from graph_evidence import graph, observed_rows, alias_mapping, csv_inventory
from statistics_values import load_step


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def topology(nodes):
    """Stable Kahn ordering from real GE data/control edges, not tuple slots."""
    table = {n['name']: n for n in nodes}
    positions = {n['name']: i for i, n in enumerate(nodes)}
    parents, children = {}, {name: set() for name in table}
    for node in nodes:
        deps = {edge.rsplit(':', 1)[0] for edge in node['inputs'] if edge}
        if not deps <= table.keys():
            raise ValueError('GE edge references an unknown producer')
        parents[node['name']] = set(deps)
        for dep in deps:
            children[dep].add(node['name'])
    ready = [(positions[name], name) for name, deps in parents.items() if not deps]
    heapq.heapify(ready)
    ordered = []
    while ready:
        _, name = heapq.heappop(ready)
        ordered.append(table[name])
        for child in children[name]:
            parents[child].remove(name)
            if not parents[child]:
                heapq.heappush(ready, (positions[child], child))
    if len(ordered) != len(nodes):
        raise ValueError('Cyclic/unsupported GE graph; no ordered localization')
    return ordered


def block_end(text, start):
    depth, quoted, escaped, pos = 1, False, False, start
    while depth and pos < len(text):
        char = text[pos]
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                quoted = False
        elif char == '"':
            quoted = True
        elif char == '{':
            depth += 1
        elif char == '}':
            depth -= 1
        pos += 1
    if depth:
        raise ValueError('Unterminated GE descriptor')
    return pos


def descriptors(text, nodes):
    # These fields are at exactly two-space depth in the original GE text.
    starts = list(re.finditer(r'^op \{', text, re.M))
    descriptions = {}
    for i, match in enumerate(starts):
        block = text[match.start(): starts[i+1].start() if i+1 < len(starts) else len(text)]
        name = re.search(r'^  name: "([^"\n]+)"$', block, re.M)[1]
        descriptions[name] = {}
        for side in ('input','output'):
            records = []
            for match in re.finditer(r'^  '+side+r'_desc \{', block, re.M):
                desc = block[match.end():block_end(block, match.end())-1]
                tensor_name = re.search(r'^    name: "([^"\n]*)"$', desc, re.M)
                dtype = re.search(r'^    dtype: ([^\n]+)$', desc, re.M)
                layout = re.search(r'^    layout: "([^"\n]*)"$', desc, re.M)
                shape = re.search(r'^    shape \{\n(.*?)^    \}', desc, re.M|re.S)
                records.append({'index': len(records), 'name': tensor_name[1] if tensor_name else None,
                                'dtype': dtype[1] if dtype else None,
                                'layout': layout[1] if layout else None,
                                'shape': [int(d) for d in re.findall(r'^      dim: (-?\d+)$', shape[1], re.M)] if shape else None})
            descriptions[name][side] = records
    if set(descriptions) != {n['name'] for n in nodes}:
        raise ValueError('GE descriptor inventory disagrees with actual nodes')
    return descriptions


def port_map(node, descs, rows, side):
    """GE optional holes are not native CSV's compacted input indices."""
    active = [d for d in descs if d['dtype'] not in (None,'DT_UNDEFINED')]
    if side == 'input' and len(node['inputs']) == len(descs):
        active = [d for d in active if node['inputs'][d['index']]]
    keys = sorted(k[1] for k in rows if k[0].lower() == side)
    if keys != list(range(len(active))):
        return {}, 'Unresolved: lowered runtime arity differs from GE descriptors; native CSV indices remain distinct.'
    mapping = {}
    for index, desc in enumerate(active):
        row = rows[(side.capitalize(),index)]
        if row['DataType'] != desc['dtype']:
            return {}, 'Unresolved: native dtype differs from the ordered active GE descriptors.'
        mapping[index] = desc['index']
    return mapping, 'Ordered nonempty actual GE descriptors/edges, matching dense runtime arity and dtype; optional holes retained.'


def finite_fields(row):
    fields = ('MaxValue','MinValue','AvgValue','NanCount','NegativeInfCount','PositiveInfCount')
    observable, missing = [], []
    for field in fields:
        try:
            finite = int(row['DataSize']) > 0 and math.isfinite(float(row.get(field)))
        except (ValueError,TypeError):
            finite = False
        (observable if finite else missing).append(field)
    return observable, missing


def at_path(value, path):
    if not re.fullmatch(r'\$(?:\[\d+\])*', path):
        raise ValueError('Unsupported serialized tensor path')
    for index in re.findall(r'\[(\d+)\]', path):
        value = value[int(index)]
    return value


def derive(folder, call):
    nodes, graph_meta = graph(folder)
    ordered = topology(nodes)
    # Existing independent locator follows the graph text order. Require that
    # the serialized order itself is a valid topological traversal before reuse.
    positions = {n['name']: i for i, n in enumerate(nodes)}
    if any(positions[e.rsplit(':', 1)[0]] >= positions[n['name']]
           for n in nodes for e in n['inputs'] if e):
        raise ValueError('Graph text is not topological; locator must be adapted')
    descriptions = descriptors((folder / graph_meta['path']).read_text(), nodes)
    aliases = alias_mapping(folder)
    module, raw_meta = None, None
    if call in (1, 2):
        raw_path = folder/'observation'/f'step{call-1}'/'rank0/dump.json'
        raw = load_step(raw_path)
        matches = [e for e in raw['entries'] if 'GraphBoundary' in e['name']]
        if len(matches) != 1:
            raise ValueError('Expected one original GraphBoundary record')
        module = matches[0]
        raw_meta = {'path': str(raw_path.relative_to(folder)), 'sha256': sha(raw_path),
                    'module_node': module['name']}
    alias_by_node = {}
    for alias in aliases['output_edges']:
        alias_by_node.setdefault(alias['producer'], []).append(alias)
    operators = []
    for graph_index, node in enumerate(ordered):
        rows, sources = observed_rows(folder, node, call)
        mappings = {side: port_map(node, descriptions[node['name']][side], rows, side)
                    for side in ('input','output')}
        ports = []
        for (side, index), row in sorted(rows.items(), key=lambda x: (x[0][0] != 'Input', x[0][1])):
            mapping, mapping_reason = mappings[side.lower()]
            finite, missing_fields = finite_fields(row)
            ports.append({'boundary': side.lower(), 'index': index,
                          'index_space': 'native_CSV_compact_tensor_index',
                          'ge_descriptor_index': mapping.get(index), 'mapping_evidence': mapping_reason,
                          'original_csv_fields': row,
                          'nonempty_tensor': int(row['DataSize']) > 0,
                          'finite_statistic_fields': finite, 'unobservable_statistic_fields': missing_fields,
                          'limitation': 'Empty tensor statistics are invalid, even if the CSV contains stale numbers.'
                          if int(row['DataSize']) == 0 else 'NA/nonfinite fields remain unobservable; rounded summary equality is not tensor equality.'})
        attached = []
        if module is not None:
            for alias in alias_by_node.get(node['name'], []):
                tensor = at_path(module['node']['output'], alias['serialized_output_path'])
                attached.append({'boundary': 'output', 'index': alias['producer_output_index'],
                                 'original_tensor_statistics': tensor, 'source': raw_meta,
                                 'serialized_path': alias['serialized_output_path'],
                                 'actual_graph_edge': alias['edge'],
                                 'scope': 'Original module statistic mapped to a direct GE output producer; not a native API record.'})
        missing = []
        for side in ('input', 'output'):
            observed = {p['ge_descriptor_index'] for p in ports if p['boundary'] == side and p['ge_descriptor_index'] is not None}
            aliased = {p['index'] for p in attached if p['boundary'] == side}
            for index in range(len(descriptions[node['name']][side])):
                if index not in observed and index not in aliased:
                    missing.append({'boundary': side, 'index': index, 'value': None,
                                    'index_space': 'actual_GE_descriptor_index',
                                    'reason': 'No independent runtime CSV or direct output alias. May be a constant, metadata-only, optimized or otherwise unobservable boundary; no equality inferred.'})
        status = 'NATIVE_CSV' if rows else 'DIRECT_OUTPUT_ALIAS_ONLY' if attached else 'UNOBSERVABLE'
        operators.append({'graph_index': graph_index, **node,
                          'descriptor_counts': {s: len(d) for s,d in descriptions[node['name']].items()},
                          'descriptors': descriptions[node['name']],
                          'status': status, 'native_csv_provenance': sources, 'native_csv_ports': ports,
                          'direct_module_alias_statistics': attached, 'missing_boundaries': missing})
    model_csv = [p for p in csv_inventory(folder) if p.parent.name == str(call)
                 and p.parent.parent.parent.name == 'graph_1']
    return {'schema': 'fault28.DERIVED_GE_operator_statistics.v1',
            'is_native_msprobe_dump_json': False, 'data_origin': 'Unmodified native GE CSV + actual GE graph + original module statistics through direct output aliases',
            'actual_graph_call_id': call, 'actual_msprobe_step': call-1 if call else None,
            'phase': 'compile_warmup' if call == 0 else 'compiled_graph_replay',
            'graph': graph_meta, 'all_optimized_graph_nodes': len(nodes),
            'model_graph_native_csv_files': len(model_csv),
            'status_counts': dict(Counter(op['status'] for op in operators)),
            'unobservable_node_types': dict(Counter(op['type'] for op in operators if op['status'] == 'UNOBSERVABLE')),
            'operators': operators,
            'limits': ['Statistics are summaries, not complete tensor values.',
                       'Original CSV spelling/rounding is preserved, without inventing a Norm field.',
                       'Missing, NA, null, empty and nonfinite fields do not establish equality.',
                       'This is graph-native capture. The original statistics/mix dump remains a single GraphBoundary module record.',
                       'Constants and metadata nodes are indexed but may have no independent runtime CSV.',
                       'No expected profile, injector events, policy or accepted output was used to choose a first difference.']}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case', type=Path, required=True)
    p.add_argument('--destination', type=Path, required=True)
    a = p.parse_args()
    results = []
    for call in (0, 1, 2):
        report = derive(a.case, call)
        step = 'warmup' if call == 0 else f'step{call-1}'
        path = a.destination/step/'rank0/operators.json'
        save(path, report)
        results.append({k: report[k] for k in ('actual_graph_call_id','actual_msprobe_step','all_optimized_graph_nodes','model_graph_native_csv_files','status_counts','unobservable_node_types')})
    print(json.dumps({'status': 'DERIVED_WITH_MISSING_ITEMS_PRESERVED', 'cases': results}))


if __name__ == '__main__':
    main()
