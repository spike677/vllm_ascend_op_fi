"""Reviewed B/F statistics export; all native GE CSV bytes are preserved.

Full tensors, binaries, weights and multi-GB debug logs never enter this tree.
Native model CSV names are shortened, with an explicit original-source map.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
from derive_operators import derive
from graph_evidence import compare

ROOT = Path('/home/fault28-fullop-graph-20261110')
SHARED = Path('/home/fault28-fia-fullmodel-20261109')
FORBIDDEN = {'.pt','.pth','.bin','.npy','.npz','.safetensors','.o','.so','.run','.log','.gz'}
ALLOWED = {'.json','.jsonl','.csv','.txt','.patch','.h','.cpp','.py','.sh'}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


class Export:
    def __init__(self, destination):
        self.root = destination
        self.mapping = []
        destination.mkdir(parents=True, exist_ok=False)

    def copy(self, source, rel):
        target = self.root/rel
        assert source.is_file() and not source.is_symlink()
        assert source.suffix in ALLOWED and source.suffix not in FORBIDDEN
        assert source.stat().st_size <= 64*1024**2
        assert not target.exists() and target.resolve().is_relative_to(self.root.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        assert sha(source) == sha(target)
        self.mapping.append({'source': str(source), 'published': rel.as_posix(),
                             'bytes': target.stat().st_size, 'sha256': sha(target),
                             'original_bytes_preserved': True})

    def case(self, role, attempt):
        parent = ROOT/'outputs'/attempt
        source = parent/role
        prefix = Path('cases')/role
        fields = ('case.json','result.json','inputs.json','config.json','graph_config.json',
                  'fx_graph_0.json','output_contract.json','model_config.json',
                  'loaded_parameters.json','parameters_receipt.json','compiled_engine_bindings.json',
                  'collector_provenance.json','statistics_receipt.json','host_events.jsonl',
                  'jit_compile_inventory.json')
        for name in fields:
            self.copy(source/name, prefix/name)
        for step in (0, 1):
            for name in ('dump','stack','construct'):
                rel = Path('observation')/f'step{step}'/'rank0'/(name+'.json')
                self.copy(source/rel, prefix/rel)
        for kind in ('original','optimized'):
            found = list((source/'msprobe_graph').rglob('dynamo_'+kind+'_graph_*.txt'))
            assert len(found) == 1
            self.copy(found[0], prefix/'msprobe_graph'/('dynamo_'+kind+'_graph_1.txt'))
        counts = Counter()
        csvs = sorted((source/'msprobe_graph').rglob('*.csv'))
        for i, p in enumerate(csvs):
            if p.parent.parent.parent.name == 'graph_1':
                assert p.parent.name in ('0','1','2')
                # Prefix still binds actual runtime type and unique GE node.
                name = '.'.join(p.name.split('.')[:2])+f'.{i:05d}.csv'
                rel = prefix/'msprobe_graph/raw/graph_1'/p.parent.parent.name/p.parent.name/name
                counts['graph_call_'+p.parent.name] += 1
            else:
                rel = prefix/'msprobe_graph/auxiliary'/(f'{i:05d}.csv')
                counts['auxiliary_outside_model_graph'] += 1
            self.copy(p, rel)
        save(self.root/prefix/'native_csv_inventory.json', {
            'all_csv_files_found': len(csvs), 'all_csv_files_published': sum(counts.values()),
            'counts': dict(counts), 'selection': 'ALL native GE CSV in this capture, including auxiliary observer operations',
            'native_csv_bytes_unchanged': True, 'original_paths': 'data/source_mapping.json',
            'scope': 'Only graph_1 CSV participates in model first-difference localization; auxiliary statistics operations are preserved separately.'})
        for name in ('completion.json','source_manifest.json','selected_cases.json',
                     'container_identity.json','resource_policy.json','private_batch_storage.json'):
            self.copy(parent/name, prefix/'controller'/name)
        self.copy(parent/(role+'.vendor_launch.json'), prefix/'controller/vendor_launch.json')
        for s, d in [('native_lines.txt','native_lines.txt'),('provenance.json','native_provenance.json')]:
            self.copy(parent/'native_extract'/s, prefix/d)
        inv = json.loads((source/'jit_compile_inventory.json').read_bytes())
        for row in inv['files']:
            if not row.get('private_copy'):
                continue
            p = source/row['private_copy']
            assert sha(p) == row['sha256']
            if '_isolate_tiling_' in p.name:
                d = json.loads(p.read_bytes())
                info = d['tiling_info']
                keys = ('block_num','task_ration','tiling_data','tiling_data_size','static_shape_flag',
                        'tiling_key','static_workspace_size','schedule_mode','tiling_info_completed','raw_run_info')
                save(self.root/prefix/'compiler_tiling_excerpt.json', {
                    'schema': 'fault28.reviewed_compiler_tiling_excerpt.v1',
                    'original_file': row['file'], 'original_sha256': row['sha256'],
                    'original_bytes': row['bytes'], 'optype': d['optype'],
                    'is_static_shape': d['is_static_shape'], 'run_info': d['run_info'],
                    'tiling_info': {k: info[k] for k in keys},
                    'generated_header_sha256': hashlib.sha256(info['file_content'].encode()).hexdigest(),
                    'scope': 'Explicit field excerpt; not an original whole isolate JSON or measured device argument.'})
            else:
                self.copy(p, prefix/'compiler_binary_metadata.json')
        for call in (0, 1, 2):
            report = derive(self.root/prefix, call)
            step = 'warmup' if call == 0 else f'step{call-1}'
            save(self.root/prefix/'derived'/step/'rank0/operators.json', report)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--baseline-attempt', required=True)
    p.add_argument('--fault-attempt', required=True)
    p.add_argument('--reports', type=Path, required=True)
    p.add_argument('--destination', type=Path, required=True)
    a = p.parse_args()
    acceptance = json.loads((a.reports/'acceptance.json').read_bytes())
    assert acceptance['status'] == 'PASS_RECOLLECTION_WITH_OBSERVABILITY_LIMITS'
    export = Export(a.destination)
    for role, attempt in [('baseline', a.baseline_attempt), ('fault', a.fault_attempt)]:
        export.case(role, attempt)
    source = ROOT/'outputs'/a.baseline_attempt
    for rel, digest in json.loads((source/'source_manifest.json').read_bytes()).items():
        assert sha(source/'source'/rel) == digest
        export.copy(source/'source'/rel, Path('runtime_source')/rel)
    for p in sorted(a.reports.glob('*.json')):
        export.copy(p, Path('reports')/p.name)
    for p in sorted((ROOT/'analysis').glob('*.py')):
        export.copy(p, Path('analysis')/p.name)
    for name in ('fia_abi_schema.json','fia_abi_compile.json','fia_abi_selftest.json',
                 'policy_source_manifest.json','official_sources.patch','fia_schema_projection.h'):
        export.copy(SHARED/'build/evidence_a4'/name, Path('build')/name)
    for name in ('device_grain_trace.json','device_grain_trace.patch'):
        export.copy(SHARED/'build'/name, Path('build')/name)
    export.copy(SHARED/'vendor_stage_a5/vendor_manifest.json', Path('build/vendor_manifest.json'))
    for name in ('stage_manifest.json','source_manifest.json','collector.patch'):
        export.copy(SHARED/'collector_fp64_a1'/name, Path('collector')/name)
    export.copy(SHARED/'collector_fp64_a1/packages/msprobe/core/dump/data_dump/data_processor/pytorch_processor.py',
                Path('collector/pytorch_processor.py'))
    for name in ('model_manifest.json','tokenizer_manifest.json'):
        export.copy(SHARED/name, Path('build')/name)
    lease = ROOT/'resource_lease/active-a1'
    restored_lease = json.loads((lease/'restore_receipt.json').read_bytes())
    installed_lease = json.loads((lease/'install_receipt.json').read_bytes())
    assert restored_lease['status'] == 'RESTORED_ORIGINAL_DOCKER_CLI'
    assert restored_lease['original_sha256'] == installed_lease['original_sha256']
    assert sha(ROOT/'resource_lease/docker_guard.py') == installed_lease['policy_sha256']
    assert sha(ROOT/'resource_lease/lease.py') == installed_lease['installer_sha256']
    for name in ('install_receipt.json','validation.json','restore_receipt.json'):
        export.copy(lease/name, Path('resource_lease')/name)
    for name in ('docker_guard.py','lease.py','validate.py'):
        export.copy(ROOT/'resource_lease'/name, Path('resource_lease')/name)
    log = lease/'rejections.jsonl'
    events = [json.loads(line) for line in log.read_text().splitlines()] if log.exists() else []
    validated = json.loads((lease/'validation.json').read_bytes())
    actual = [row for row in events if row['time'] > validated['time']+1]
    save(export.root/'resource_lease/operation_summary.json', {
        'schema': 'fault28.card2_lease.redacted_summary.v1',
        'explicit_user_approval': True, 'selected_card': 2,
        'restored': True, 'original_binary_sha256': restored_lease['original_sha256'],
        'all_rejected_operations': dict(Counter(row['operation'] for row in events)),
        'after_validation_rejected_operations': dict(Counter(row['operation'] for row in actual)),
        'private_rejection_log_sha256': sha(log) if log.exists() else None,
        'raw_credential_exported': False, 'original_executable_exported': False,
        'scope': 'Temporary local Docker-CLI lease; no change to model math, Docker daemon or SSH. Completed capture containers and unrelated devices use original runtime.'})
    restored = compare(export.root/'cases/baseline', export.root/'cases/fault')
    original = json.loads((a.reports/'independent_first_difference.json').read_bytes())
    assert [r['first'] for r in restored['independent_first_producer']] == [r['first'] for r in original['independent_first_producer']]
    assert [r['first_observed_difference'] for r in restored['ge']] == [r['first_observed_difference'] for r in original['ge']]
    save(export.root/'reports/restored_independent_first_difference.json', restored)
    export.copy(ROOT/'outputs/analysis_checks_a1/report.json', Path('diagnostics/independent_analysis_controls.json'))
    save(export.root/'primary_BF.json', {
        'roles': ['baseline','fault'], 'baseline': 'cases/baseline', 'fault': 'cases/fault',
        'actual_steps': [0,1], 'warmup_graph_call': 0,
        'graph_calls_mapped_to_steps': {'1': 0, '2': 1},
        'same_batch': 8, 'same_sequence_length': 2048,
        'physical_card': acceptance['physical_card'],
        'real_single_fullgraph': True, 'fusion_off_in_both': True,
        'independent_localization': 'analysis/graph_evidence.py',
        'converted_operator_JSON': 'cases/<role>/derived/stepN/rank0/operators.json',
        'converted_JSON_is_native_msprobe_dump': False})
    save(export.root/'source_mapping.json', {
        'schema': 'fault28.fullgraph_original_statistical_file_mapping.v1',
        'files': export.mapping,
        'scope': 'Mapped originals preserve bytes. Derived JSON, summaries, inventories and labeled compiler excerpts are generated. No private tensor payloads or binaries.'})
    files = sorted(p for p in export.root.rglob('*') if p.is_file())
    assert sum(p.stat().st_size for p in files) < 512*1024**2
    assert all(p.suffix not in FORBIDDEN for p in files)
    (export.root/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.relative_to(export.root).as_posix()+'\n' for p in files))
    archive = export.root.with_suffix('.tar.gz')
    with tarfile.open(archive, 'x:gz') as stream:
        for p in sorted(export.root.rglob('*')):
            if p.is_file():
                stream.add(p, arcname=p.relative_to(export.root), recursive=False)
    print(json.dumps({'status': 'EXPORTED_TWO_FULLGRAPH_STATISTICS_GROUPS',
                      'files': len(files)+1, 'archive': str(archive),
                      'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive)}))


if __name__ == '__main__':
    main()
