"""Real eager FIA calibration/full-model execution; no torch.compile backend."""
import argparse
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import time
import traceback
import uuid
from collector_stage import select_collector,verify_loaded


def sha(data): return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024**2),b''): h.update(block)
    return h.hexdigest()


def save(path,value):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2,allow_nan=False)
        stream.write('\n')


def parameters(model):
    return {name:{'shape':list(t.shape),'dtype':str(t.dtype),
                  'sha256':sha(t.detach().cpu().contiguous().numpy().tobytes())}
            for name,t in model.named_parameters()}


def configure(out,collector):
    from msprobe.pytorch import PrecisionDebugger
    proc=importlib.import_module('msprobe.core.dump.data_dump.data_processor.pytorch_processor')
    collector['actual_loaded']=verify_loaded(collector,proc)
    support=Path(collector['package_root'])/'msprobe/pytorch/dump/api_dump/support_wrap_ops.yaml'
    assert '- npu_fused_infer_attention_score' in support.read_text()
    collector['support_registration']={'path':str(support),'sha256':file_sha(support)}
    save(out/'collector_provenance.json',collector)
    config={'task':'statistics','level':'mix','precision':'high','rank':[],'step':[0],
            'dump_path':str(out/'observation'),'async_dump':False,
            'statistics':{'scope':[],'list':[],'data_mode':['all'],
                          'summary_mode':'statistics','tensor_list':[]}}
    save(out/'config.json',config)
    return PrecisionDebugger(config_path=str(out/'config.json'))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--case-file',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();out=a.output;out.mkdir(parents=True,exist_ok=False)
    private=out/'private_output';private.mkdir()
    case=json.loads(a.case_file.read_bytes());save(out/'case.json',case)
    result={'schema':'fault28.eager.capture.v1','status':'RUNNING','case_id':case['case_id'],
            'execution_mode':'eager','calls':[],'accepted':False}
    try:
        assert case['execution_mode']=='eager' and case['capture_scope'] in ('calibration','model')
        collector=select_collector(case) if case['capture_msprobe'] else None
        start=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]
        token=uuid.uuid4().hex
        debug=out/'private_device_debug';debug.mkdir()
        os.environ['ASCEND_WORK_PATH']=str(debug)
        if case['operator_variant']=='private_vendor':
            os.environ.update(FAULT28_FIA_GRAPH_MODE=case['mode'],FAULT28_FIA_GRAPH_TOKEN=token,
                FAULT28_FIA_GRAPH_PID=str(os.getpid()),FAULT28_FIA_GRAPH_OWNER_START=start,
                FAULT28_FIA_GRAPH_LOG=str(out/'host_events.jsonl'))
        import torch
        import torch_npu
        import numpy as np
        import model_adapter
        result.update(owner_pid=os.getpid(),owner_starttime_ticks=start,scope_token=token)
        frozen=json.loads((out.parent/'source_manifest.json').read_bytes())
        assert file_sha(Path(__file__))==frozen['eager_probe.py']
        assert file_sha(Path(model_adapter.__file__))==frozen['model_adapter.py']
        torch.manual_seed(42);torch.use_deterministic_algorithms(True)
        forbidden=[]
        def no_compile(*args,**kwargs):
            forbidden.append('torch.compile')
            raise RuntimeError('Compiled model execution is forbidden in eager acceptance')
        torch.compile=no_compile
        torch.npu.set_device(0);torch.npu.set_compile_mode(jit_compile=False)
        before_limit=torch.npu.get_device_limit(0)
        torch.npu.set_device_limit(0,cube_num=16,vector_num=32)
        actual_limit=torch.npu.get_device_limit(0)
        assert actual_limit=={'cube_core_num':16,'vector_core_num':32}
        save(out/'execution_config.json',{'mode':'eager','torch_compile_forbidden':True,
            'torchair_backend_requested':False,'model_graph_compilation_requested':False,
            'core_limit_before':before_limit,'actual_process_core_limit':actual_limit,
            'jit_compile':False,'deterministic_algorithms':True,
            'route':'torch_npu.npu_fused_infer_attention_score / native ACLNN',
            'scope':'Python eager execution; native ACLNN may internally build its own operator executor.'})
        assert case['batch']==8 and case['sequence_length']==2048
        mask_cpu=torch.triu(torch.ones((2048,2048),dtype=torch.bool),diagonal=1)
        scope=case['capture_scope'];model=None;params_before=None
        if scope=='calibration':
            ref=Path(case['pilot_reference'])
            old=json.loads((ref/'result.json').read_bytes());assert old['status']=='CAPTURE_COMPLETED'
            rows=old['calls'][0]['values'];xs=[];provenance=[]
            for slot,heads,kind in [(1,16,'query'),(2,8,'key'),(3,8,'value')]:
                row=rows[slot];assert row['kind']==kind and row['layer']==0
                path=ref/row['target_file'];data=path.read_bytes();assert sha(data)==row['target_sha256']
                tensor=torch.from_numpy(np.frombuffer(data,dtype='<f2').copy()).reshape(1,heads,2048,128).repeat(8,1,1,1)
                xs.append(tensor);provenance.append({'kind':kind,'source':str(path),'source_sha256':sha(data),
                    'source_request_row':0,'repeat_count':8})
            cpu_inputs=(*xs,mask_cpu)
            class Calibration(torch.nn.Module):
                def forward(self,q,k,v,mask):
                    attn=model_adapter.native_fia(0,q,k,v,mask,128**-0.5)
                    consumed=attn+1
                    return q,k,v,attn,consumed
            wrapper=Calibration().eval()
            slots=[{'slot':i,'kind':kind,'layer':0 if i<4 else None}
                   for i,kind in enumerate(('query','key','value','attention','consumer'))]
            save(out/'inputs.json',{'scope':'Fixed real graph-captured layer0 QKV, request0 repeated8; calibration only',
                'provenance':provenance,'batch':8,'target_position':2047})
        else:
            from transformers import AutoModelForCausalLM
            inventory=Path(case['cpu_inventory']);assert file_sha(inventory)==case['cpu_inventory_sha256']
            inv=json.loads(inventory.read_bytes())
            versions={n:importlib.metadata.version(n) for n in ('torch','torch-npu','transformers')}
            assert versions==inv['versions']
            for name,row in inv['modules'].items():
                path=Path(importlib.import_module(name).__file__)
                assert str(path)==row['path'] and file_sha(path)==row['sha256'],name
            source=Path(case['input_manifest']);assert file_sha(source)==case['input_manifest_sha256']
            manifest=json.loads(source.read_bytes());by_id={r['request_id']:r for r in manifest['requests']}
            requests=[by_id[k] for k in case['request_ids']]
            assert len({r['request_id'] for r in requests})==8 and all(len(r['prompt_token_ids'])==2048 for r in requests)
            mm=Path(case['model_manifest']);assert file_sha(mm)==case['model_manifest_sha256']
            for name,row in json.loads(mm.read_bytes())['files'].items():
                path=Path('/models/Qwen3-0.6B')/name
                assert path.stat().st_size==row['bytes'] and file_sha(path)==row['sha256']
            model=AutoModelForCausalLM.from_pretrained('/models/Qwen3-0.6B',dtype=torch.float16,
                attn_implementation='eager',local_files_only=True,trust_remote_code=False).eval()
            assert all(t.dtype==torch.float16 for t in model.parameters())
            params_before=parameters(model)
            save(out/'loaded_parameters.json',{'parameters':params_before,'checkpoint_sha256':file_sha(Path('/models/Qwen3-0.6B/model.safetensors'))})
            model_adapter.install(model);model=model.to('npu:0')
            wrapper=model_adapter.FullModelEager(model).eval()
            ids_cpu=torch.tensor([r['prompt_token_ids'] for r in requests],dtype=torch.long)
            positions_cpu=torch.arange(2048,dtype=torch.long).unsqueeze(0)
            cpu_inputs=(ids_cpu,positions_cpu,mask_cpu)
            slots=[{'slot':0,'kind':'logits','layer':None}]
            slots += [{'slot':1+4*l+i,'kind':kind,'layer':l} for l in range(28)
                      for i,kind in enumerate(('query','key','value','attention'))]
            save(out/'inputs.json',{'manifest_sha256':file_sha(source),'request_rows':[
                {'slot':i,'request_id':r['request_id'],'prompt_length':2048,'token_sha256':r['prompt_token_ids_sha256']} for i,r in enumerate(requests)],
                'position_ids':'0..2047','use_cache':False,'generated_feedback':False})
            save(out/'versions.json',versions)
        inputs=tuple(t.to('npu:0') for t in cpu_inputs);torch.npu.synchronize()
        input_hashes=[sha(t.contiguous().numpy().tobytes()) for t in cpu_inputs]
        save(out/'output_contract.json',{'slots':slots,'scope':'Actual eager returned tensors and direct native API input/output aliases; independently check raw API stack/construct.'})
        storage=Path('/private_batch')/case['case_id'];storage.mkdir(exist_ok=False)
        holder=torch.nn.Module();holder.add_module('forward_region',wrapper)
        debugger=None
        for call_id in range(3):
            model_adapter.STATE['forward']=call_id;begin=len(model_adapter.STATE['calls']);started=time.monotonic()
            if call_id==1 and collector is not None:debugger=configure(out,collector)
            active=debugger is not None and call_id==1
            if active:debugger.start(model=holder,rank_id=0)
            print(json.dumps({'schema':'fault28.eager.forward_marker.v1','event':'enter','call_id':call_id,'pid':os.getpid()}),flush=True)
            try:
                with torch.inference_mode():outputs=wrapper(*inputs)
                torch.npu.synchronize()
            finally:
                if active:debugger.stop();debugger.step()
            if scope=='model':
                outputs=(outputs,*model_adapter.STATE.pop('observations'))
            print(json.dumps({'schema':'fault28.eager.forward_marker.v1','event':'exit','call_id':call_id,'pid':os.getpid()}),flush=True)
            calls=model_adapter.STATE['calls'][begin:]
            assert [c['layer'] for c in calls]==([0] if scope=='calibration' else list(range(28)))
            assert len(outputs)==len(slots)
            values=[]
            for item,tensor in zip(slots,outputs):
                cpu=tensor.detach().cpu().contiguous();assert cpu.dtype==torch.float16 and cpu.shape[0]==8 and bool(torch.isfinite(cpu).all())
                raw=cpu.numpy().tobytes();target=cpu[0].numpy().tobytes();name='value_%03d.fp16.bin'%item['slot']
                if call_id==0:
                    (private/name).write_bytes(raw if item['kind']=='logits' else target)
                    if item['kind']!='logits':(storage/name).write_bytes(raw)
                values.append(dict(item,shape=list(cpu.shape),dtype=str(cpu.dtype),full_sha256=sha(raw),target_sha256=sha(target),
                    request_sha256=[sha(row.numpy().tobytes()) for row in cpu],target_file='private_output/'+name,
                    private_batch_relative=case['case_id']+'/'+name if item['kind']!='logits' else None))
            assert all(sha(t.detach().cpu().contiguous().numpy().tobytes())==h for t,h in zip(inputs,input_hashes))
            result['calls'].append({'call_id':call_id,'phase':'warmup' if call_id==0 else 'statistics_forward' if active else 'uncaptured_repeat',
                'values':values,'api_markers':calls,'inputs_unchanged':True,'elapsed_seconds':time.monotonic()-started,
                'logits_top1':outputs[0].detach().cpu()[:,0,:].argmax(-1).tolist() if scope=='model' else None})
        assert not forbidden and not torch.compiler.is_compiling()
        assert getattr(wrapper,'_compiled_call_impl',None) is None
        assert not any(p.name.startswith('dynamo_optimized_graph_') for p in out.rglob('*'))
        if model is not None:
            assert params_before==parameters(model)
            save(out/'parameters_receipt.json',{'unchanged_after_three_forwards':True,'loaded_parameters_sha256':file_sha(out/'loaded_parameters.json')})
        maps=Path('/proc/self/maps').read_text()
        save(out/'loaded_native_libraries.json',{'paths':sorted({x.split()[-1] for x in maps.splitlines() if '.so' in x and len(x.split())>=6})})
        if collector is not None:
            files=[]
            for name in ('dump','stack','construct'):
                p=out/'observation/step0/rank0'/(name+'.json');assert p.is_file()
                files.append({'path':str(p.relative_to(out)),'sha256':file_sha(p),'bytes':p.stat().st_size})
            raw=json.loads((out/'observation/step0/rank0/dump.json').read_bytes())
            apis=[k for k in raw['data'] if k.startswith('NPU.npu_fused_infer_attention_score.')]
            assert len(apis)==(1 if scope=='calibration' else 28),apis
            assert raw['task']=='statistics' and raw['level']=='mix' and raw.get('dump_data_dir') is None
            save(out/'statistics_receipt.json',{'files':files,'actual_steps':[0],'native_FIA_API_records':apis,'all_raw_records':len(raw['data'])})
        stable=all([v['full_sha256'] for v in c['values']]==[v['full_sha256'] for v in result['calls'][0]['values']] for c in result['calls'])
        result.update(status='CAPTURE_COMPLETED',repeated_all_outputs_equal=stable,parameters_unchanged=model is not None,
            actual_eager_forwards=3,actual_eager_FIA_API_calls=len(model_adapter.STATE['calls']),
            torch_compile_calls=0,actual_process_core_limit=actual_limit,statistics_steps=[0] if collector is not None else [])
    except BaseException:
        result.update(status='FAIL',traceback=traceback.format_exc())
    finally:
        save(out/'result.json',result)
    print(json.dumps({'status':result['status'],'case_id':case['case_id'],'error':result.get('traceback','')[-6500:]}),flush=True)
    return 0 if result['status']=='CAPTURE_COMPLETED' else 1


if __name__=='__main__':raise SystemExit(main())
