"""CPU-only behavioral verification of the temporary selected-card lease."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time
import docker_guard as policy

IMAGE = 'sha256:8988c3cd3a971a72ebb2e5baae24e0091cde55146f96d2b4c8229448210735b9'


def run(args,env=None):
    return subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                          universal_newlines=True,timeout=20)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory',type=Path,required=True)
    a = p.parse_args()
    state = json.loads((a.directory/'lease.json').read_text())
    env = dict(os.environ)
    env[policy.KEY_ENV] = json.loads((a.directory/'credential.json').read_text())['key']
    assert policy.creation_reasons(['--device','/dev/davinci2:/dev/davinci2'],2)
    assert policy.creation_reasons(['--device=/dev/davinci2'],2)
    assert not policy.creation_reasons(['--device','/dev/davinci5','--privileged=false'],2)
    assert policy.creation_reasons(['--mount','type=bind,source=/dev,target=/dev'],2)
    name = 'dcat-f28-eager-lease-selftest'
    target = run(['docker','run','-d','--name',name,'--label','demoncat.task='+policy.TASK,
                  '--network','none','--memory','64m','--cpus','.25','--device','/dev/davinci2',
                  '--entrypoint','/bin/sleep',IMAGE,'180'],env)
    assert target.returncode == 0,target.stderr
    cid = target.stdout.strip()
    checks = []
    try:
        for command in (['docker','stop','--time','1',cid],['docker','kill',cid],
                        ['docker','rm','-f',cid],['docker','container','stop',cid],
                        ['docker','exec',cid,'/bin/true']):
            q = run(command)
            assert q.returncode == 75,(command,q.returncode,q.stderr)
            checks.append({'operation':command[1],'unauthorized_returncode':q.returncode})
        obj = json.loads(run(['docker','inspect',cid]).stdout)[0]
        assert obj['State']['Running'] and not obj['State']['OOMKilled']
        assert run(['docker','exec',cid,'/bin/true'],env).returncode == 0
        other_name = 'dcat-f28-eager-lease-denied-create'
        denied = run(['docker','create','--name',other_name,'--device','/dev/davinci2',IMAGE,'/bin/true'])
        assert denied.returncode == 75
        assert run([str(a.directory/'docker.real'),'inspect',other_name]).returncode != 0
        assert run(['docker','ps','-q']).returncode == 0
        result = {'schema':'fault28.card2_lease_validation.v1',
                  'status':'PASS_PROTECTED_MUTATIONS_NEW_CARD2_ALLOCATION_AND_AUTHORIZED_CONTROLLER',
                  'time':time.time(),'no_NPU_calls':True,'protected_container_id':cid,
                  'blocked_operations':checks,'new_unauthorized_card2_container_created':False,
                  'authorized_exec_succeeded':True,'read_only_queries_succeeded':True,
                  'card5_creation_policy_allowed':True,'expires_at':state['expires_at']}
    finally:
        cleaned = run(['docker','rm','-f',cid],env)
        assert cleaned.returncode == 0,cleaned.stderr
    result['authorized_cleanup_succeeded'] = True
    with (a.directory/'validation.json').open('x') as stream:
        json.dump(result,stream,indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
