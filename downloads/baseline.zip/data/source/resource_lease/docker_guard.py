"""Temporary, explicit card2 Docker-CLI lease, authorized by the user.

Protects this capture's containers and rejects new selected-card allocations.
Read-only commands and unrelated devices delegate to the original executable.
This is resource coordination for observed CLI callers, not a root security
boundary or Docker-daemon authorization plugin. It never changes tensor data.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

TASK = 'fault28-eager-20261110'
KEY_ENV = 'DEMONCAT_CARD2_LEASE_KEY'
MUTATE = {'stop','kill','rm','restart','pause','unpause','rename','update','exec','attach','commit'}


def command(args):
    value_options = {'-H','--host','--context','--config','-c','--log-level','-l',
                     '--tlscacert','--tlscert','--tlskey'}
    i = 0
    while i < len(args):
        part = args[i]
        if part in value_options:
            i += 2
        elif part.startswith('-'):
            i += 1
        else:
            break
    if i >= len(args):
        return '', []
    operation = args[i]
    tail = args[i+1:]
    if operation == 'container' and tail:
        operation, tail = tail[0], tail[1:]
    return operation, tail


def creation_reasons(args, card):
    reasons = []
    target = '/dev/davinci'+str(card)
    for index, part in enumerate(args):
        flag, equal, value = part.partition('=')
        if not equal and index+1 < len(args):
            value = args[index+1]
        if flag == '--privileged' and (not equal or value.lower() not in ('false','0')):
            reasons.append('privileged_access_to_selected_card')
        if flag in ('--device-cgroup-rule','--device-request'):
            reasons.append('unrestricted_or_unproven_device_grant')
        if flag == '--device' and value.split(':',1)[0] == target:
            reasons.append('selected_device_node')
        if flag in ('-v','--volume') and value.split(':',1)[0].rstrip('/') in ('','/dev',target):
            reasons.append('selected_device_or_broad_device_bind')
        if flag == '--mount':
            fields = dict(item.split('=',1) for item in value.split(',') if '=' in item)
            source = fields.get('src',fields.get('source','')).rstrip('/')
            if source in ('','/dev',target) and fields.get('type') == 'bind':
                reasons.append('selected_device_or_broad_mount')
    return sorted(set(reasons))


def selected_capability(obj, card):
    h = obj.get('HostConfig',{})
    if h.get('Privileged') or h.get('DeviceCgroupRules') or h.get('DeviceRequests'):
        return True
    target = '/dev/davinci'+str(card)
    if any(x.get('PathOnHost') == target for x in h.get('Devices') or []):
        return True
    return any((x.get('Source','').rstrip('/') or '/') in ('/','/dev',target)
               for x in obj.get('Mounts') or [])


def inspect_targets(real, args):
    # Inspect only; values that are not existing containers are ignored. No
    # command contents, environment variables or secrets enter the lease log.
    results = {}
    for value in args:
        if not value or value.startswith('-') or ':' in value or '\n' in value:
            continue
        p = subprocess.run([str(real),'inspect','--type','container',value],
                           stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,universal_newlines=True,timeout=5)
        if p.returncode == 0:
            for obj in json.loads(p.stdout):
                results[obj['Id']] = obj
    return list(results.values())


def is_protected(obj, card):
    labels = obj.get('Config',{}).get('Labels') or {}
    return labels.get('demoncat.task') == TASK and selected_capability(obj,card)


def decision(args, state, real, authenticated):
    operation, tail = command(args)
    if authenticated:
        return True, operation, [], []
    if operation in ('run','create'):
        reasons = creation_reasons(tail,state['card'])
        if reasons and not authenticated:
            return False, operation, reasons, []
    if operation in MUTATE or operation == 'start':
        targets = inspect_targets(real,tail)
        protected = [x['Id'] for x in targets if is_protected(x,state['card'])]
        if protected and not authenticated:
            return False, operation, ['capture_container_protected'], protected
        if operation in ('start','restart','unpause') and not authenticated and any(selected_capability(x,state['card']) for x in targets):
            return False, operation, ['new_selected_card_execution'], [x['Id'] for x in targets]
    return True, operation, [], []


def main(directory):
    root = Path(directory)
    real = root/'docker.real'
    # The executable backup is immutable for this bounded lease. If the lease
    # is expired/ended, delegate immediately even before the watchdog unmounts.
    try:
        state = json.loads((root/'lease.json').read_text())
        active = time.time() < state['expires_at'] and not (root/'RELEASE').exists()
    except (OSError,ValueError,KeyError):
        active = False
        state = {}
    args = sys.argv[1:]
    if active:
        key = os.environ.get(KEY_ENV,'')
        authenticated = bool(key) and hashlib.sha256(key.encode()).hexdigest() == state.get('token_sha256')
        allowed, operation, reasons, targets = decision(args,state,real,authenticated)
        if not allowed:
            event = {'schema':'fault28.card2_lease.rejected_command.v1','time':time.time(),
                     'caller_pid':os.getppid(),'operation':operation,'card':state['card'],
                     'reasons':reasons,'protected_ids':targets,'expires_at':state['expires_at']}
            try:
                fd = os.open(str(root/'rejections.jsonl'),os.O_WRONLY|os.O_APPEND|os.O_CREAT,0o600)
                try:
                    os.write(fd,(json.dumps(event)+'\n').encode())
                finally:
                    os.close(fd)
            except OSError:
                pass
            sys.stderr.write('Temporary card2 resource lease: command rejected for fault28 capture; '+','.join(reasons)+'\n')
            return 75
    os.execv(str(real),['docker']+args)

