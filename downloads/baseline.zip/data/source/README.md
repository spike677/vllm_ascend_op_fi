# 故障28：真实FIA eager模式测试与验收

2026-11-10在124物理卡2完成固定形状的受控机制和完整模型验收。此结论独立于之前的TorchAir/GE图模式；模型以PyTorch eager执行，禁止调用 `torch.compile`，直接通过公开FIA API进入ACLNN V3。软件为CANN 9.1.0、torch 2.10.0、torch-npu 2.10.0.post4、transformers 5.5.4，Ascend910B4。

| 项目 | 本轮实际结果 |
| --- | --- |
| 模型与输入 | Qwen3-0.6B，28层；8个不同固定请求；2048-token、FP16、BNSD、causal sparse2、inner_precise=0 |
| 执行预算 | 单进程16 Cube/32 Vector核，逻辑device0映射物理卡2 |
| 注入 | B：M512；F：每次符合条件均M128；B/F共用同一causal尾块规则、host和OPC二进制 |
| 全层/请求覆盖 | B/F各3次前向、84次FIA、672个层/请求单元；总计168次FIA、1344个单元 |
| 统计 | 原生API/module statistics/mix，无过滤，同一CPU-FP64 high collector；每组真实仅step0 |
| 独立首差 | 第0层 NPU.npu_fused_infer_attention_score.0.forward 的output[0]，Mean/Norm |
| 完整数组 | 首差层所有请求Q/K/V一致；Attention变化传播到全部8请求的首token logits |
| logits | 1,070,967个元素不同，最大绝对差0.0546875；8请求Top-1均不变 |
| 稳定与恢复 | 每组全部113项观测三轮重复一致；OFF三轮全部113项、全部请求精确恢复 |

验收状态为 `PASS_EAGER_PREFILL_WITH_SCOPE_LIMITS`。原始result.json只回执采集完成，不代替独立验收。

## 真实调用链与关键代码

```text
eager_probe.py：加载固定checkpoint、请求，设定核预算并禁止torch.compile
→ model_adapter.FullModelEager.forward：真实HF Qwen3前向
→ 全部28层Qwen3Attention / 注册的attention入口
→ torch_npu.npu_fused_infer_attention_score（msprobe原生API钩子）
→ aclnnFusedInferAttentionScoreV3（实际ACLNN日志确认）
→ 私有host：真实输入、23项条件及进程作用域校验，选择M
→ 原生host生成依赖tiling，观察实际1576-byte public raw/POD
→ 原生runtime运行OPC编译的相应FIA kernel
→ 模型后续层、lm_head、首token logits
```

`model_adapter.py` 的native_fia不缓存钩子初始化前的API；attention/install绑定全部28层，没有固定层号或一次命中限制。FullModelEager返回真实logits，并保留同一批Q/K/V/Attention对象供采集停止后的完整数组观察，避免顶层module重复统计113个中间别名。不筛掉模型API/module，不篡改FIA输入或返回值。

底层沿用匹配源码commit `c77c0829f1f0f0b8f882db1d9b051a758b605472` 的受控策略。冻结的fault28_fia_policy.h的Select检查进程/PID起始时间/随机作用域、格式、形状、dtype、causal参数和核预算；batch_causal_m128对匹配B8每次选择M128。fia_tiling_nonquant.cpp在真实M选择边界应用策略并重算依赖参数。环境变量保留旧FAULT28_FIA_GRAPH前缀，不能据名字推断模型在图模式执行。

B/F实际key为109000000000000000、109000000000400000，同一文件内的合法模板；OFF为103000000000000000。M128同时启用合法M相关Brcb派生模板。fault28_causal_tile.h及GQA Cube/Vec源码按实际M块上界裁剪causal尾部宽度：S2基本块仍512，早期query的宽度可由512变成128/256/384，未屏蔽key覆盖完整。浮点softmax/归约路径因此改变；不能将误差唯一分配到某条Reduce指令或排除其他M相关模板效应。

## eager包与实际执行

旧图包只有host/JIT源码，缺少eager二进制和完整ACLNN总索引，直接复用会在执行前报找不到key。本轮通过官方OPC为Ascend910B4、FP16输出编译上述三key，再用匹配release的ascendc_ops_config.py生成binary_info_config.json。没有手改tiling raw、kernel元数据中的key/符号或机器码。

最终新包清单SHA256为 `88b06b9d30c24a7120332f9a4dbcf38e6db01fbc004cdcddd788b10575f0adc3`。B/F/OFF共用同一完整文件清单，只在任务私有进程环境加载；系统SDK及旧图包不改。CPU编译成功不计为NPU验收。此二进制只覆盖当前三key，不是任意FIA形状/分支的通用替换包；适配器显式限制几何、精度和causal参数，不能把本轮结果推广至未知调用。

## 原始msprobe与独立定位

```ini
task = statistics
level = mix
summary_mode = statistics
precision = high
async_dump = false
step = [0]
```

两组均保留完整原生dump/stack/construct、config、collector身份及完成回执，不公开整批.pt。真实step0是第二次实际前向；第一轮预热、第三轮未采集重复，三轮都不是生成token步数。每组1616条记录中有1189条API、427条module；FIA内部融合子算子不会另成msprobe API。416项不可观测统计保持null，不当作数值相等。

high使用披露的任务私有CPU-FP64官方采集器修改版，完整源码和加载SHA随证据导出；全部真实浮点张量同样处理，无目标算子或故障模式特判。

| 首差原始字段 | B | F |
| --- | --- | --- |
| output[0].Mean | -0.002108109542442449 | -0.002108109450752238 |
| output[0].Norm | 660.5721173259877 | 660.572120054888 |

analysis/compare_statistics.py仅读取原始统计/配置/栈/构造关系，不用注入器、运行结果或期望profile选择首差。模块返回值与其内部API执行顺序区分。baseline自比无差异；临时副本中修改更早Functional.embedding.0.forward统计时，定位器报告embedding而非FIA。这个负对照只是CPU合成定位器检查，原证据不改，不冒充NPU故障。

analysis/audit_runtime.py单独审查每次实际API窗口、真实host选核、native launch、public raw与全部层/请求映射；analysis/compare_model.py对私有完整8请求数组逐元素及完整字节摘要核对；analysis/review_pair.py在独立定位之后验收机制和传播。不能用命中日志替代这三类证据。

## 实机矩阵、交付与边界

固定真实Q/K/V校准为cal_card2_a2/cal_stock与cal_card2_bf_a3的B/F/OFF，各3次调用。stock=B=OFF完整输出一致；F只改变Attention及消费者。完整正式组为model_card2_B_a2/baseline、model_card2_F_a2/fault，另有不采集统计的model_card2_OFF_a2/model_restore控制，三个进程均完成三次完整模型前向。挂载失败、缺binary/index和第一轮540秒超时的基线均保留私有记录，未进入B/F交付。

公开仅baseline/fault两组statistics，ZIP为baseline.zip/fault.zip，合并解压到data/cases。完整报告、实际源码、host/schema和collector证据随baseline.zip导出；OFF只提供恢复比较/运行审查摘要，不增加第三组统计。原始字节和真实step数不变；完整私有张量、权重、编译二进制、大DEBUG日志与私有输入token清单不上传。

两次临时卡2Docker CLI隔断分别获得明确45分钟、20分钟授权，均已提前恢复原入口SHA256 `e95b17c978781194139f48cc1998826ae16b6851fadd4699df677dcafedf8a65`，没有停止卡5任务。隔断仅针对已观察的CLI清理/派发路径，不声称阻断root直接Docker API或host PID操作。

本轮仅证明固定B8/2048-token eager受控M策略、完整覆盖、重复稳定、关闭恢复与首token logits传播。没有重新验收eager原生B1/B8自然切换、历史盘古版本、连续生成、文本质量、默认SDPA等价性或任意形状/模型。统计首差符合该受控路径预期，统计本身不能唯一证明物理根因。
