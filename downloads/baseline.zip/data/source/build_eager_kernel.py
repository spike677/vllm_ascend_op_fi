"""CPU-only official OPC build for the existing FIA policy's three keys.

The same new private package serves B/F/OFF. No SDK, old stage, host policy,
kernel arithmetic, output or raw tiling bytes are modified by this builder.
"""
import argparse,hashlib,json,shutil,subprocess,time,re
from pathlib import Path

ROOT=Path('/home/fault28-eager-20261110')
OLD=Path('/home/fault28-fia-fullmodel-20261109/vendor_stage_a5')
IMAGE='sha256:8988c3cd3a971a72ebb2e5baae24e0091cde55146f96d2b4c8229448210735b9'
KEYS=[103000000000000000,109000000000000000,109000000000400000]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--generation',required=True)
    generation=parser.parse_args().generation;assert re.fullmatch('a[1-9][0-9]*',generation)
    assert sha(OLD/'vendor_manifest.json')=='205988e230b901421f14eb0844ce435b66647a5846324608d768d313a66f8cd2'
    stage=ROOT/('vendor_eager_'+generation);assert not stage.exists()
    shutil.copytree(OLD,stage,symlinks=True)
    manifest=json.loads((stage/'vendor_manifest.json').read_text())
    vendor=stage/'vendors/fault28_fia_graph_transformer'
    for row in manifest['artifacts']:assert sha(vendor/row['path'])==row['sha256']
    ev=ROOT/'build'/('eager_kernel_'+generation);ev.mkdir(parents=True,exist_ok=False)
    param=Path('/home/fault28-fia-graph-20261106/source_a4/ops-transformer-v9.1.0/build/binary/ascend910b/gen/FusedInferAttentionScore_8cd36e66e4ceb2d60ef96db29a147347_param.json')
    contract=json.loads(param.read_text())['op_list'][0]
    assert contract['outputs'][0]['dtype']=='float16' and all((x[0] if isinstance(x,list) else x)['dtype']=='float16' for x in contract['inputs'][:3])
    shutil.copyfile(param,ev/'input_param.json')
    script='''set -eo pipefail
source /usr/local/Ascend/cann-9.1.0/set_env.sh
source /work/venv/bin/activate
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=2
export ASCEND_GLOBAL_LOG_LEVEL=0 ASCEND_SLOG_PRINT_TO_STDOUT=1 ASCENDC_LOG_LEVEL=0
export ASCEND_CUSTOM_OPP_PATH=/audit/vendor_eager_a1/vendors/fault28_fia_graph_transformer
cd /audit/build/eager_kernel_a1
mkdir output
python /usr/local/Ascend/cann-9.1.0/python/site-packages/opc_tool/opc.py /audit/vendor_eager_a1/vendors/fault28_fia_graph_transformer/op_impl/ai_core/tbe/fault28_fia_graph_transformer_impl/dynamic/fused_infer_attention_score.py --main_func=fused_infer_attention_score --input_param=/audit/build/eager_kernel_a1/input_param.json --soc_version=Ascend910B4 --output=/audit/build/eager_kernel_a1/output --impl_mode=high_performance,optional --simplified_key_mode=0 --op_mode=dynamic --tiling_key=103000000000000000,109000000000000000,109000000000400000 --op_debug_config=dump_cce
'''
    script=script.replace('_a1','_'+generation)
    (ev/'compile.sh').write_text(script)
    cmd=['docker','run','--rm','--network','none','--cpus','4','--memory','12g','--pids-limit','512',
        '--name','dcat-f28-eager-kernel-build-'+generation,'--mount','type=bind,src='+str(ROOT)+',dst=/audit',
        '--mount','type=bind,src=/home/tik-constfold-cann91-overnight-20261022,dst=/work,readonly',
        '--entrypoint','bash',IMAGE,'/audit/build/eager_kernel_'+generation+'/compile.sh']
    start={'command':cmd,'source_manifest_sha256':sha(OLD/'vendor_manifest.json'),
        'input_param_sha256':sha(ev/'input_param.json'),'keys':KEYS,'devices':[],
        'npu_executed':False,'started_at':time.time(),'script_sha256':sha(ev/'compile.sh')}
    (ev/'start.json').write_text(json.dumps(start,indent=2)+'\n')
    with (ev/'compile.log').open('x') as log:
        rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
    done={'returncode':rc,'finished_at':time.time(),'compile_log_sha256':sha(ev/'compile.log'),
        'status':'COMPILE_RETURNED_SUCCESS_NOT_NPU_VALIDATED' if rc==0 else 'FAIL_CPU_COMPILE','npu_executed':False}
    (ev/'compile_completion.json').write_text(json.dumps(done,indent=2)+'\n')
    print(json.dumps(done),flush=True)
    return rc

if __name__=='__main__':raise SystemExit(main())
