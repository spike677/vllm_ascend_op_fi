"""Complete the private package with the matching source's official index tool."""
import hashlib,json,shutil,subprocess,time
from pathlib import Path

ROOT=Path('/home/fault28-eager-20261110')
IMAGE='sha256:8988c3cd3a971a72ebb2e5baae24e0091cde55146f96d2b4c8229448210735b9'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    old=ROOT/'vendor_eager_a4';new=ROOT/'vendor_eager_a5'
    assert sha(old/'vendor_manifest.json')=='c6bd4cae96badb25bed875586be56c9c9dbb643002b4f4fc7959f8b6432a32e2'
    shutil.copytree(old,new,symlinks=True)
    ev=ROOT/'build/eager_index_a5';ev.mkdir(parents=True,exist_ok=False)
    source=Path('/home/fault28-fia-graph-20261106/source_a4/ops-transformer-v9.1.0/cmake/scripts/util')
    for name in ('ascendc_ops_config.py','const_var.py'):shutil.copyfile(source/name,ev/name)
    script='''set -e
source /usr/local/Ascend/cann-9.1.0/set_env.sh
source /work/venv/bin/activate
export PYTHONDONTWRITEBYTECODE=1
python -B /audit/build/eager_index_a5/ascendc_ops_config.py --path /audit/vendor_eager_a5/vendors/fault28_fia_graph_transformer/op_impl/ai_core/tbe/kernel/ascend910b --soc ascend910b --out /audit/vendor_eager_a5/vendors/fault28_fia_graph_transformer/op_impl/ai_core/tbe/kernel/config/ascend910b --op-range normal
'''
    (ev/'generate.sh').write_text(script)
    cmd=['docker','run','--rm','--network','none','--cpus','1','--memory','1g','--pids-limit','128',
        '--mount','type=bind,src='+str(ROOT)+',dst=/audit',
        '--mount','type=bind,src=/home/tik-constfold-cann91-overnight-20261022,dst=/work,readonly',
        '--entrypoint','bash',IMAGE,'/audit/build/eager_index_a5/generate.sh']
    subprocess.run(cmd,check=True,timeout=60)
    v=new/'vendors/fault28_fia_graph_transformer'
    index=v/'op_impl/ai_core/tbe/kernel/config/ascend910b/binary_info_config.json'
    d=json.loads(index.read_text());assert list(d)==['FusedInferAttentionScore'] and len(d['FusedInferAttentionScore']['binaryList'])==1
    receipt={'status':'CPU_OFFICIAL_INDEX_GENERATED_NOT_NPU_VALIDATED','time':time.time(),'npu_executed':False,
        'generator_sha256':sha(ev/'ascendc_ops_config.py'),'generator_constants_sha256':sha(ev/'const_var.py'),
        'binary_info_config_sha256':sha(index),'original_sdk_unchanged':True,
        'compiler_kernel_machine_code_unchanged':True,
        'scope':'Official generator adds filePath to compiler JSON and generates the ACLNN summary/per-op index; no tiling or arithmetic changes.'}
    (ev/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n')
    m=json.loads((new/'vendor_manifest.json').read_text());m.update(generation='eager_a5',
        vendor_root='vendor_eager_a5/vendors/fault28_fia_graph_transformer',eager_index_generation=receipt)
    m['artifacts']=[{'path':p.relative_to(v).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(v.rglob('*')) if p.is_file()]
    (new/'vendor_manifest.json').write_text(json.dumps(m,indent=2)+'\n')
    print(json.dumps({'status':receipt['status'],'manifest_sha256':sha(new/'vendor_manifest.json'),'artifacts':len(m['artifacts'])}))

if __name__=='__main__':main()
