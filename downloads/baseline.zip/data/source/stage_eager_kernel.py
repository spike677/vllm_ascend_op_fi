"""Register official OPC outputs in a new task-private eager package only."""
import argparse,hashlib,json,shutil,subprocess,sys,time
from pathlib import Path

ROOT=Path('/home/fault28-eager-20261110')
IMAGE='sha256:8988c3cd3a971a72ebb2e5baae24e0091cde55146f96d2b4c8229448210735b9'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def inside(generation):
    root=Path('/audit');ev=root/'build'/('eager_kernel_'+generation)
    stage=root/('vendor_eager_'+generation);vendor=stage/'vendors/fault28_fia_graph_transformer'
    done=json.loads((ev/'compile_completion.json').read_text());assert done['returncode']==0
    param=json.loads((ev/'input_param.json').read_text());name=param['op_list'][0]['bin_filename']
    candidates=list((ev/'output').rglob(name+'.json'));assert len(candidates)==1
    meta=candidates[0];data=json.loads(meta.read_text());binary=meta.with_suffix('.o')
    assert data['sha256']==sha(binary) and data['binFileName']==name
    keys={int(x['tilingKey']) for x in data['kernelList']}
    assert keys=={103000000000000000,109000000000000000,109000000000400000}
    sdk=Path('/usr/local/Ascend/cann-9.1.0/opp/built-in/op_impl/ai_core/tbe/kernel')
    config=sdk/'config/ascend910b/ops_transformer/fused_infer_attention_score.json'
    original=json.loads(config.read_text());selected=[x for x in original['binList'] if Path(x['binInfo']['jsonFilePath']).stem==name]
    assert len(selected)==1 and selected[0]['outputs'][0]['dtype']=='float16'
    dest=vendor/'op_impl/ai_core/tbe/kernel'
    output=dest/'ascend910b/fused_infer_attention_score';output.mkdir(parents=True,exist_ok=False)
    for f in (meta,binary):shutil.copyfile(f,output/f.name)
    configs=dest/'config/ascend910b';configs.mkdir(parents=True,exist_ok=False)
    # SDK dtype/format/attrs matcher is byte-derived; only its relative package
    # path changes. Tiling keys, symbols, resource metadata and machine code are
    # the official compiler outputs, not hand-edited replacements.
    selected[0]['binInfo']['jsonFilePath']='ascend910b/fused_infer_attention_score/'+meta.name
    (configs/'fused_infer_attention_score.json').write_text(json.dumps({'binList':selected},indent=2)+'\n')
    receipt={'schema':'fault28.eager.kernel_registration.v1','status':'CPU_STAGED_NPU_VALIDATION_REQUIRED',
        'time':time.time(),'source_generation':generation,'sdk_registry_sha256':sha(config),
        'compiler_metadata_sha256':sha(meta),'binary_sha256':sha(binary),'compiled_keys':sorted(keys),
        'kernel_symbols':[x['kernelName'] for x in data['kernelList']],
        'source_policy_arithmetic_changed':False,'global_sdk_modified':False,'npu_executed':False,
        'scope':'Only this FP16 dtype/current validated geometry; this restricted binary does not support arbitrary eager FIA shapes or keys.'}
    (ev/'registration.json').write_text(json.dumps(receipt,indent=2)+'\n')
    manifest=json.loads((stage/'vendor_manifest.json').read_text())
    manifest.update(vendor_root='vendor_eager_'+generation+'/vendors/fault28_fia_graph_transformer',
        status='CPU_EAGER_KERNEL_REGISTERED_NOT_NPU_VALIDATED',generation='eager_'+generation,
        eager_kernel_registration=receipt)
    manifest['artifacts']=[{'path':str(p.relative_to(vendor)),'bytes':p.stat().st_size,'sha256':sha(p)}
        for p in sorted(vendor.rglob('*')) if p.is_file()]
    (stage/'vendor_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'status':receipt['status'],'manifest_sha256':sha(stage/'vendor_manifest.json'),
        'artifacts':len(manifest['artifacts']),'kernel_symbols':receipt['kernel_symbols']}))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--generation',required=True);p.add_argument('--inside',action='store_true');a=p.parse_args()
    assert a.generation[0]=='a' and a.generation[1:].isdigit()
    if a.inside:return inside(a.generation)
    cmd=['docker','run','--rm','--network','none','--cpus','1','--memory','1g','--pids-limit','128',
        '--mount','type=bind,src='+str(ROOT)+',dst=/audit','--entrypoint','/usr/bin/python3',IMAGE,
        '-B','/audit/stage_eager_kernel.py','--generation',a.generation,'--inside']
    subprocess.run(cmd,check=True,timeout=60)

if __name__=='__main__':main()
