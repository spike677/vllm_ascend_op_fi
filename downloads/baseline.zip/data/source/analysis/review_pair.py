"""Separate native numerical localization, actual execution and complete arrays."""
import argparse,hashlib,json
from pathlib import Path
from audit_runtime import audit
from compare_statistics import compare as statistics
from compare_model import compare as complete

R=Path('/home/fault28-eager-20261110')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):
    with p.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    out=a.output;out.mkdir(parents=True,exist_ok=False)
    folders={'baseline':R/'outputs/model_card2_B_a2/baseline','fault':R/'outputs/model_card2_F_a2/fault',
             'OFF':R/'outputs/model_card2_OFF_a2/model_restore'}
    runtime={}
    for name,folder in folders.items():
        runtime[name]=audit(folder);save(out/('runtime_'+name+'.json'),runtime[name])
    manifests=[json.loads((x.parent/'source_manifest.json').read_text()) for x in folders.values()]
    assert manifests[0]==manifests[1]==manifests[2],'B/F/OFF frozen execution sources changed'
    first=statistics(folders['baseline']/'observation/step0/rank0/dump.json',folders['fault']/'observation/step0/rank0/dump.json')
    save(out/'independent_first_difference_full.json',first)
    numerical=complete(folders['baseline'],folders['fault']);save(out/'complete_output_comparison.json',numerical)
    off=complete(folders['baseline'],folders['OFF']);save(out/'complete_OFF_comparison.json',off)
    off_bytes_exact=all(x['B_sha256']==x['F_sha256'] for x in off['comparisons'])
    first_qkv=[x for x in numerical['comparisons'] if x['layer']==numerical['first_changed_attention_layer'] and x['kind'] in ('query','key','value')]
    qkv_bytes_exact=len(first_qkv)==3 and all(x['B_sha256']==x['F_sha256'] for x in first_qkv)
    # Check expected mechanism only AFTER the generic independent localizer has
    # selected its first boundary without runtime/policy/output-result input.
    observed=first.get('first_observed_api_difference')
    expected=(first['status']=='ALIGNED_OBSERVED_API_DIFFERENCE' and observed is not None
        and observed['B_node']=='NPU.npu_fused_infer_attention_score.0.forward' and observed['boundary']=='output')
    rawB=runtime['baseline']['public_plan_unique'];rawF=runtime['fault']['public_plan_unique'];rawO=runtime['OFF']['public_plan_unique']
    assert len(rawB)==len(rawF)==len(rawO)==1
    b,f,o=[x[0] for x in (rawB,rawF,rawO)]
    bd,fd,od=[x['decoded'] for x in (b,f,o)]
    fixed=['baseParams.bSize','baseParams.n2Size','baseParams.gSize','baseParams.s1Size','baseParams.s2Size',
        'baseParams.usedCoreNum','innerSplitParams.s2BaseSize','fdParams.numOfFdHead']
    assert all(bd[k]==fd[k]==od[k] for k in fixed)
    assert bd['innerSplitParams.mBaseSize']==od['innerSplitParams.mBaseSize']==512 and fd['innerSplitParams.mBaseSize']==128
    assert b['plan']['pruned'] and f['plan']['pruned'] and not o['plan']['pruned']
    assert b['plan']['per_query_inner_width_histogram']!=f['plan']['per_query_inner_width_histogram']
    assert len({x['private_binary_sha256'] for x in runtime.values()})==1
    native_differences=[{'field':k,'B':bd[k],'F':fd[k]} for k in bd if bd[k]!=fd[k]]
    mechanism={'schema':'fault28.eager.mechanism_review.v1','status':'PASS_ACTUAL_HOST_AND_EXECUTED_KEY',
        'same_private_machine_code_all_modes':True,'private_binary_sha256':runtime['baseline']['private_binary_sha256'],
        'B_m':512,'F_m':128,'OFF_m':512,'same_causal_tail_rule_B_F':True,'no_SplitKV':bd['fdParams.numOfFdHead']==0,
        'B_actual_key':b['actual_host_key'],'F_actual_key':f['actual_host_key'],
        'M128_uses_native_M_dependent_Brcb_template':True,
        'raw_public_fields_changed':native_differences,'B_causal_plan':b['plan'],'F_causal_plan':f['plan'],
        'automatic_batch_policy':'Existing batch_causal_m128 rule selects M128 for matching B8; this round does not remeasure native B1/B8 strategy discovery.',
        'kernel_argument_raw_observed':False,'inner_reduce_is_direct_device_trace':False}
    save(out/'mechanism_review.json',mechanism)
    controls=json.loads((folders['baseline'].parent/'independent_localizer_controls.json').read_text())
    assert controls['status']=='PASS_SELF_AND_EARLIER_API_NEGATIVE_CONTROL'
    finite=all(json.loads((x/'result.json').read_text())['repeated_all_outputs_equal'] for x in folders.values())
    accepted=bool(expected and numerical['first_changed_attention_inputs_equal'] and
        numerical['first_changed_attention_layer']==0 and numerical['logits_changed_requests']==8 and
        off['all_observed_elements_equal'] and off_bytes_exact and qkv_bytes_exact and finite)
    report={'schema':'fault28.eager.acceptance.v1',
        'status':'PASS_EAGER_PREFILL_WITH_SCOPE_LIMITS' if accepted else 'NOT_ACCEPTED',
        'execution_mode':'eager','physical_card':2,'B_F_groups':['baseline','fault'],'actual_statistics_steps':[0],
        'B_F_eager_forwards':6,'B_F_actual_FIA_executions':168,'B_F_layer_request_executions':1344,
        'layers':28,'requests':8,'all_matching_calls_covered':True,'all_three_forwards_repeat_exact':finite,
        'torch_compile_calls':0,'first_independent_API_difference':observed,
        'first_changed_attention_QKV_complete_equal':numerical['first_changed_attention_inputs_equal'],
        'first_changed_attention_QKV_byte_identical':qkv_bytes_exact,
        'first_changed_attention_layer':numerical['first_changed_attention_layer'],
        'first_changed_last_query_attention_layer':numerical['first_changed_last_query_attention_layer'],
        'logits_changed_requests':numerical['logits_changed_requests'],'top1_changed_requests':numerical['top1_changed_requests'],
        'OFF_all_113_observed_arrays_all_8_requests_exact':off['all_observed_elements_equal'],
        'OFF_all_observed_arrays_byte_identical':off_bytes_exact,
        'native_statistics_records':first['all_aligned_records'],'native_API_records':first['native_API_records'],
        'unobservable_statistic_fields':first['unobservable_fields'],'all_B_F_frozen_execution_sources_equal':True,
        'full_private_tensors_exported':False,'B_result_sha256':sha(folders['baseline']/'result.json'),
        'F_result_sha256':sha(folders['fault']/'result.json'),
        'limits':['This is fixed B8/2048-token FP16 causal FIA eager prefill and first-token logits; no continuous generation or task-quality acceptance.',
            'The existing controlled common causal-tail variant is used in B/F; this is not a claim that stock current CANN naturally chooses these strategies across batches.',
            'No new eager B1/B8 same-query matrix or historical Pangu-version reproduction is claimed.',
            'All matching layers/requests within this fixed supported geometry are covered; arbitrary shapes/models/FIA branches are not validated.',
            'CPU-FP64 high statistics use a disclosed task-local modified official collector uniformly on every real floating tensor.',
            'Null/empty/nonfloating-statistics remain unobservable. Summaries alone do not prove complete tensor equality or a unique physical root.',
            'Actual public host raw/POD plus native launch corroborate the mechanism; inner Reduce grain is source-derived, not an instruction-level device trace.',
            'M128 also selects the legal M-dependent Brcb template; this experiment does not uniquely separate Reduce-grain rounding from other M-dependent template effects.',
            'Top-1 stability or change at one prefill does not establish generated-text correctness or business impact.']}
    save(out/'acceptance.json',report)
    print(json.dumps({k:report[k] for k in ('status','native_statistics_records','native_API_records','logits_changed_requests','top1_changed_requests','OFF_all_113_observed_arrays_all_8_requests_exact','first_independent_API_difference')}))
    return 0 if accepted else 1

if __name__=='__main__':raise SystemExit(main())
