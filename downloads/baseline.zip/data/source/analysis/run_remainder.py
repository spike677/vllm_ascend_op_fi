"""Continue F/OFF after successful B; never extend the existing lease deadline."""
import json,os,subprocess,time
from pathlib import Path

R=Path('/home/fault28-eager-20261110')
LEASE=R/'resource_lease/active-a2'
ALLOW='a8eeda3a5db34389fbcc83fdd8cabc99d687ac1db5aa4011a0586f2a9f0ddc4c'

def main():
    deadline=json.loads((LEASE/'lease.json').read_text())['expires_at']
    b=R/'outputs/model_card2_B_a2/completion.json'
    while not b.exists():
        assert time.time()<deadline-120,'Not enough original lease window remains'
        time.sleep(3)
    assert json.loads(b.read_text())['status']=='CAPTURE_COMPLETED','Baseline incomplete'
    br=json.loads((b.parent/'baseline/result.json').read_text())
    assert br['status']=='CAPTURE_COMPLETED' and br['repeated_all_outputs_equal'] and br['actual_eager_FIA_API_calls']==84
    env=dict(os.environ);env['DEMONCAT_CARD2_LEASE_KEY']=json.loads((LEASE/'credential.json').read_text())['key']
    reports=[]
    for attempt,case,reserve in [('model_card2_F_a2','fault',80),('model_card2_OFF_a2','model_restore',40)]:
        remain=int(deadline-time.time());seconds=min(840,remain-reserve)
        assert seconds>=60 and remain>=110,'Insufficient original lease window for '+case
        cmd=['python3','-B',str(R/'controller.py'),'--card','2','--attempt',attempt,
            '--probe','eager_probe.py','--case-file','setup/'+case+'.json','--capture','native-logs',
            '--max-seconds',str(max(180,min(900,seconds+45))),'--case-seconds',str(seconds),
            '--max-log-mib','4096','--allow-idle-container-ID',ALLOW]
        print(json.dumps({'event':'starting_remaining_case','case':case,'seconds':seconds,'lease_seconds_left':remain}),flush=True)
        with (R/'outputs'/('pipeline_'+case+'.log')).open('x') as stream:
            rc=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
        result=json.loads((R/'outputs'/attempt/'completion.json').read_text())
        reports.append({'attempt':attempt,'case':case,'rc':rc,'status':result['status']})
        print(json.dumps(reports[-1]),flush=True)
        assert rc==0 and result['status']=='CAPTURE_COMPLETED','Remaining case did not complete'
    (R/'outputs/remainder_completion.json').write_text(json.dumps({'status':'ALL_REMAINING_CAPTURES_COMPLETED','cases':reports},indent=2)+'\n')

if __name__=='__main__':main()
