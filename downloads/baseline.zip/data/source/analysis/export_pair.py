"""Whitelist original B/F statistics bytes and reviewed reports; no tensors."""
import argparse,collections,hashlib,json,shutil
from pathlib import Path

R=Path('/home/fault28-eager-20261110')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(obj,f,indent=2,allow_nan=False);f.write('\n')

class Export:
    def __init__(self,destination):
        self.root=destination;self.root.mkdir(parents=True,exist_ok=False);self.mapping=[]
    def copy(self,source,target):
        source=Path(source);target=self.root/target
        assert source.is_file() and not source.is_symlink() and source.stat().st_size<=256*1024**2
        assert source.suffix in ('.json','.jsonl','.py','.sh','.h','.cpp','.patch','.md','.yaml')
        target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
        shutil.copyfile(source,target);assert sha(source)==sha(target)
        self.mapping.append({'source':str(source),'exported':target.relative_to(self.root).as_posix(),
            'bytes':target.stat().st_size,'sha256':sha(target),'byte_preserved':True})

def lease_summary():
    windows=[]
    for n,limit in [('active-a1',2700),('active-a2',1200)]:
        d=R/'resource_lease'/n
        installed=json.loads((d/'install_receipt.json').read_text());restored=json.loads((d/'restore_receipt.json').read_text())
        assert restored['status']=='RESTORED_ORIGINAL_DOCKER_CLI' and restored['file_bind_removed']
        assert installed['original_sha256']==restored['original_sha256'] and restored['time']-installed['time']<=limit+10
        rejected=[json.loads(l) for l in (d/'rejections.jsonl').read_text().splitlines()] if (d/'rejections.jsonl').exists() else []
        windows.append({'window':n,'authorized_max_seconds':limit,'installed_at':installed['time'],
            'restored_at':restored['time'],'actual_seconds':restored['time']-installed['time'],
            'original_binary_sha256':restored['original_sha256'],'restored':True,
            'denied_operations_including_CPU_selftest':dict(collections.Counter(e['operation'] for e in rejected)),
            'install_receipt_sha256':sha(d/'install_receipt.json'),'restore_receipt_sha256':sha(d/'restore_receipt.json'),
            'private_credential_removed':not (d/'credential.json').exists()})
    assert all(w['private_credential_removed'] for w in windows)
    return {'schema':'fault28.eager.resource_operation_summary.v1','restored':True,'windows':windows,
        'second_window_explicit_user_approval':True,'raw_credential_exported':False,
        'daemon_or_SSH_configuration_changed':False,'card5_stopped_by_this_task':False,
        'scope':'Observed Docker CLI allocation/cleanup callers only; no direct Docker API/host-PID protection claim.'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--review',type=Path,required=True)
    p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
    review=a.review;acceptance=json.loads((review/'acceptance.json').read_text())
    assert acceptance['status']=='PASS_EAGER_PREFILL_WITH_SCOPE_LIMITS'
    lease=lease_summary();export=Export(a.destination);out=export.root
    folders={'baseline':R/'outputs/model_card2_B_a2/baseline','fault':R/'outputs/model_card2_F_a2/fault'}
    for role,folder in folders.items():
        prefix=Path('cases')/role
        names=['case.json','config.json','execution_config.json','collector_provenance.json','statistics_receipt.json',
            'inputs.json','output_contract.json','result.json','loaded_parameters.json','parameters_receipt.json',
            'versions.json','loaded_native_libraries.json','host_events.jsonl']
        names += ['observation/step0/rank0/'+x+'.json' for x in ('dump','stack','construct')]
        for name in names:export.copy(folder/name,prefix/name)
        originals=[p.relative_to(folder/'observation').as_posix() for p in (folder/'observation').rglob('*') if p.is_file()]
        assert set(originals)=={'step0/rank0/'+x+'.json' for x in ('dump','stack','construct')},originals
        for src,dst in [(folder.parent/'completion.json','capture_completion.json'),
            (folder.parent/'source_manifest.json','frozen_source_manifest.json'),
            (folder.parent/(role+'.controller.json'),'controller_case_completion.json'),
            (folder.parent/(role+'.vendor_launch.json'),'verified_vendor_launch.json'),
            (review/('runtime_'+role+'.json'),'actual_runtime_coverage.json')]:export.copy(src,prefix/dst)
    reports=['acceptance.json','independent_first_difference_full.json','complete_output_comparison.json',
        'complete_OFF_comparison.json','mechanism_review.json','runtime_OFF.json']
    for name in reports:export.copy(review/name,Path('reports')/name)
    export.copy(R/'outputs/model_card2_B_a2/independent_localizer_controls.json','reports/independent_localizer_controls.json')
    cal=json.loads((R/'outputs/cal_card2_bf_a3/calibration_acceptance.json').read_text())
    save(out/'reports/calibration_summary.json',{k:v for k,v in cal.items() if k in
        ('status','stock_B_OFF_all_outputs_exact','F_QKV_exact','repeated_all_outputs_exact')})
    save(out/'resource_lease/operation_summary.json',lease)
    for n in ('active-a1','active-a2'):
        for file in ('install_receipt.json','validation.json','restore_receipt.json'):
            export.copy(R/'resource_lease'/n/file,Path('resource_lease')/n/file)
    names=['controller.py','env.sh','vendor_exec.py','collector_stage.py','eager_probe.py','model_adapter.py',
        'build_eager_kernel.py','stage_eager_kernel.py','complete_eager_index.py']
    names += ['analysis/'+n for n in ('compare_statistics.py','statistics_values.py','public_plan.py',
        'audit_runtime.py','compare_model.py','review_pair.py','export_pair.py','run_remainder.py')]
    names += ['resource_lease/'+n for n in ('lease.py','docker_guard.py','validate.py')]
    for name in names:export.copy(R/name,Path('source')/name)
    export.copy(R/'README.md','source/README.md')
    for name in ('baseline','fault','model_restore'):export.copy(R/'setup'/(name+'.json'),Path('source/setup')/(name+'.json'))
    vendor=R/'vendor_eager_a5/vendors/fault28_fia_graph_transformer'
    export.copy(R/'vendor_eager_a5/vendor_manifest.json','build/vendor_manifest.json')
    for n in ('start.json','compile_completion.json','registration.json','input_param.json','compile.sh'):
        export.copy(R/'build/eager_kernel_a4'/n,Path('build/eager_kernel_a4')/n)
    for n in ('ascendc_ops_config.py','const_var.py','generate.sh','completion.json'):
        export.copy(R/'build/eager_index_a5'/n,Path('build/eager_index_a5')/n)
    for path in vendor.glob('op_impl/ai_core/tbe/kernel/**/*.json'):
        export.copy(path,Path('build/private_kernel_metadata')/path.relative_to(vendor/'op_impl/ai_core/tbe/kernel'))
    shared=Path('/home/fault28-fia-fullmodel-20261109')
    for n in ('fia_abi_schema.json','fia_abi_selftest.json','source_freeze.json','policy_source_manifest.json'):
        export.copy(shared/'build/evidence_a4'/n,Path('build/public_host_abi')/n)
    frozen=json.loads((shared/'build/evidence_a4/source_freeze.json').read_text())['files']
    original=Path('/home/fault28-fia-graph-20261106')
    for relative,target in [('source_policy_a4/fault28_fia_policy.h','source/host/fault28_fia_policy.h'),
        ('source_policy_a4/apply_policy.py','source/host/apply_policy.py'),
        ('source_a4/ops-transformer-v9.1.0/attention/common/op_host/arch22/fia_tiling_nonquant.cpp','source/host/fia_tiling_nonquant.cpp')]:
        assert sha(original/relative)==frozen[relative]
        export.copy(original/relative,target)
    implementation=vendor/'op_impl/ai_core/tbe/fault28_fia_graph_transformer_impl'
    for relative in ('fused_infer_attention_score/op_kernel/fused_infer_attention_score_v3.cpp',
        'fused_infer_attention_score/op_kernel/fused_infer_attention_score.cpp',
        'common/op_kernel/arch22/fault28_causal_tile.h',
        'common/op_kernel/arch22/fia_block_cube_nonquant_gqa.h',
        'common/op_kernel/arch22/fia_block_vec_nonquant.h'):
        # .cpp is source code, not an executable or a tensor. Exact source bytes.
        source=implementation/relative
        if source.suffix=='.cpp':
            target=out/'source/kernel'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
            export.mapping.append({'source':str(source),'exported':target.relative_to(out).as_posix(),'bytes':target.stat().st_size,'sha256':sha(target),'byte_preserved':True})
        else:export.copy(source,Path('source/kernel')/relative)
    collector=shared/'collector_fp64_a1'
    export.copy(collector/'stage_manifest.json','build/collector_manifest.json')
    processors=list(collector.rglob('pytorch_processor.py'));assert len(processors)==1
    export.copy(processors[0],'source/collector/pytorch_processor.py')
    # Explicit source mapping, plus every exported byte, are independently
    # verifiable without reconstructing unavailable private complete tensors.
    save(out/'source_mapping.json',{'schema':'fault28.eager.export_mapping.v1','files':export.mapping,
        'main_groups':['baseline','fault'],'private_full_tensors_or_weights_exported':False,
        'scope':'Whitelist of original statistics/metadata/source bytes and clearly generated review summaries.'})
    files=sorted(x for x in out.rglob('*') if x.is_file())
    (out/'SHA256SUMS').write_text(''.join(sha(x)+'  '+x.relative_to(out).as_posix()+'\n' for x in files))
    # Ensure no raw lease credential appears anywhere in the whitelisted output.
    assert not any(x.suffix in ('.pt','.bin','.o','.so','.safetensors') for x in files)
    print(json.dumps({'status':'EXPORTED_REVIEWED_TWO_GROUP_NATIVE_EAGER_STATISTICS','files':len(files)+1,
        'bytes':sum(x.stat().st_size for x in files),'destination':str(out)}))

if __name__=='__main__':main()
