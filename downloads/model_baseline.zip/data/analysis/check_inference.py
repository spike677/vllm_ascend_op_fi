"""Re-read original NPU B/F logits and decode their greedy next-token results on CPU."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--captures', type=Path, required=True)
    parser.add_argument('--expected', type=Path, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    import numpy as np
    from transformers import AutoTokenizer
    expected = json.loads(args.expected.read_bytes())
    assert expected['source_commit'] == 'c1dcb0f22438362bfdd7100f834b0be62cd425c9'
    arms = {}
    for name, item in expected['cases'].items():
        folder = args.captures / item['capture_path']
        for file, digest in item['published_files'].items():
            assert sha(folder / file) == digest, (name, file)
        result = json.loads((folder / 'result.json').read_bytes())
        assert result['status'] == 'CAPTURE_COMPLETED' and result['original_api_calls'] == 28
        assert result['request_count'] == 8 and result['all_layers'] == list(range(28))
        assert result['host']['applied'] == (0 if name == 'model_baseline' else 28)
        meta = result['decode_logits']
        assert meta['shape'] == [8, 1, 151936] and meta['dtype'] == 'torch.float16'
        assert meta['byteorder'] == 'little'
        file = folder / result['private_logits_file']
        raw = file.read_bytes()
        assert len(raw) == meta['bytes'] == 2430976
        assert hashlib.sha256(raw).hexdigest() == meta['sha256']
        logits = np.frombuffer(raw, dtype='<f2').reshape(8, 151936)
        assert np.isfinite(logits).all()
        for row in range(8):
            assert hashlib.sha256(logits[row].tobytes()).hexdigest() == meta['request_sha256'][row]
        arms[name] = {'folder': folder, 'meta': meta, 'logits': logits,
                      'result_sha256': sha(folder / 'result.json')}
    b, f = (arms[n] for n in ('model_baseline', 'model_fault_r0'))
    for file in ('release.json', 'request_mapping.json', 'prefill_cache.json', 'block_table.json'):
        assert (b['folder'] / file).read_bytes() == (f['folder'] / file).read_bytes()
    release = json.loads((b['folder'] / 'release.json').read_bytes())
    tokenizer_files = {}
    for file in ('tokenizer.json', 'tokenizer_config.json', 'vocab.json'):
        digest = sha(args.model / file)
        assert digest == release['files'][file]['sha256']
        tokenizer_files[file] = digest
    tokenizer = AutoTokenizer.from_pretrained(str(args.model), local_files_only=True, trust_remote_code=False)
    mapping = json.loads((b['folder'] / 'request_mapping.json').read_bytes())['rows']
    rows = []
    for index in range(8):
        left, right = b['logits'][index], f['logits'][index]
        changed = np.not_equal(left, right)
        difference = np.abs(left.astype(np.float64) - right.astype(np.float64))
        ids = [int(np.argmax(v)) for v in (left, right)]
        assert all(np.count_nonzero(v == v.max()) == 1 for v in (left, right))
        text = [tokenizer.decode([token], skip_special_tokens=False,
                                 clean_up_tokenization_spaces=False) for token in ids]
        top5 = []
        for values in (left, right):
            positions = np.argsort(-values.astype(np.float64), kind='stable')[:5]
            top5.append([{'id': int(token), 'logit': float(values[token]),
                          'text': tokenizer.decode([int(token)], skip_special_tokens=False,
                                                   clean_up_tokenization_spaces=False)} for token in positions])
        rows.append({'request_id': mapping[index]['request_id'], 'request_slot': index,
                     'known_prefix_sha256': mapping[index]['known_prefix_sha256'],
                     'teacher_token_id': mapping[index]['teacher_token_id'],
                     'changed_logits': int(changed.sum()), 'logit_elements': int(left.size),
                     'max_abs_logit_difference': float(difference.max()),
                     'B_next_token_id': ids[0], 'F_next_token_id': ids[1],
                     'B_next_token_text': text[0], 'F_next_token_text': text[1],
                     'next_token_changed': ids[0] != ids[1], 'decoded_fragment_changed': text[0] != text[1],
                     'B_top5': top5[0], 'F_top5': top5[1]})
    report = {'schema': 'fault33.published_BF.inference_output_recheck.v1',
              'status': 'PASS_COMPLETE_LOGITS_AND_TOKENIZER_RECHECK',
              'test_kind': 'CPU reread of the original completed NPU inference outputs, not a fresh NPU run',
              'source_commit': expected['source_commit'], 'review_date': '2026-11-10',
              'model': 'Qwen3-0.6B FP16 TP1, original SDPA prefill plus explicit paged IFA decode',
              'request_count': 8, 'known_prefix_decode_steps': 1, 'kv_length': 16384,
              'physical_block_size': 128, 'B_sinner': 8192, 'F_sinner': 1024,
              'changed_logits': sum(r['changed_logits'] for r in rows), 'logit_elements': 8 * 151936,
              'max_abs_logit_difference': max(r['max_abs_logit_difference'] for r in rows),
              'requests_with_changed_logits': sum(r['changed_logits'] > 0 for r in rows),
              'changed_greedy_next_tokens': sum(r['next_token_changed'] for r in rows),
              'changed_decoded_fragments': sum(r['decoded_fragment_changed'] for r in rows),
              'rows': rows, 'sources': {n: {'result_sha256': v['result_sha256'], 'logits_sha256': v['meta']['sha256']}
                                       for n, v in arms.items()},
              'tokenizer_files_sha256': tokenizer_files,
              'new_npu_calls': 0, 'cpu_only': True, 'continuous_generation_tested': False,
              'private_tensor_payload_exported': False,
              'limits': ['Only one greedy next-token prediction at the fixed known prefixes is compared.',
                         'Equal next-token results do not imply equal logits, equal later continuations or equal model quality.',
                         'The source prompts are the original long repeated-seed workloads; this is not a new short chat prompt.',
                         'Physical block size stays 128; the controlled intervention changes KV computation grouping.',
                         'The original complete logits remain private on 124; public output contains only scalar metrics and token IDs/text.']}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')
    print(json.dumps({k: report[k] for k in ('status', 'changed_logits', 'logit_elements',
                                           'max_abs_logit_difference', 'changed_greedy_next_tokens',
                                           'changed_decoded_fragments', 'new_npu_calls')}))


if __name__ == '__main__':
    main()
