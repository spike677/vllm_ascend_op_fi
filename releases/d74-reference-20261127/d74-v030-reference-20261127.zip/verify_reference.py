"""Reference-only byte verification and six original CPU contract tests."""
import argparse, hashlib, importlib.util, json, sys, types, unittest
from pathlib import Path
root = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--tests', action='store_true')
args = p.parse_args()
manifest = json.loads((root/'manifest.json').read_bytes())
for row in manifest['files']:
    f = (root/row['path']).resolve()
    if not f.is_relative_to(root) or not f.is_file():
        raise SystemExit('REFERENCE_PATH_INVALID:'+row['path'])
    raw = f.read_bytes()
    if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
        raise SystemExit('REFERENCE_SHA_MISMATCH:'+row['path'])
print(json.dumps({'verified':True,'files':len(manifest['files']), 'qualification_granted':False}))
if args.tests:
    # Isolated namespace loads ONLY the two archived stdlib modules. It does not
    # import or simulate the production fault_injection package initializer.
    folder=root/'reference/27cadf79'
    pkg=types.ModuleType('fault_injection')
    pkg.__path__=[str(folder/'fault_injection')]
    sys.modules['fault_injection']=pkg
    def load(name,path):
        spec=importlib.util.spec_from_file_location(name,path)
        mod=importlib.util.module_from_spec(spec)
        sys.modules[name]=mod
        spec.loader.exec_module(mod)
        return mod
    load('fault_injection.product_contract',folder/'fault_injection/product_contract.py')
    load('fault_injection.dsv4_product_v030',folder/'fault_injection/dsv4_product_v030.py')
    module=load('reference_contract_tests',folder/'tests/worker_extension/test_dsv4_product_v030.py')
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
    print(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),
        'errors':len(result.errors),'passed':result.wasSuccessful(),
        'real_v4_environment_validated':False}))
    raise SystemExit(not result.wasSuccessful())
