# D74 参考资料，不是安装包

**没有在真实 V4 0.30/0.32 环境验证过。** 本包不授予执行或验收资格。

D74 取代旧文档中的蓝区出包前置：0.30/0.32 的运行时、机制、工具、包与验收由黄区负责。
S0-UPGRADE-001 现在是咨询，不阻塞 S1/R0/R1/R2。蓝区不再等待源码来发布 D13/公共 8 包。

- reference/27cadf79：原提交 27cadf797014a6a34bbee23e5eaeae1977f5488f 的长请求关闭准入、依赖、六项 CPU 测试和设计说明。
  helper 只生成 executable=false；enable_prepared_route 始终拒绝。它硬编码 global ranks 0–7、TP8/EP/DP1、
  软件版本字符串、2500–4092 token/4 token 等，仅是参考假设，须以实际环境重审，不可直接接入产品。
  patch 仅该提交的三个文件差异；不要把其整个开发分支当成冻结 r8 安装。
- reference/r3：四份观测/审查门槛文档。历史蓝区责任与等待要求已由 D74 覆盖。
  r3 历史观测结果不等于 D13 或公共 8 注入资格。
- reference/743611c4：源码审查和未接线的 Python 观测核心；旧 CPU 18/18 是 stdlib 核心测试，
  不是 V4 tensor fixture、设备消费事件、Worker 接线或实机证明。此次不继续开发它。
- reference/r8：冻结 e38c4113b421ac979699071a60e80d3babd05e07 的选定源码原始字节，只供对照，不是完整运行时。
- docs/worker_core_v1/runtime_026_version_bound_checklist_20261127.md：位置、目的、迁移重审面。
  runtime-source-locations.json 给出冻结文件 SHA 与函数行号。

不把任何 reference/ 目录加到生产 PYTHONPATH；不覆盖现役 SITE；没有 wheel、Native 库、许可或登记。
所有源文件从指定 Git blob 读取，绕过 Windows 换行转换。manifest.json 记录逐文件来源、字节数、SHA。

取件后先按交付索引核对 ZIP SHA，解压独立目录，然后：

```sh
python -I verify_reference.py
python -I verify_reference.py --tests
```

Python >=3.10，只需标准库。测试器建立隔离 namespace，加载原始 helper 与 product_contract，
不执行生产包 initializer；只验证原有六项 CPU 契约，不声称整包安装检查或 NPU 验收。

黄区另开 0.30 分支，独立会话审运行时；R1 两 owner/负例通过后逐项迁移重验并重新登记。
LEDGER-FINAL 分列 0.26/0.30；0.26 资格不得复制为 0.30。蓝区以后只按请求做源码咨询。
