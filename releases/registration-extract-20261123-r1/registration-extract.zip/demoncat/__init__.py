"""Standalone read-only extraction support; no runtime bootstrap."""
