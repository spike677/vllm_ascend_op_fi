# Source integration handoff

This bundle preserves one canonical implementation under `sources/`. The eight
section directories contain entrypoint/source indexes, not replacement code.
Three original pyproject.toml files define demoncatpfi, demoncat-worker-extension
and demoncat-fault39-core. Build/install them independently from sources/,
sources/src/ and sources/fault39/ using your approved Python packaging tools.

The inner-framework Registry/Controller implementation is unavailable here:
INNER_FRAMEWORK_INTEGRATION_PENDING. RC1 starts at
sources/docs/worker_core_v1/yellow_rc1.md, including native dependencies and
openchamber's five actual wiring points. The single product surface is
FaultConfig + WorkerFaultClient(HostAdapter(existing_executor)); the older
HostContracts remain internal adapters, not alternative user interfaces.
Serving owns Worker creation,
startup and shutdown. Keep Worker RPC nonce/owner/generation, one-attempt rules,
scope checks and owner retention on uncertain/failed recovery unchanged.

The current Worker source may include additional discovery/census modules from
the explicitly reviewed source root. Inventory and C0 observations never grant
runtime or native qualification. Read sources/docs/worker_core_v1/host_contract.md.
When census is present, the package also includes the exact existing
engineering_closure observer modules, the serving-context CPU fixture, and
sources/docs/worker_core_v1/{README,census_contract}.md. Unrelated engineering
history, queues, execution receipts and reports are not included.

NativeBuildManager remains fault_injection.native_build.NativeBuildManager.
Pass --repository pointing to sources/ when installed outside this source tree.
Current recipe dependencies retain their original relative paths, including
explicitly selected legacy C++/header/build inputs. No CANN/vendor libraries,
prebuilt .so, tensors, statistics, experiment reports or historical certificates
are included. Obtain environment-specific dependencies through the host's
approved deployment and produce new build fingerprints. A successful build is
not runtime qualification. No native build runs during export or verification.

CANN 8.5.1/A2 has mechanism-specific prior evidence only; this artifact grants
no acceptance. CANN 9.x and A3 remain NOT_ACCEPTED_BY_THIS_BUNDLE. Compatibility
must be established for an exact build/environment/operator/Worker instance.
C1/C2/C3, resource recovery, healthy-output recovery and independent E5 each
require their own current evidence. This is not a 17/17 completion statement.

Native strategy certificate files and their historical evidence are excluded.
Provide independently reviewed certificates and bound evidence explicitly;
absence must continue to refuse arming rather than use historical acceptance.

Before extraction, verify against the separately retained source review file:
python tools/export_integration_bundle.py verify --archive bundle.tar.gz --review review.json
The archive SHA returned by export should also be retained independently.
The verifier does not extract or execute archive entries. Hash verification
establishes integrity against supplied review bytes, not authorship or approval.
