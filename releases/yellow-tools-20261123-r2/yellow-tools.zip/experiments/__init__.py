"""Independent tool namespace, not a product runtime replacement."""
