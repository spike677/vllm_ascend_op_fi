# r2 K3补充件（不覆盖原r2）
先读 docs/worker_core_v1/yellow_intake_20261124_fault33_window1.md，再按 fault33_n2_existing_capture_20261124.md 从旧文件补提。K3审查取代旧full intake和旧r2验证文档里的“统一重跑”建议；旧文档保留为历史来源。

采集器源码与原r2逐字节相同。新工具只读取既有文件，缺项保留null，不把函数名哈希当tiling key。SDK ABI/layout及两个只读窗口步骤在 docs/worker_core_v1/fault33_candidate_windows_20261124.md。原r2蓝区库只为构建参考，不自动获得A3资格。

产品包不变。完整Qwen测试范围见 releases/RC3-PREVIEW-R7.4.1-FORMAL-TEST-PLAN-V2-20261124.md；配方表是文档，不是黄区适配器实现。

Python>=3.10；提取只需标准库。先设置PYTHONPATH到解压根目录。控制重算测试另需匹配torch环境。校验外层SHA256SUMS后，按manifest.files逐文件核对字节数及SHA256。旧原件不要覆盖，解压到新目录。
