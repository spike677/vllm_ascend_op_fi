"""Bounded post-operator proxies with actual dispatch and storage observations.

This is a new public Tensor/operator boundary. It does not inherit the legacy
OpCache output-proxy certificate or claim a naturally occurring cache overwrite.
Only an independent normal model replay can discover a target. No layer name,
pointer, claimed writer receipt, or claimed consumer receipt is accepted.
"""
from __future__ import annotations

import ctypes
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import secrets
import threading

import torch
from torch.utils._python_dispatch import TorchDispatchMode
from torch.utils._pytree import tree_flatten, tree_map

from .postwrite_boundaries import (PROJECTION_OPERATORS, VALUE_CONSUMERS,
    projection_return, reads_selected_elements, tensor_geometry)


class PostwriteRefused(RuntimeError):
    pass


MAX_POSTWRITE_LEASES = 256
MAX_POSTWRITE_SPAN_BYTES = 160 * 1024 * 1024


def _storage(tensor):
    return (str(tensor.device), tensor.untyped_storage()._cdata,
            tensor.untyped_storage().data_ptr(), tensor.untyped_storage().nbytes())


def _tensors(value):
    return [item for item in tree_flatten(value)[0] if isinstance(item, torch.Tensor)]


def _cpu(value):
    return tree_map(lambda x: x.detach().cpu().clone() if isinstance(x, torch.Tensor) else x, value)


def _equal(left, right):
    a, sa = tree_flatten(left)
    b, sb = tree_flatten(right)
    return sa == sb and all(torch.equal(x, y) if isinstance(x, torch.Tensor)
                           and isinstance(y, torch.Tensor) else x == y for x, y in zip(a, b))


def _hash_inputs(args, kwargs):
    flattened, spec = tree_flatten((args, kwargs))
    digest = hashlib.sha256(str(spec).encode())
    for value in flattened:
        if isinstance(value, torch.Tensor):
            digest.update(str((tuple(value.shape), str(value.dtype), str(value.device))).encode())
            digest.update(value.detach().contiguous().view(torch.uint8).cpu().numpy().tobytes())
        elif isinstance(value, (str, int, float, bool, type(None))):
            digest.update(json.dumps(value, allow_nan=False).encode())
        else:
            raise PostwriteRefused('UNSUPPORTED_REPLAY_INPUT')
    return digest.hexdigest()


class NativePostwriteLibrary:
    """Deployment-owned public ACL ABI. Loading never confers model acceptance."""
    transport_kind = 'public_acl_native'

    def __init__(self, library, sha256):
        path = Path(library).resolve(strict=True)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != sha256 or len(sha256) != 64:
            raise PostwriteRefused('POSTWRITE_BUILD_HASH_MISMATCH')
        self.sha256 = actual
        self.path = str(path)
        self.lib = ctypes.CDLL(str(path))
        u64, u32, i32, ptr = ctypes.c_uint64, ctypes.c_uint32, ctypes.c_int32, ctypes.c_void_p
        signatures = {
            'dcat_pw_abi': ([], u32),
            'dcat_pw_open': ([ptr, u64, i32, u64, u64, ctypes.POINTER(u64)], ctypes.c_int),
            'dcat_pw_apply': ([u64, u64, u64, u32, ctypes.POINTER(u64), u64, ctypes.POINTER(u64)], ctypes.c_int),
            'dcat_pw_restore': ([u64, u64, u64], ctypes.c_int),
            'dcat_pw_release': ([u64, u64, u64], ctypes.c_int),
            'dcat_pw_live': ([u64, u64, u64], ctypes.c_int),
        }
        for name, (args, result) in signatures.items():
            function = getattr(self.lib, name)
            function.argtypes, function.restype = args, result
        self._snapshot = getattr(self.lib, 'dcat_pw_read_span', None)
        if self._snapshot is not None:
            self._snapshot.argtypes, self._snapshot.restype = [ptr, u64, i32, ptr], ctypes.c_int
        if self.lib.dcat_pw_abi() != 1:
            raise PostwriteRefused('POSTWRITE_ABI_MISMATCH')
        capacity = getattr(self.lib, 'dcat_pw_lease_capacity', None)
        byte_capacity = getattr(self.lib, 'dcat_pw_lease_byte_capacity', None)
        self.lease_capacity = 1
        self.lease_byte_capacity = 1024 * 1024
        if capacity is not None and byte_capacity is not None:
            capacity.argtypes, capacity.restype = [], u32
            byte_capacity.argtypes, byte_capacity.restype = [], u64
            self.lease_capacity = capacity()
            self.lease_byte_capacity = byte_capacity()
            if (not 1 <= self.lease_capacity <= MAX_POSTWRITE_LEASES
                    or not 1 <= self.lease_byte_capacity <= MAX_POSTWRITE_SPAN_BYTES):
                raise PostwriteRefused('POSTWRITE_LEASE_CAPACITY_UNADAPTED')
        self._verify_loaded_file(path)
        if hashlib.sha256(path.read_bytes()).hexdigest() != actual:
            raise PostwriteRefused('POSTWRITE_LOADED_BYTES_CHANGED')

    @staticmethod
    def _verify_loaded_file(path):
        # A successful CDLL lookup can reuse an older mapping with the same
        # filename. Bind this process's mapped inode as well as on-disk bytes.
        maps = Path('/proc/self/maps')
        if not maps.is_file():
            raise PostwriteRefused('POSTWRITE_LINUX_LOADED_IDENTITY_REQUIRED')
        stat = path.stat()
        expected_device = f'{os.major(stat.st_dev):02x}:{os.minor(stat.st_dev):02x}'
        matching = []
        for line in maps.read_text().splitlines():
            fields = line.split(None, 5)
            if len(fields) == 6 and fields[5] == str(path):
                matching.append(fields)
        if not matching or any(int(row[4]) != stat.st_ino or row[3] != expected_device for row in matching):
            raise PostwriteRefused('POSTWRITE_LOADED_INODE_MISMATCH')

    def validate(self, tensor):
        if tensor.device.type != 'npu' or tensor.dtype != torch.bfloat16:
            raise PostwriteRefused('POSTWRITE_REQUIRES_NPU_BF16')
        import torch_npu
        if int(torch_npu.get_npu_format(tensor)) not in (0, 2):
            raise PostwriteRefused('POSTWRITE_REQUIRES_BASE_FORMAT')
        _validate_tensor(tensor)

    def environment_bindings(self):
        from ..environment import NativeSymbolHolder
        name = 'dcat_pw_linked_address_v1'
        function = getattr(self.lib, name, None)
        if function is None:
            raise PostwriteRefused('FRESH_POSTWRITE_LINKED_ADDRESS_BUILD_REQUIRED')
        return (NativeSymbolHolder(self.lib, function, name, self.path, self.sha256,
            ((0, 'aclrtGetDevice'), (1, 'aclrtSynchronizeDevice'), (2, 'aclrtMemcpy')),
            kind='LINKED_FUNCTION_RELOCATION'),)

    def snapshot(self, tensor, element_offset=0, elements=None):
        """Read real bytes without adding diagnostic Tensor ops to msprobe."""
        if self._snapshot is None:
            raise PostwriteRefused('POSTWRITE_FRESH_READ_SPAN_BUILD_REQUIRED')
        if tensor.device.type != 'npu' or not tensor.is_contiguous():
            raise PostwriteRefused('POSTWRITE_CONTIGUOUS_NPU_SNAPSHOT_REQUIRED')
        import torch_npu
        if int(torch_npu.get_npu_format(tensor)) not in (0, 2):
            raise PostwriteRefused('POSTWRITE_BASE_FORMAT_SNAPSHOT_REQUIRED')
        elements = tensor.numel() if elements is None else elements
        if (type(element_offset) is not int or type(elements) is not int or element_offset < 0
                or elements < 0 or element_offset + elements > tensor.numel()
                or elements * tensor.element_size() > 1024 * 1024
                or (tensor.storage_offset() + element_offset + elements) * tensor.element_size()
                    > tensor.untyped_storage().nbytes()):
            raise PostwriteRefused('POSTWRITE_SNAPSHOT_SPAN_OUT_OF_BOUNDS')
        if elements == 0:return b''
        geometry = tensor_geometry(tensor)
        size = elements * tensor.element_size()
        copied = (ctypes.c_ubyte * size)()
        code = self._snapshot(tensor.data_ptr() + element_offset * tensor.element_size(), size,
                              tensor.device.index, copied)
        if code or tensor_geometry(tensor) != geometry:
            raise PostwriteRefused('POSTWRITE_SNAPSHOT_FAILED:' + str(code))
        return bytes(copied)

    def open(self, tensor, owner, generation):
        self.validate(tensor)
        return _NativeLease(self, tensor, owner, generation)

    def open_span(self, tensor, element_offset, elements, owner, generation):
        # The span is part of the *actual* live cache tensor. No repack or clone
        # is writable. Its allocation may include disjoint K/V views.
        if tensor.device.type != 'npu' or tensor.dtype != torch.bfloat16:
            raise PostwriteRefused('POSTWRITE_REQUIRES_NPU_BF16')
        import torch_npu
        if int(torch_npu.get_npu_format(tensor)) not in (0, 2):
            raise PostwriteRefused('POSTWRITE_REQUIRES_BASE_FORMAT')
        _validate_span(tensor, element_offset, elements)
        return _NativeLease(self, tensor, owner, generation,
                            element_offset=element_offset, elements=elements)


def _validate_tensor(tensor):
    if (tensor.requires_grad or not tensor.is_contiguous() or tensor.storage_offset() != 0
            or tensor.numel() <= 0 or tensor.numel() * tensor.element_size() > 1024 * 1024
            or tensor.untyped_storage().nbytes() != tensor.numel() * tensor.element_size()):
        raise PostwriteRefused('POSTWRITE_REQUIRES_EXCLUSIVE_CONTIGUOUS_BOUNDED_STORAGE')


def _validate_span(tensor, element_offset, elements):
    if (type(element_offset) is not int or type(elements) is not int
            or element_offset < 0 or elements <= 0 or tensor.requires_grad
            or not tensor.is_contiguous() or tensor.element_size() != 2
            or element_offset + elements > tensor.numel()
            or elements * tensor.element_size() > 1024 * 1024
            or (tensor.storage_offset() + element_offset + elements) * tensor.element_size()
                > tensor.untyped_storage().nbytes()):
        raise PostwriteRefused('POSTWRITE_LIVE_CONTIGUOUS_BOUNDED_SPAN_REQUIRED')


class _NativeLease:
    def __init__(self, library, tensor, owner, generation, *, element_offset=0, elements=None):
        self.library, self.tensor = library, tensor  # Strong reference until exact restoration.
        self.owner, self.generation = owner, generation
        self.thread = threading.get_ident()
        self.storage = _storage(tensor)
        self.geometry = tensor_geometry(tensor)
        self.element_offset = element_offset
        self.elements = tensor.numel() if elements is None else elements
        self.handle = ctypes.c_uint64()
        self._receipt_events = []
        self._receipt_failure = None
        address = tensor.data_ptr() + element_offset * tensor.element_size()
        size = self.elements * tensor.element_size()
        self.closed = False
        try:
            code = self._native_call('open', library.lib.dcat_pw_open,
                (address, size, tensor.device.index, owner, generation, ctypes.byref(self.handle)),
                fields=dict(data_ptr=address, bytes=size, device=tensor.device.index))
            if code:
                raise PostwriteRefused(f'POSTWRITE_OPEN_{code}')
        except BaseException as error:
            error.postwrite_lease_receipt = self.receipt()
            raise

    def _native_call(self, operation, function, args, *, fields=None, capture=None, valid=(0,)):
        """Keep actual existing call results; this performs no additional ABI call."""
        event = dict(sequence=len(self._receipt_events) + 1, operation=operation,
            handle=self.handle.value, owner=self.owner, generation=self.generation,
            returned=False, return_code=None, error=None, **(fields or {}))
        try:
            code = function(*args)
        except BaseException as error:
            event.update(handle=self.handle.value, error=repr(error))
            self._receipt_events.append(event)
            if self._receipt_failure is None:
                self._receipt_failure = deepcopy(event)
            raise
        event.update(handle=self.handle.value, returned=True, return_code=code)
        if capture is not None:
            event.update(capture())
        if operation == 'live':
            event['native_live'] = bool(code) if code in (0, 1) else None
        self._receipt_events.append(event)
        if code not in valid and self._receipt_failure is None:
            self._receipt_failure = deepcopy(event)
        return code

    def receipt(self):
        """Detached metadata only; never query, restore, or retain extra Tensors."""
        events = self._receipt_events
        def last(name):
            return next((row for row in reversed(events) if row['operation'] == name), None)
        return deepcopy(dict(schema='demoncat.postwrite.lease_receipt.v1',
            owner=self.owner, generation=self.generation, handle=self.handle.value, thread=self.thread,
            geometry=self.geometry, element_offset=self.element_offset, elements=self.elements,
            open=last('open'), applications=[row for row in events if row['operation'] == 'apply'],
            restore=last('restore'), release=last('release'),
            live_readbacks=[row for row in events if row['operation'] == 'live'],
            events=events, first_failure=self._receipt_failure, closed=self.closed))

    def _check(self):
        if threading.get_ident() != self.thread:
            raise PostwriteRefused('POSTWRITE_SYNCHRONOUS_OWNER_REQUIRED')
        if (self.closed or _storage(self.tensor) != self.storage
                or tensor_geometry(self.tensor) != self.geometry):
            raise PostwriteRefused('POSTWRITE_LIVE_STORAGE_CHANGED')

    def apply(self, mode, indices):
        self._check()
        selected = (ctypes.c_uint64 * len(indices))(*indices)
        changed = ctypes.c_uint64()
        code = self._native_call('apply', self.library.lib.dcat_pw_apply,
            (self.handle, self.owner, self.generation, mode, selected, len(indices), ctypes.byref(changed)),
            fields=dict(mode=mode, indices=list(indices)), capture=lambda: dict(changed_elements=changed.value))
        if code:
            raise PostwriteRefused(f'POSTWRITE_APPLY_{code}')
        return changed.value

    def recover(self):
        if self.closed:
            return
        self._check()
        if getattr(self, 'release_uncertain', False) and self._release_readback():
            return
        code = self._native_call('restore', self.library.lib.dcat_pw_restore,
                                 (self.handle, self.owner, self.generation))
        if code:
            raise PostwriteRefused(f'POSTWRITE_RESTORE_{code}')
        try:
            code = self._native_call('release', self.library.lib.dcat_pw_release,
                                     (self.handle, self.owner, self.generation))
            if code:
                raise PostwriteRefused(f'POSTWRITE_RELEASE_{code}')
        except BaseException:
            # The release may have completed before its response was lost.
            # Read this exact handle/owner/generation, never another lease or a
            # process-wide zero. Preserve the original error and caller owner;
            # a later explicit retry must not restore an already released span.
            self.release_uncertain = True
            self.release_ticket = (self.handle.value, self.owner, self.generation)
            try:
                self._release_readback()
            except BaseException as read_error:
                self.release_readback_error = repr(read_error)
            raise
        self.closed = True

    def _release_readback(self):
        if (self.handle.value, self.owner, self.generation) != self.release_ticket:
            raise PostwriteRefused('POSTWRITE_RELEASE_SCOPE_CHANGED')
        absent = not self.live(record=True)
        self.release_uncertain = False
        if absent:
            self.closed = True
        return absent

    def live(self, *, record=False):
        args = (self.handle, self.owner, self.generation)
        state = (self._native_call('live', self.library.lib.dcat_pw_live, args, valid=(0, 1)) if record
                 else self.library.lib.dcat_pw_live(*args))
        if state not in (0, 1):
            raise PostwriteRefused('POSTWRITE_NATIVE_LEASE_OWNER_MISMATCH')
        return state == 1


@dataclass
class _Candidate:
    key: tuple
    tensor: torch.Tensor
    indices: tuple[int, ...]
    operator: str
    module_path: str
    storage: tuple
    consumers: list
    producer_proof: dict
    consumer_observations: list


class _ObserveDispatch(TorchDispatchMode):
    # Views and alias-only dispatches do not prove a value was consumed.
    VALUE_CONSUMERS = VALUE_CONSUMERS
    def __init__(self, provider, phase):
        super().__init__()
        self.provider, self.phase = provider, phase
        self.candidates = []
        self.counts = {}
        self.original_calls = 0
        self.operator_counts = {}
        self.projection_observations = []
        self.rejections = []
        self.gemm_binding = None
        from .postwrite_inventory import ProjectionWorkloadInventory
        self.inventory = ProjectionWorkloadInventory()
        self.parameter_owners = ()
        self.parameter_consumption = []

    def _coverage_projection(self, record, candidate=None, rejection=None):
        if record is not None:
            record.candidate, record.rejection = candidate, rejection
            if self.provider._coverage is not None:
                self.provider._coverage.projection(self, record)

    def _current_reviewed_consumers(self, candidate):
        # A known schema/source change must refuse before opening a Native
        # writer lease, not merely after the later consumer returns. This is a
        # metadata check only; current value-read geometry is still observed
        # at the actual consumer, and no future call is manufactured.
        from .postwrite_npu_consumers import npu_consumer_registration
        for observed in self.provider._observations[:1]:
            for original in observed.candidates:
                if original.key != candidate.key:
                    continue
                for row in original.consumer_observations:
                    prior = row.get('reviewed_consumer')
                    if prior is None:
                        continue
                    function = getattr(torch.ops.npu, prior['operator'].split('.')[1]).default
                    current, reason = npu_consumer_registration(function)
                    if reason or any(prior.get(name) != value for name, value in (current or {}).items()):
                        raise PostwriteRefused('POSTWRITE_REVIEWED_CONSUMER_CHANGED_BEFORE_ADMISSION:'
                                              + (reason or 'REGISTRATION_IDENTITY'))

    @staticmethod
    def _writes(func, args, kwargs, storage):
        for i, parameter in enumerate(func._schema.arguments):
            value = args[i] if i < len(args) else kwargs.get(parameter.name)
            if (parameter.alias_info and parameter.alias_info.is_write and
                    any(_storage(t) == storage for t in _tensors(value))):
                return True
        return False

    def __torch_dispatch__(self, func, types, args=(), kwargs=None):
        kwargs = kwargs or {}
        p = self.provider
        if not p._stack:
            return func(*args, **kwargs)
        operation = str(func)
        operands = _tensors((args, kwargs))
        read_storages = {_storage(t) for t in operands}
        previous = [c for c in self.candidates if c.storage in read_storages]
        if any(self._writes(func, args, kwargs, lease.storage) for lease in p._live_leases()):
            raise PostwriteRefused('WRITE_AFTER_SELECTED_WRITER_REFUSED')
        result = func(*args, **kwargs)  # Exactly one real original operation.
        for module in self.parameter_owners:
            for name, parameter in module.named_parameters(recurse=False):
                if any(tensor is parameter for tensor in operands):
                    self.parameter_consumption.append(dict(module_object_identity=id(module), parameter_name=name,
                        parameter_object_identity=id(parameter), parameter_geometry=tensor_geometry(parameter),
                        actual_operator=operation, schema=str(func._schema), original_returned=True,
                        calling_module_identity=id(p._stack[-1][1]), module_forward_observed=False))
        record = self.inventory.original_returned(func, p._stack[-1][0], p._stack[-1][1], result)
        self.original_calls += 1
        self.operator_counts[operation] = self.operator_counts.get(operation, 0) + 1
        if operation in ('aten.mm.default', 'aten.addmm.default', 'aten.linear.default',
                         'aten.matmul.default', 'npu.npu_linear.default',
                         'vllm.unquantized_gemm.default') and len(self.projection_observations) < 32:
            outputs = _tensors(result)
            self.projection_observations.append(dict(operator=operation, module_path=p._stack[-1][0],
                admitted_producer_operator=operation in PROJECTION_OPERATORS,
                inputs=[dict(shape=list(t.shape), dtype=str(t.dtype)) for t in operands],
                outputs=[dict(shape=list(t.shape), dtype=str(t.dtype), contiguous=t.is_contiguous(),
                    offset=t.storage_offset(), storage_bytes=t.untyped_storage().nbytes(),
                    logical_bytes=t.numel() * t.element_size(), requires_grad=t.requires_grad,
                    aliases_input=_storage(t) in read_storages) for t in outputs]))
        from .postwrite_npu_consumers import NPU_VALUE_CONSUMERS, npu_value_consumer
        consumer_proof, consumer_inputs = None, operands
        if previous and operation in NPU_VALUE_CONSUMERS:
            consumer_proof, consumer_inputs, reason = npu_value_consumer(func, args, kwargs, result)
            if reason:
                self.rejections.append(dict(reason=reason, operator=operation, module_path=p._stack[-1][0]))
        for candidate in previous:
            if (operation in self.VALUE_CONSUMERS
                    or consumer_proof is not None) and (
                    not self._writes(func, args, kwargs, candidate.storage)):
                reads = [t for t in consumer_inputs if reads_selected_elements(t, candidate.indices, candidate.tensor)]
                if reads:
                    candidate.consumers.append(operation)
                    candidate.consumer_observations.append(dict(operator=operation,
                        module_path=p._stack[-1][0], original_returned=True,
                        selected_elements_read=list(candidate.indices),
                        operand_views=[tensor_geometry(t) for t in reads],
                        reviewed_consumer=consumer_proof))
        tensor, indices, producer_proof, rejection = None, (), {}, 'NO_ADAPTED_RETURN_GEOMETRY'
        if p.mechanism == '39.output_proxy' and operation in PROJECTION_OPERATORS:
            if operation == 'vllm.unquantized_gemm.default' and self.gemm_binding is None:
                from demoncat.runtime.vllm_ascend.worker_extension.gemm_lineage import ReviewedGemmBinding
                self.gemm_binding = ReviewedGemmBinding()
            proof, reason = projection_return(func, args, kwargs, result,
                gemm_binding=self.gemm_binding, expected_weight=getattr(p._stack[-1][1], 'weight', None))
            if proof is not None and result.numel() >= p.prefix_elements:
                tensor, indices, producer_proof = result, tuple(range(p.prefix_elements)), proof
            elif reason is not None:
                rejection = reason
                self.rejections.append(dict(reason=reason, operator=operation, module_path=p._stack[-1][0]))
        elif p.mechanism == '41.tail_column' and operation == 'aten.index_copy_.default':
            if len(args) >= 4:
                cache, dim, rows, source = args[:4]
                if (isinstance(cache, torch.Tensor) and id(cache) in p._buffers
                        and p._buffers[id(cache)] is cache and cache.ndim == 2 and dim == 0
                        and cache.dtype == torch.bfloat16 and cache.shape[1] >= p.tail_elements
                        and isinstance(rows, torch.Tensor) and rows.dtype == torch.int64
                        and rows.numel() == 1 and source.shape == (1, cache.shape[1])):
                    slot = int(rows.cpu().item())
                    if 0 <= slot < cache.shape[0]:
                        tensor = cache
                        indices = tuple(slot * cache.shape[1] + col
                            for col in range(cache.shape[1] - p.tail_elements, cache.shape[1]))
        if tensor is None:
            self._coverage_projection(record, rejection=rejection)
            return result
        try:
            p.transport.validate(tensor)
        except PostwriteRefused as error:
            p._rejections.append(str(error))
            self.rejections.append(dict(reason=str(error), operator=operation, module_path=p._stack[-1][0],
                                        shape=list(tensor.shape), dtype=str(tensor.dtype)))
            self._coverage_projection(record, rejection=str(error))
            return result
        module_path, module = p._stack[-1]
        signature = (id(module), operation, tuple(tensor.shape), tuple(tensor.stride()),
                     str(tensor.dtype), indices)
        if operation == 'vllm.unquantized_gemm.default':
            # Bind the raw public-call ordinal, including refused calls. A
            # newly qualified earlier invocation must not relabel a later one.
            occurrence = record.key[-1]
        else:
            occurrence = self.counts.get(signature, 0)
            self.counts[signature] = occurrence + 1
        candidate = _Candidate(signature + (occurrence,), tensor, indices, operation,
                               module_path, _storage(tensor), [], producer_proof, [])
        self.candidates.append(candidate)
        if self.phase in ('baseline', 'fault') and (p._coverage is not None or candidate.key == p._target):
            self._current_reviewed_consumers(candidate)
        self._coverage_projection(record, candidate=candidate)
        if p._coverage is None and self.phase in ('baseline', 'fault') and candidate.key == p._target:
            mode = p.mutation_mode if self.phase == 'fault' else 0
            changed = p._apply_single_return(tensor, indices, mode)
            p._last_intervention = dict(operator=operation, original_executed=True,
                selected_elements=len(indices), changed_elements=changed, readback_exact=True,
                boundary='post_operator_tensor_output' if p.mechanism.startswith('39.')
                         else 'post_cache_writer_live_slot', transport=p.transport.transport_kind,
                new_fault_hits=int(self.phase == 'fault'), module_path=module_path)
        return result


class PostwriteProvider:
    """Single automatically discovered, lossless-qualified inference target.

    ``qualify`` runs two real unchanged forwards. ``run`` always drives the
    actual bound model. Runtime hooks cannot manufacture a writer/consumer
    receipt. Full Worker integration and all-eligible modes are not granted.
    """
    def __init__(self, model, transport, mechanism, *, prefix_elements=1,
                 tail_elements=1, proxy='pos_inf'):
        if mechanism not in ('39.output_proxy', '41.tail_column'):
            raise ValueError('Separate output_proxy or tail_column mechanism required')
        if not isinstance(transport, NativePostwriteLibrary) and getattr(transport, 'transport_kind', None) != 'cpu_test':
            raise TypeError('A verified native transport is required')
        if type(prefix_elements) is not int or prefix_elements not in (1, 5, 51, 512):
            raise ValueError('Reviewed prefix sizes are 1, 5, 51 or 512')
        if type(tail_elements) is not int or not 1 <= tail_elements <= 128:
            raise ValueError('Tail must contain 1 through 128 logical columns')
        if proxy not in ('pos_inf', 'neg_inf', 'qnan'):
            raise ValueError('Unknown output proxy')
        self.model, self.transport, self.mechanism = model, transport, mechanism
        self.prefix_elements, self.tail_elements = prefix_elements, tail_elements
        self.mutation_mode = {'pos_inf': 1, 'neg_inf': 2, 'qnan': 3}[proxy] if mechanism.startswith('39.') else 4
        self.owner, self.generation = secrets.randbits(63) + 1, 0
        self._thread = threading.get_ident()
        self._stack, self._rejections, self._history = [], [], []
        self._lease = self._target = self._input_hash = self._model_identity = None
        self._group_leases = {}
        self._last_intervention = None
        self._last_native_lease_receipt = None
        self._buffers = {id(t): t for t in model.buffers()}
        self._lock = threading.Lock()
        self._qualified = self._lossless = self._fault_attempted = False
        self._qualification_diagnostics = None
        self._coverage = None
        self._observations = []
        self._last_observer = None

    def _identity(self):
        return (id(self.model), tuple((id(m), type(m).__module__, type(m).__qualname__)
                                     for m in self.model.modules()),
                tuple((id(p), _storage(p), p._version) for p in self.model.parameters()),
                tuple((id(b), _storage(b)) for b in self.model.buffers()))

    def _replay(self, phase, args, kwargs, model_observation=None):
        if threading.get_ident() != self._thread or not self._lock.acquire(False):
            raise PostwriteRefused('POSTWRITE_SYNCHRONOUS_OWNER_REQUIRED')
        hooks = []
        observer = _ObserveDispatch(self, phase)
        self._last_observer = observer
        self._last_intervention = None
        self._last_native_lease_receipt = None
        try:
            if self.live_lease_count:
                raise PostwriteRefused('POSTWRITE_RECOVERY_REQUIRED')
            for name, module in self.model.named_modules():
                def pre(current, inputs, name=name):
                    self._stack.append((name, current))
                    observer.inventory.module_entered(name, current)
                def post(current, inputs, output):
                    if not self._stack or self._stack[-1][1] is not current:
                        raise PostwriteRefused('MODULE_CALL_STACK_MISMATCH')
                    self._stack.pop()
                hooks.append(module.register_forward_pre_hook(pre))
                hooks.append(module.register_forward_hook(post, always_call=True))
            # Start collection only after replay identity checks and hook
            # installation. Its context ends before CPU copies, comparisons
            # and native recovery, preserving the actual model call boundary.
            from contextlib import nullcontext
            window = nullcontext() if model_observation is None else model_observation(self.model)
            with window:
                with torch.inference_mode(), observer:
                    output = self.model(*args, **kwargs)
            return self._observed_result(observer, output, phase)
        finally:
            try:
                for hook in reversed(hooks):
                    hook.remove()
            finally:
                self._stack.clear()
                try:
                    self._recover_owned_entries()
                finally:
                    self._lock.release()

    def _observed_result(self, observer, output, phase):
        copied = _cpu(output)
        self._last_observer = observer
        candidates = [c for c in observer.candidates if c.consumers]
        selected = [c for c in candidates if c.key == self._target]
        if self._coverage is None and phase in ('baseline', 'fault') and (len(selected) != 1 or self._lease is None):
            raise PostwriteRefused('QUALIFIED_WRITER_OR_CONSUMER_NOT_OBSERVED')
        if self._coverage is None and phase == 'off' and (len(selected) != 1 or self._lease is not None):
            raise PostwriteRefused('OFF_TARGET_OR_DRAIN_NOT_OBSERVED')
        report = dict(phase=phase, mechanism=self.mechanism,
            transport=self.transport.transport_kind, original_operator_calls=observer.original_calls,
            observed_candidates=len(observer.candidates), eligible_with_consumers=len(candidates),
            intervention=self._last_intervention,
            consumers=selected[0].consumers if selected else [],
            rejections=list(self._rejections), scope='controlled single-target inference replay',
            native_acceptance_inherited=False, public_worker_qualified=False,
            all_eligible_qualified=False, every_match_qualified=False)
        report['discovery_diagnostics'] = dict(operator_counts=dict(sorted(observer.operator_counts.items())),
            projection_observations=observer.projection_observations, projection_observation_limit=32,
            transport_rejections=observer.rejections,
            candidates=[dict(module_path=c.module_path, operator=c.operator,
                shape=list(c.tensor.shape), dtype=str(c.tensor.dtype), consumers=list(c.consumers))
                for c in observer.candidates[:64]], candidate_observation_limit=64)
        if selected:
            chosen = selected[0]
            report['actual_target'] = dict(pid=os.getpid(), model_instance=id(self.model),
                owner=self.owner, generation=self.generation, operator=chosen.operator,
                module_path=chosen.module_path, storage_identity=chosen.storage,
                shape=list(chosen.tensor.shape), stride=list(chosen.tensor.stride()),
                storage_offset=chosen.tensor.storage_offset(), dtype=str(chosen.tensor.dtype),
                logical_indices=list(chosen.indices), consumer_calls=list(chosen.consumers),
                producer_proof=chosen.producer_proof, consumer_observations=chosen.consumer_observations)
        if self._coverage is not None:
            self._coverage.forward_returned(observer, copied)
        return copied, candidates, report

    def qualify(self, *args, **kwargs):
        if threading.get_ident() != self._thread or self._lock.locked():
            raise PostwriteRefused('POSTWRITE_SYNCHRONOUS_OWNER_REQUIRED')
        if self._qualified or self._fault_attempted:
            raise PostwriteRefused('NEW_PROVIDER_REQUIRED_FOR_NEW_QUALIFICATION')
        identity, input_hash = self._identity(), _hash_inputs(args, kwargs)
        self._qualification_diagnostics = dict(status='IN_PROGRESS', observations=[], guards_relaxed=False)
        left, first, first_report = self._replay('observe', args, kwargs)
        self._observations.append(self._last_observer)
        self._qualification_diagnostics['observations'].append(first_report)
        right, second, second_report = self._replay('observe', args, kwargs)
        self._observations.append(self._last_observer)
        self._qualification_diagnostics['observations'].append(second_report)
        return self._qualify_observed_pair(identity, input_hash, left, first, right, second)

    def _qualify_observed_pair(self, identity, input_hash, left, first, right, second):
        keys_equal = [c.key for c in first] == [c.key for c in second]
        outputs_equal = _equal(left, right)
        identity_equal = self._identity() == identity
        failures = []
        if not first:failures.append('NO_ELIGIBLE_WRITER_WITH_OBSERVED_VALUE_CONSUMER')
        if not keys_equal:failures.append('ACTUAL_CANDIDATE_SEQUENCE_CHANGED')
        if not outputs_equal:failures.append('UNCHANGED_REPLAYS_OUTPUT_NOT_EXACT')
        if not identity_equal:failures.append('MODEL_BINDING_CHANGED_DURING_REPLAY')
        self._qualification_diagnostics.update(status='REFUSED' if failures else 'QUALIFIED',
            failure_reasons=failures, candidate_sequences_equal=keys_equal,
            complete_original_outputs_equal=outputs_equal, model_identity_equal=identity_equal)
        if failures:
            raise PostwriteRefused('NO_STABLE_ORIGINAL_WRITER_CONSUMER_REPLAY:' + ','.join(failures))
        self._target = first[0].key
        self._input_hash, self._model_identity = input_hash, identity
        self._qualified = True
        self._baseline_output = left
        return dict(status='ACTUAL_CALL_CANDIDATE_SELECTED', count=len(first),
                    selection='first eligible in stable actual execution order',
                    operator=first[0].operator, module_path=first[0].module_path,
                    consumers=list(first[0].consumers), producer_proof=deepcopy(first[0].producer_proof),
                    consumer_observations=deepcopy(first[0].consumer_observations), input_sha256=input_hash,
                    requires_lossless=True)

    def run(self, phase, *args, model_observation=None, **kwargs):
        self._begin_run(phase, args, kwargs)
        output, _, report = self._replay(phase, args, kwargs, model_observation=model_observation)
        return self._complete_run(phase, output, report)

    def _begin_run(self, phase, args, kwargs):
        if threading.get_ident() != self._thread or self._lock.locked():
            raise PostwriteRefused('POSTWRITE_SYNCHRONOUS_OWNER_REQUIRED')
        if phase not in ('baseline', 'fault', 'off'):
            raise ValueError('phase must be baseline, fault or off')
        if not self._qualified or self._identity() != self._model_identity:
            raise PostwriteRefused('POSTWRITE_MODEL_IDENTITY_NOT_QUALIFIED')
        if _hash_inputs(args, kwargs) != self._input_hash:
            raise PostwriteRefused('POSTWRITE_REPLAY_INPUT_CHANGED')
        if phase == 'fault' and (not self._lossless or self._fault_attempted):
            raise PostwriteRefused('POSTWRITE_LOSSLESS_OR_ONCE_GATE')
        if phase == 'fault':
            self._fault_attempted = True
        self.generation += 1

    def _complete_run(self, phase, output, report):
        if phase == 'baseline':
            if not _equal(output, self._baseline_output):
                raise PostwriteRefused('POSTWRITE_LOSSLESS_OUTPUT_MISMATCH')
            self._lossless = True
        if phase == 'off' and not _equal(output, self._baseline_output):
            raise PostwriteRefused('POSTWRITE_OFF_OUTPUT_MISMATCH')
        report['recovery_confirmed'] = self._lease is None
        report['exact_baseline_output'] = _equal(output, self._baseline_output)
        report['new_fault_hits'] = (report['intervention'] or {}).get('new_fault_hits', 0)
        if self.mechanism == '39.output_proxy':
            report['native_lease_receipt'] = deepcopy(self._last_native_lease_receipt)
        self._history.append(report)
        return output, report

    def recover(self):
        if threading.get_ident() != self._thread:
            raise PostwriteRefused('POSTWRITE_SYNCHRONOUS_OWNER_REQUIRED')
        if self._lock.locked():
            raise PostwriteRefused('POSTWRITE_CONSUMER_WINDOW_ACTIVE')
        self._recover_owned_entries()

    def _apply_single_return(self, tensor, indices, mode):
        """Shared execution only: exact original storage, unchanged Native guard.

        Admission belongs to the caller's live request. This routine neither
        qualifies a target nor runs a model/census. Failed leases stay owned.
        """
        if self._lease is not None:
            raise PostwriteRefused('ONLY_ONE_TARGET_CALL_PER_REPLAY')
        try:
            self._lease = self.transport.open(tensor, self.owner, self.generation)
        except BaseException as error:
            if self.mechanism == '39.output_proxy':
                self._last_native_lease_receipt = deepcopy(getattr(error, 'postwrite_lease_receipt', None))
            raise
        self._remember_native_receipt(self._lease)
        try:
            return self._lease.apply(mode, indices)
        finally:
            self._remember_native_receipt(self._lease)

    def _recover_owned_entries(self):
        entries = list(self._group_leases.items())
        if self._lease is not None:
            entries.append((None, self._lease))
        errors = []
        for key, lease in reversed(entries):
            try:
                lease.recover()
                live = (lease.live(record=True) if self.mechanism == '39.output_proxy'
                        and isinstance(lease, _NativeLease) else lease.live())
                if live:
                    raise PostwriteRefused('POSTWRITE_NATIVE_LEASE_REMAINS')
            except Exception as error:
                errors.append(error)
                continue
            finally:
                if key is None:
                    self._remember_native_receipt(lease)
            if key is None:
                self._lease = None
            else:
                del self._group_leases[key]
        if len(errors) == 1:
            raise errors[0]
        if errors:
            raise PostwriteRefused('POSTWRITE_MULTIPLE_RECOVERIES_PENDING:' + ', '.join(map(repr, errors))) from errors[0]

    def _remember_native_receipt(self, lease):
        if self.mechanism == '39.output_proxy' and isinstance(lease, _NativeLease):
            self._last_native_lease_receipt = lease.receipt()

    def _live_leases(self):
        group = tuple(self._group_leases.values())
        return group if self._lease is None else (self._lease, *group)

    @property
    def live_lease_count(self):
        return len(self._group_leases) + int(self._lease is not None)

    def _reserve_group_output(self, candidate):
        if (self._coverage is None or threading.get_ident() != self._thread
                or self._lease is not None or candidate.key in self._group_leases
                or self.live_lease_count >= getattr(self.transport, 'lease_capacity', 1)):
            raise PostwriteRefused('POSTWRITE_GROUP_LEASE_SCOPE_OR_CAPACITY')
        if any(candidate.storage == live.storage for live in self._group_leases.values()):
            raise PostwriteRefused('POSTWRITE_GROUP_STORAGE_ALREADY_RESERVED')
        lease = self.transport.open(candidate.tensor, self.owner, self.generation)
        self._group_leases[candidate.key] = lease
        return lease

    def query(self):
        return dict(mechanism=self.mechanism, owner=self.owner, generation=self.generation,
            execution_boundary='public_acl_postwrite', transport=self.transport.transport_kind,
            qualified=self._qualified, lossless=self._lossless, attempted=self._fault_attempted,
            leases=self.live_lease_count, recovery_pending=bool(self.live_lease_count),
            last_native_lease_receipt=deepcopy(self._last_native_lease_receipt),
            history=list(self._history), qualification_diagnostics=self._qualification_diagnostics,
            public_worker_qualified=False)


class Fault39OutputProxyProvider(PostwriteProvider):
    """Actual BF16 linear/matmul/MM return storage -> prefix -> real value consumer."""
    def __init__(self, model, transport, *, prefix_elements=1, proxy='pos_inf'):
        super().__init__(model, transport, '39.output_proxy',
                         prefix_elements=prefix_elements, proxy=proxy)


class Fault41TailColumnProvider(PostwriteProvider):
    """Actual model-owned cache IndexCopy writer -> finite logical slot tail sign flip."""
    def __init__(self, model, transport, *, tail_elements=1):
        super().__init__(model, transport, '41.tail_column', tail_elements=tail_elements)
