# 第12行 v2 持久权重行参考补充

仅列manifest的两个固定档，A2/0.26/CANN9.1/社区Qwen3.8 W8A8/TP2实机结果，不授予A3资格。
独立解压，需要Python3.12、torch/torch_npu2.10、冻结r7.4.1三个wheel及完整源码（含experiments）。
不覆盖冻结目录；将本目录、r7.4.1根目录、src、fault39/src和experiments/worker_core_v11_20261118加入PYTHONPATH。
实际lm_head布局、原权重读取和sampler路径须先审查；A2源码PIN不能盲目替换成A3新SHA。
静态复制/预打包/tied embedding/量化head未知时拒绝；只改拥有完整token10/11/12行组的分片，其余rank守卫。
开启期间全部真实请求读到改写权重；关闭时drain后同对象/分配代字节恢复，不覆盖后来合法更新。
写入计数每owner一次，读取计数为真实prefill/decode次数；非owner不制造写入。
两个owner、实际目标logits/概率和sampler消费、负例、逐位金丝雀见a2-review.json及原回执SHA。
可信PersistentSite注册采用LmHeadCollapseProvider/LmHeadSwapProvider、region_kind=persistent_weight，
必须保留部署鉴权、身份、许可、独占ingress和真实drain；本包验收RPC不能暴露公网。
完整命令与适用边界见docs中的交接单；CLI映射由黄区补入，资格以实际注册为准。

```bash
python -m unittest discover -s tests/worker_extension -p 'test_reference_lm_head*.py'
DCAT_REFERENCE_ROW12=row12_lm_head_collapse python -m reference_adapters.lm_head_product
python -m reference_adapters.review_lm_head /evidence/persistent_product.json --output /evidence/independent-review.json
```

交换档使用新的evidence目录和row12_lm_head_swap。原始张量留验收方，只交审查摘要和SHA。
