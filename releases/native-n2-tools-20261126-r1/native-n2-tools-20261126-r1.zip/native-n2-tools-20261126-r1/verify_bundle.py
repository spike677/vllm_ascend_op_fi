"""Offline verification; no runtime installation, no NPU, no real input mutation."""
import base64, hashlib, io, json, subprocess, sys, unittest
from pathlib import Path
if sys.version_info < (3,10): raise SystemExit('PYTHON_3_10_REQUIRED')
sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
sys.path[:0] = [str(root), str(root/'tests')]
manifest = json.loads((root/'manifest.json').read_bytes())
for entry in manifest['files']:
    p = (root/entry['path']).resolve()
    assert p.is_relative_to(root), 'PATH_OUTSIDE_BUNDLE'
    raw = p.read_bytes()
    assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'], entry['path']
metadata = json.loads((root/'dcat-native-build.json').read_bytes())
assert metadata['library_sha256']=='d9aa0d9488c5c1e8f7fca10c297e4968687ceb6a24866d8346bd33a58afce274'
assert metadata['cann']=='9.1.0'
suite = unittest.defaultTestLoader.loadTestsFromName('test_fault33_launch_host')
log = io.StringIO(); result = unittest.TextTestRunner(stream=log).run(suite)
if not result.wasSuccessful(): raise RuntimeError(log.getvalue())
from test_fault33_existing_extract import ExistingExtractTests
fixture = ExistingExtractTests(); fixture.setUp()
try:
    for call in fixture.plan['calls']: call.pop('tiling')
    plan = fixture.root/'plan.json'; plan.write_text(json.dumps(fixture.plan), encoding='utf-8')
    # -I ignores inherited PYTHONPATH and site user settings; inject this bundle only.
    code = "import runpy,sys; sys.path.insert(0,sys.argv.pop(1)); path=sys.argv.pop(1); runpy.run_path(path,run_name='__main__')"
    cmd = [sys.executable,'-I','-B','-S','-c',code,str(root),str(root/'tools/extract_fault33_launch_host.py'),
           '--capture-root',str(fixture.root),'--api',str(fixture.api),'--plan',str(plan)]
    first = subprocess.run(cmd,cwd=fixture.root,capture_output=True)
    second = subprocess.run(cmd,cwd=fixture.root,capture_output=True)
    assert first.returncode==second.returncode==0, first.stderr.decode(errors='replace')
    assert not first.stderr and not second.stderr and first.stdout==second.stdout
    rows = [json.loads(line) for line in first.stdout.splitlines()]
    assert rows[0]['n2_launch_complete'] is True and rows[0]['ready_for_control_recompute'] is False
    assert all(len(line)+1<=4096 for line in first.stdout.splitlines())
    cli = dict(runs=2,byte_equal=True,records=len(rows),max_line_bytes=max(len(x)+1 for x in first.stdout.splitlines()),
               stdout_sha256=hashlib.sha256(first.stdout).hexdigest())
finally: fixture.doCleanups()
print(json.dumps(dict(status='PASSED',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),
    skipped=len(result.skipped),files_verified=len(manifest['files']),cli=cli,python=sys.version.split()[0],
    manifest_sha256=hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest(),
    isolated_interpreter=True,third_party_dependencies=[],npu_used=False,qualification_granted=False),sort_keys=True))
