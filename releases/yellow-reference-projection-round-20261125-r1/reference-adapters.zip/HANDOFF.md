# 黄区参考适配器独立补充件

仅供黄区审查接入，现象复现，非原机理。A2/0.26/CANN9.1/社区Qwen3.8 W8A8/TP2结果不授予A3资格。本包不修改冻结r7.4.1、不新增公共编号、不自动登记。仅manifest列出的命名变体完成A2两owner复核。

在独立目录解压；需要r7.4.1的三个wheel及其完整源码目录（含experiments）。Python 3.12、torch2.10/torch_npu2.10，与目标部署身份匹配。把本包和r7.4.1源码同时加入PYTHONPATH，不覆盖发行目录。逐项检查manifest中文件及依赖SHA。

可信宿主对每个rank导入factory，以manifest中的工厂文件SHA构造ExternalSite，region_kind=transient，expected_deployment取该rank实际observe_deployment；通过register_external_site注册，再配置product profile和验收许可。只允许固定命名变体，不接受用户数值、层名或rank。CLI映射由黄区接入方补入，能力以ProductClient.capabilities为准。

依赖文件的冻结Git内容未改。Windows验收快照部分文件为CRLF，r7.4.1源码包为LF；dependency-byte-forms.json逐项列出两种SHA，不声称它们原始字节相等。工厂SHA按本包实际字节审核。

产品顺序为attach→enable→真实用户HTTP请求→status→disable（drain和金丝雀）→detach；每变体两个owner，缺许可/超范围/重复enable负例，逐rank八计数及changed_elements，真实消费者、区域字节恢复、资源清零、逐位金丝雀。changed小于applied不等于失败，但零变化不得宣称复现了数值现象。原始回执留在验收方，回传一页总结由负责人转交。

完整A2命令和语义边界见开发线reference_adapters/README.md；本包只含本批工厂和复核器。受审源提交、source_manifest SHA、原回执SHA及同组Worker/两个owner均在a2-review.json。
