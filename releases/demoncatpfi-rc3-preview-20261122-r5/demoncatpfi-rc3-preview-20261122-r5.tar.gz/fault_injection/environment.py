"""Read worker environment identity without importing device libraries."""
import hashlib
from dataclasses import dataclass
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import re
import stat
import struct
import sys


_ASCEND = Path('/usr/local/Ascend')
_LIBRARIES = re.compile(
    r'^lib(?:nnopbase|opapi\w*|ascendcl|acl_rt|ascend_hal|cust_opapi\w*|torch_npu|'
    r'fault\d+\w*|dcat\d+\w*)\.so(?:\.[\w.]+)?$'
)
_ABI_HEADERS = ('acl/acl.h', 'aclnn/acl_meta.h', 'aclnn/opdev/op_cache.h')
_SOC_REFERENCE = 'https://docs.vllm.ai/projects/ascend/en/v0.18.0/faqs.html'


def classify_soc(observed_name):
    """Classify an observed SoC family, never certify a provider or a product SKU."""
    normalized = re.sub(r'\s+', '', observed_name).lower() if isinstance(observed_name, str) else ''
    if re.fullmatch(r'(?:ascend)?910b\d*', normalized):
        family = 'A2'
    elif re.fullmatch(r'(?:ascend)?910_93\d{2}', normalized):
        family = 'A3'
    else:
        family = None
    return dict(observed_name=observed_name, family=family,
                status='SOC_FAMILY_CLASSIFIED' if family else 'UNCLASSIFIED',
                source=_SOC_REFERENCE if family else None,
                product_sku=None, provider_compatibility='UNVERIFIED')


def _live_soc():
    """Query only an already initialized backend; never import or initialize NPU."""
    backend = sys.modules.get('torch_npu')
    npu = getattr(backend, 'npu', None) if backend is not None else None
    ready = getattr(npu, 'is_initialized', None)
    if not callable(ready):
        return None, 'REQUIRES_LIVE_WORKER_OBSERVATION'
    try:
        if ready() is not True:
            return None, 'BACKEND_NOT_INITIALIZED_NO_QUERY'
        index = npu.current_device()
        name = npu.get_device_name(index)
        if type(index) is not int or not isinstance(name, str) or not name:
            return None, 'INVALID_LIVE_DEVICE_OBSERVATION'
        return dict(classify_soc(name), logical_device=index), 'INITIALIZED_TORCH_NPU_DEVICE_QUERY'
    except (RuntimeError, AttributeError, TypeError):
        return None, 'LIVE_DEVICE_QUERY_UNAVAILABLE'


def _digest(stream):
    digest = hashlib.sha256()
    stream.seek(0)
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        digest.update(block)
    return digest.hexdigest()


def _manifest(path):
    try:
        with path.open('rb') as stream:
            data = stream.read(64 * 1024 + 1)
    except OSError:
        return None
    if len(data) > 64 * 1024:
        return None
    entries = {}
    for line in data.decode(errors='replace').splitlines():
        key, separator, value = line.partition('=')
        if separator and key.strip():
            entries[key.strip().lower()] = value.strip().strip("'\"")
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(data).hexdigest(),
            'fields': {k: entries[k] for k in ('version', 'innerversion', 'arch', 'package_name')
                       if k in entries}}


def _toolkit():
    # The selected environment wins over a convenience latest symlink.
    configured = os.environ.get('ASCEND_HOME_PATH')
    roots = [Path(configured)] if configured else [
        _ASCEND / 'ascend-toolkit' / 'latest', _ASCEND / 'cann' / 'latest',
    ]
    installations = {}
    machine = platform.machine().lower()
    architecture = {'arm64': 'aarch64', 'amd64': 'x86_64'}.get(machine, machine)
    for root in roots:
        # Several releases expose both a toolkit root and an architecture
        # subdirectory. Select the directory used for headers on this machine.
        for directory in (root / (architecture + '-linux'), root):
            info = _manifest(directory / 'ascend_toolkit_install.info')
            if not info:
                continue
            resolved = directory.resolve()
            headers = {}
            for name in _ABI_HEADERS:
                path = resolved / 'include' / name
                try:
                    with path.open('rb') as stream:
                        headers[name] = _digest(stream)
                except OSError:
                    headers[name] = None
            installations[str(resolved)] = {**info, 'toolkit': str(resolved), 'abi_headers': headers}
            break
    status = 'AMBIGUOUS' if len(installations) > 1 else 'FOUND' if installations else 'UNAVAILABLE'
    return {'status': status, 'ascend_home_path': configured, 'installations': list(installations.values())}


def discover_installations(root=None, *, fingerprint_libraries=False):
    """Read installed toolkit metadata without loading a library or a device.

    This is an inventory, not an ABI compatibility decision. Full library hashes
    are opt-in for an offline inventory because a worker's status RPC should
    not reread gigabytes of unused installations on every call.
    """
    root = Path(root) if root is not None else _ASCEND
    machine = platform.machine().lower()
    arch = {'arm64': 'aarch64', 'amd64': 'x86_64'}.get(machine, machine)
    candidates = set()
    errors = []
    for base in (root, root / 'ascend-toolkit', root / 'cann'):
        try:
            if base.is_dir():
                candidates.add(base)
                candidates.update(p for p in base.iterdir() if p.is_dir())
        except OSError as error:
            errors.append(dict(path=str(base), error=type(error).__name__))
    if len(candidates) > 512:
        raise RuntimeError('Toolkit inventory exceeds bounded directory budget')
    records = {}
    for base in sorted(candidates):
        for directory in (base / (arch + '-linux'), base):
            info = _manifest(directory / 'ascend_toolkit_install.info')
            if info is None:
                continue
            directory = directory.resolve()
            if str(directory) in records:
                break
            row = dict(info, toolkit=str(directory), abi_headers={}, libraries={},
                       native_loaded=False, compatibility='UNVERIFIED')
            for name in _ABI_HEADERS:
                path = directory / 'include' / name
                try:
                    with path.open('rb') as stream:
                        row['abi_headers'][name] = _digest(stream)
                except OSError:
                    row['abi_headers'][name] = None
            if fingerprint_libraries:
                for name in ('libopapi.so', 'libopapi_nn.so', 'libnnopbase.so', 'libascendcl.so'):
                    path = directory / 'lib64' / name
                    try:
                        with path.open('rb') as stream:
                            length = os.fstat(stream.fileno()).st_size
                            row['libraries'][name] = dict(path=str(path.resolve()), bytes=length,
                                sha256=_digest(stream), elf_build_id=_elf_build_id(stream, length))
                    except OSError:
                        row['libraries'][name] = None
            records[str(directory)] = row
            break
    return dict(status='INSTALLED_METADATA_FOUND' if records else 'UNAVAILABLE',
                root=str(root), installations=list(records.values()),
                library_fingerprints_collected=fingerprint_libraries,
                loaded_library_identity_proven=False, scan_errors=errors)


def loaded_installation_links(libraries, installations):
    """Associate verified mapped file paths with installation metadata, not ABI.

    A proxy outside the toolkit stays unresolved. Multiple installations remain
    visible. No version is inferred from an arbitrary directory-name substring.
    """
    rows = []
    for library in libraries:
        path = Path(library['path'])
        matches = []
        if library.get('status') == 'MAPPED_FILE_VERIFIED':
            for installation in installations:
                root = Path(installation['toolkit'])
                try:
                    path.relative_to(root)
                except ValueError:
                    continue
                matches.append(dict(toolkit=str(root), version=installation['fields'].get('version'),
                                    metadata_sha256=installation['sha256']))
        rows.append(dict(name=library['name'], path=str(path), matches=matches,
                         status='PATH_LINKED_TO_INSTALLATION' if len(matches) == 1 else
                                'AMBIGUOUS_INSTALLATION' if matches else 'UNRESOLVED'))
    versions = {m['toolkit'] for row in rows for m in row['matches']}
    return dict(status='MULTIPLE_INSTALLATIONS_LOADED' if len(versions) > 1 else
                'PARTIALLY_LINKED' if versions else 'UNRESOLVED', libraries=rows,
                abi_compatibility_proven=False)


def _elf_build_id(stream, length):
    """Return a GNU build ID from ELF program notes. Malformed entries are ignored."""
    stream.seek(0)
    header = stream.read(64)
    if len(header) < 52 or header[:4] != b'\x7fELF' or header[4] not in (1, 2) or header[5] not in (1, 2):
        return None
    endian = '<' if header[5] == 1 else '>'
    if header[4] == 2:
        if len(header) < 64:
            return None
        table = struct.unpack_from(endian + 'Q', header, 32)[0]
        entry_size, count = struct.unpack_from(endian + 'HH', header, 54)
        fmt = endian + 'IIQQQQQQ'
        offset_index, size_index = 2, 5
    else:
        table = struct.unpack_from(endian + 'I', header, 28)[0]
        entry_size, count = struct.unpack_from(endian + 'HH', header, 42)
        fmt = endian + 'IIIIIIII'
        offset_index, size_index = 1, 4
    size = struct.calcsize(fmt)
    if entry_size < size or count > 1024 or table + entry_size * count > length:
        return None
    for index in range(count):
        stream.seek(table + index * entry_size)
        raw_entry = stream.read(size)
        if len(raw_entry) != size:
            return None
        entry = struct.unpack(fmt, raw_entry)
        offset, amount = entry[offset_index], entry[size_index]
        if entry[0] != 4 or amount > 1024 * 1024 or offset + amount > length:  # PT_NOTE
            continue
        stream.seek(offset)
        notes = stream.read(amount)
        cursor = 0
        while cursor + 12 <= len(notes):
            name_size, value_size, note_type = struct.unpack_from(endian + 'III', notes, cursor)
            name = cursor + 12
            value = name + ((name_size + 3) & ~3)
            cursor = value + ((value_size + 3) & ~3)
            if cursor > len(notes):
                break
            if note_type == 3 and notes[name:name + name_size] == b'GNU\0' and 0 < value_size <= 128:
                return notes[value:value + value_size].hex()
    return None


def _mapped_images(content, additional_names):
    images = {}
    for line in content.splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) != 6 or 'x' not in fields[1] or not fields[5].startswith('/'):
            continue
        address, _, offset, device, inode, mapped = fields
        deleted = mapped.endswith(' (deleted)')
        path = mapped.removesuffix(' (deleted)')
        name = Path(path).name
        if not _LIBRARIES.fullmatch(name) and name not in additional_names:
            continue
        key = (path, device, inode, deleted)
        offsets = images.setdefault(key, [])
        offsets.append((address, offset))
    return images


def _file_identity(info):
    return dict(device=info.st_dev, major=os.major(info.st_dev), minor=os.minor(info.st_dev),
                inode=info.st_ino, bytes=info.st_size, mode=info.st_mode,
                mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns)


def _mapping_backing_diagnostic(offsets):
    """Read kernel mapping metadata only; it never grants file/loaded-code identity.

    In particular, an overlay pathname hash cannot repair a map/stat mismatch.
    A map_files descriptor may be inaccessible without an extra capability; that
    refusal is retained rather than falling back to trusting the pathname.
    """
    rows = []
    for address, offset in offsets:
        path = Path('/proc/self/map_files') / address
        row = dict(address=address, file_offset=offset, map_file=str(path),
                   target=None, target_error=None, file_identity=None, open_error=None,
                   authority_granted=False)
        try:
            row['target'] = os.readlink(path)
        except OSError as error:
            row['target_error'] = dict(type=type(error).__name__, errno=error.errno)
        try:
            with path.open('rb') as stream:
                row['file_identity'] = _file_identity(os.fstat(stream.fileno()))
        except OSError as error:
            row['open_error'] = dict(type=type(error).__name__, errno=error.errno)
        rows.append(row)
    return rows


def _loaded_library(key, offsets):
    path, device, inode, deleted = key
    row = {'path': path, 'name': Path(path).name, 'status': 'UNAVAILABLE',
           'sha256': None, 'elf_build_id': None,
           'mapping': dict(device=device, inode=inode, deleted=deleted,
               executable_segments=[dict(address=address, file_offset=offset) for address, offset in offsets]),
           'path_identity_before': None, 'path_identity_after': None, 'path_identity_current': None,
           'identity_failure': None, 'mapping_backing': None}
    if deleted:
        return dict(row, status='MAPPING_DELETED')
    if len(offsets) != len({offset for _, offset in offsets}):
        return dict(row, status='DUPLICATE_EXECUTABLE_MAPPING')
    try:
        with open(path, 'rb') as stream:
            before = os.fstat(stream.fileno())
            row['path_identity_before'] = _file_identity(before)
            mapped_device = tuple(int(part, 16) for part in device.split(':'))
            if (not stat.S_ISREG(before.st_mode) or before.st_ino != int(inode)
                    or mapped_device != (os.major(before.st_dev), os.minor(before.st_dev))):
                row['identity_failure'] = 'EXECUTABLE_MAP_DOES_NOT_MATCH_OPEN_PATH'
                row['mapping_backing'] = _mapping_backing_diagnostic(offsets)
                return dict(row, status='MAPPED_FILE_IDENTITY_CHANGED')
            if stream.read(4) != b'\x7fELF':
                return dict(row, status='MAPPED_FILE_NOT_ELF')
            build_id = _elf_build_id(stream, before.st_size)
            digest = _digest(stream)
            after = os.fstat(stream.fileno())
            current = os.stat(path)
            row['path_identity_after'], row['path_identity_current'] = _file_identity(after), _file_identity(current)
            identity = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
            if identity(before) != identity(after) or identity(before) != identity(current):
                row['identity_failure'] = 'OPEN_OR_PATH_IDENTITY_CHANGED_DURING_HASH'
                row['mapping_backing'] = _mapping_backing_diagnostic(offsets)
                return dict(row, status='MAPPED_FILE_IDENTITY_CHANGED')
    except (OSError, ValueError, struct.error) as error:
        row['identity_failure'] = dict(type=type(error).__name__, errno=getattr(error, 'errno', None))
        return row
    return dict(row, status='MAPPED_FILE_VERIFIED', sha256=digest, elf_build_id=build_id)


def _loaded_libraries(additional_names):
    maps = Path('/proc/self/maps')
    try:
        inventory = _mapped_images(maps.read_text(errors='surrogateescape'), additional_names)
    except OSError:
        return [], 'UNAVAILABLE'
    rows = [_loaded_library(key, offsets) for key, offsets in sorted(inventory.items())]
    # A worker can load more than one implementation with the same filename.
    # Keep all records, so the resolver cannot silently pick the first one.
    counts = {}
    for row in rows:
        counts[row['name']] = counts.get(row['name'], 0) + 1
    for row in rows:
        if counts[row['name']] > 1:
            row['file_identity_status'] = row['status']
            row['status'] = 'AMBIGUOUS_MAPPING'
            row['same_basename_mappings'] = [dict(path=other['path'], mapping=other['mapping'])
                for other in rows if other['name'] == row['name']]
    try:
        final_inventory = _mapped_images(maps.read_text(errors='surrogateescape'), additional_names)
    except OSError:
        return rows, 'UNAVAILABLE'
    if final_inventory != inventory:
        return rows, 'MAPPING_CHANGED_DURING_INSPECTION'
    return rows, 'OBSERVED' if rows else 'NONE'


def _package(name, module):
    try:
        installed = metadata.version(name)
    except metadata.PackageNotFoundError:
        installed = None
    loaded = sys.modules.get(module)
    version = vars(loaded).get('__version__') if loaded is not None else None
    return {'installed': installed, 'loaded': str(version) if isinstance(version, str) else None}


def inspect_environment(*, additional_libraries=()):
    """Inventory the current process. Reading a mapped file does not hash loaded code."""
    additional_libraries = frozenset(additional_libraries)
    if any(not isinstance(name, str) or not name or Path(name).name != name for name in additional_libraries):
        raise ValueError('Additional libraries must be basenames')
    libraries, maps_status = _loaded_libraries(additional_libraries)
    abi = getattr(sys.modules.get('torch._C'), '_GLIBCXX_USE_CXX11_ABI', None)
    packages = {name: _package(name, module) for name, module in (
        ('torch', 'torch'), ('torch-npu', 'torch_npu'), ('vllm', 'vllm'), ('vllm-ascend', 'vllm_ascend'),
    )}
    installations = discover_installations()
    soc, soc_source = _live_soc()
    driver_file = _manifest(_ASCEND / 'driver' / 'version.info')
    driver = {'installation': driver_file, 'running_module_versions': {}}
    for module in ('drv_pcie_host', 'drv_devdrv_host'):
        try:
            version = (Path('/sys/module') / module / 'version').read_text().strip()
            driver['running_module_versions'][module] = version
        except OSError:
            pass
    return dict(schema='demoncat.environment.v1', pid=os.getpid(), machine=platform.machine(),
                python=platform.python_version(), packages=packages, toolkit=_toolkit(), driver=driver,
                torch_cxx11_abi=abi if type(abi) is bool else None,
                soc=soc, soc_source=soc_source,
                installed_toolkits=installations,
                loaded_toolkit_links=loaded_installation_links(libraries, installations['installations']),
                maps_status=maps_status, loaded_libraries=libraries,
                has_native_code_attestation=False)


def environment_fingerprint(environment, required_libraries):
    """Fingerprint exactly the named mapped files for a reviewed deployment profile.

    Install records, path spellings and process IDs are diagnostic metadata.
    Callers still need native attestation and live slot/storage proofs.
    """
    if environment is None or environment['maps_status'] != 'OBSERVED':
        return None
    names = sorted(set(required_libraries))
    if not names:
        raise ValueError('A profile must identify required mapped libraries')
    if any(row['status'] != 'MAPPED_FILE_VERIFIED' for row in environment['loaded_libraries']):
        return None
    mapped = {row['name']: (row['sha256'], row['elf_build_id']) for row in environment['loaded_libraries']}
    if not set(names) <= mapped.keys():
        return None
    driver = environment['driver']
    material = dict(machine=environment['machine'], python=environment['python'],
                    packages=environment['packages'], torch_cxx11_abi=environment['torch_cxx11_abi'],
                    libraries={name: mapped[name] for name in names},
                    driver={'running_module_versions': driver['running_module_versions'],
                            'installation_sha256': (driver['installation'] or {}).get('sha256')})
    return hashlib.sha256(json.dumps(material, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


@dataclass(frozen=True)
class NativeSymbolHolder:
    """Trusted deployment holder of a source-reviewed, read-only address getter.

    The getter reads addresses already used by this DSO; it must not resolve a
    replacement symbol. This is not a serializable qualification credential.
    """
    library: object
    getter: object
    getter_name: str
    path: str
    sha256: str
    symbols: tuple
    kind: str = 'CACHED_FUNCTION_POINTER'


def _native_pointer(function):
    import ctypes as C
    if not isinstance(function, C._CFuncPtr):
        raise ValueError('ACTUAL_CTYPES_FUNCTION_HOLDER_REQUIRED')
    return C.cast(function, C.c_void_p).value


def _address_origin(address):
    import ctypes as C
    class Info(C.Structure):
        _fields_ = [('path', C.c_char_p), ('base', C.c_void_p), ('symbol', C.c_char_p), ('symbol_address', C.c_void_p)]
    loader = C.CDLL(None)
    locate = loader.dladdr
    locate.argtypes, locate.restype = [C.c_void_p, C.POINTER(Info)], C.c_int
    value = Info()
    if not address or locate(address, C.byref(value)) == 0 or not value.path or not value.symbol:
        raise ValueError('ACTUAL_BOUND_SYMBOL_ORIGIN_UNAVAILABLE')
    return dict(path=os.fsdecode(value.path), base=value.base, symbol=os.fsdecode(value.symbol),
                symbol_address=value.symbol_address, address=address)


def _binding_image(environment, origin, symbol):
    if (origin['symbol'] != symbol or origin['symbol_address'] != origin['address']
            or not origin['base'] or not origin['base'] <= origin['address']):
        raise ValueError('EXACT_BOUND_SYMBOL_ADDRESS_REQUIRED')
    rows = []
    for row in environment['loaded_libraries']:
        for segment in row['mapping']['executable_segments']:
            start, end = (int(part, 16) for part in segment['address'].split('-'))
            if start <= origin['address'] < end:
                rows.append(row)
    if len(rows) != 1 or rows[0].get('file_identity_status', rows[0]['status']) != 'MAPPED_FILE_VERIFIED':
        raise ValueError('UNIQUE_VERIFIED_EXECUTABLE_SYMBOL_MAPPING_REQUIRED')
    # dladdr may spell a loader symlink while maps names its target. Accept
    # that alias only with the same full device/inode/file stamp, never a hash
    # of a replacement path or an inode-only overlay exception.
    if _file_identity(os.stat(origin['path'])) != rows[0]['path_identity_current']:
        raise ValueError('BOUND_SYMBOL_PATH_DOES_NOT_NAME_MAPPED_FILE')
    return rows[0]


def _read_native_bindings(environment, holders, *, progress=None):
    import ctypes as C
    records = []
    progress = {} if progress is None else progress
    for holder in holders:
        current = dict(holder_path=getattr(holder, 'path', None), getter_name=getattr(holder, 'getter_name', None))
        progress['current_binding'] = current
        if (type(holder) is not NativeSymbolHolder or holder.kind not in
                ('CACHED_FUNCTION_POINTER', 'LINKED_FUNCTION_RELOCATION')
                or not isinstance(holder.symbols, tuple) or not 1 <= len(holder.symbols) <= 64
                or len({slot for slot, _ in holder.symbols}) != len(holder.symbols)
                or getattr(holder.library, holder.getter_name, None) is not holder.getter):
            raise ValueError('REVIEWED_LIVE_NATIVE_SYMBOL_HOLDER_REQUIRED')
        getter = _address_origin(_native_pointer(holder.getter))
        current['getter'] = getter
        image = _binding_image(environment, getter, holder.getter_name)
        getter['mapped_path'] = image['path']
        if image['path'] != holder.path or image['sha256'] != holder.sha256:
            raise ValueError('BOUND_GETTER_MANIFEST_IMAGE_CHANGED')
        holder.getter.argtypes, holder.getter.restype = [C.c_uint32, C.POINTER(C.c_uint64)], C.c_int
        for slot, name in holder.symbols:
            current = dict(holder_path=holder.path, getter_name=holder.getter_name, getter=getter, slot=slot, symbol=name)
            progress['current_binding'] = current
            if type(slot) is not int or not 0 <= slot < 64 or not isinstance(name, str) or not name:
                raise ValueError('BOUNDED_SOURCE_DEFINED_SYMBOL_SLOT_REQUIRED')
            value = C.c_uint64()
            code = holder.getter(slot, C.byref(value))
            current.update(return_code=code, cached_address=value.value)
            if code != 0 or not value.value:
                raise ValueError('NATIVE_CACHED_SYMBOL_UNRESOLVED:'+holder.getter_name+':'+str(slot)+':'+str(code))
            origin = _address_origin(value.value)
            current['target'] = origin
            target = _binding_image(environment, origin, name)
            origin['mapped_path'] = target['path']
            records.append(dict(kind=holder.kind, getter=getter, getter_sha256=image['sha256'],
                slot=slot, symbol=name, target=origin, target_sha256=target['sha256'],
                target_elf_build_id=target['elf_build_id']))
            progress['completed_bindings'] = list(records)
    return records


def inspect_bound_environment(holders, *, required_libraries):
    """Explicit collision profile; the default name-only fingerprint stays strict.

    Every mapped image must have exact file identity, including unselected
    same-name images. A collision additionally needs an actual held getter or
    target in that group. The complete image set and verified function edges
    enter the scope fingerprint. No path-only assertion or JSON is a holder.
    """
    required_libraries = tuple(required_libraries)
    holders = tuple(holders)
    additional = set(required_libraries) | {Path(holder.path).name for holder in holders if type(holder) is NativeSymbolHolder}
    actual = inspect_environment(additional_libraries=additional)
    audit = dict(schema='demoncat.bound_environment.v1', status='REFUSED', bindings=[],
                 collision_groups=[], qualification_granted=False, serializable_authority=False)
    actual['bound_symbol_evidence'] = audit
    progress = dict(read_pass='first')
    try:
        rows = actual['loaded_libraries']
        if (not holders or actual.get('pid') != os.getpid() or actual['maps_status'] != 'OBSERVED'
                or not required_libraries or not set(required_libraries).issubset(row['name'] for row in rows)
                or any(row.get('file_identity_status', row['status']) != 'MAPPED_FILE_VERIFIED' for row in rows)):
            raise ValueError('COMPLETE_VERIFIED_MAPPED_ENVIRONMENT_REQUIRED')
        before = _read_native_bindings(actual, holders, progress=progress)
        audit['bindings'] = before
        bound_paths = {origin['mapped_path'] for row in before for origin in (row['getter'], row['target'])}
        names = sorted({row['name'] for row in rows})
        for name in names:
            group = [row for row in rows if row['name'] == name]
            if len(group) > 1:
                paths = [row['path'] for row in group]
                audit['collision_groups'].append(dict(name=name, complete_paths=paths,
                    actual_bound_paths=sorted(bound_paths.intersection(paths)), all_images_retained=True))
                if not bound_paths.intersection(paths):
                    raise ValueError('DUPLICATE_IMAGE_WITHOUT_ACTUAL_BOUND_SYMBOL:'+name)
        progress = dict(read_pass='second')
        after = _read_native_bindings(actual, holders, progress=progress)
        if before != after:
            raise ValueError('NATIVE_BOUND_SYMBOL_CHANGED_DURING_OBSERVATION')
        inventory = {(row['path'], row['mapping']['device'], row['mapping']['inode'], row['mapping']['deleted']):
            [(segment['address'], segment['file_offset']) for segment in row['mapping']['executable_segments']] for row in rows}
        if _mapped_images(Path('/proc/self/maps').read_text(errors='surrogateescape'), additional) != inventory:
            raise ValueError('EXECUTABLE_MAPPING_SET_CHANGED_DURING_BINDING')
        if any(_file_identity(os.stat(row['path'])) != row['path_identity_current'] for row in rows):
            raise ValueError('BOUND_ENVIRONMENT_PATH_IDENTITY_CHANGED')
        # Paths distinguish same-name objects; ASLR addresses and process IDs
        # remain diagnostics and are not stable scope material.
        images = [dict(path=row['path'], name=row['name'], sha256=row['sha256'], elf_build_id=row['elf_build_id'])
                  for row in sorted(rows, key=lambda row: row['path'])]
        edges = [dict(kind=row['kind'], getter_path=row['getter']['mapped_path'], getter_symbol=row['getter']['symbol'],
            getter_sha256=row['getter_sha256'], slot=row['slot'], symbol=row['symbol'],
            target_path=row['target']['mapped_path'], target_sha256=row['target_sha256']) for row in before]
        material = dict(profile=audit['schema'], machine=actual['machine'], python=actual['python'],
            packages=actual['packages'], torch_cxx11_abi=actual['torch_cxx11_abi'], images=images, bindings=edges,
            driver=dict(running_module_versions=actual['driver']['running_module_versions'],
                installation_sha256=(actual['driver']['installation'] or {}).get('sha256')))
        fingerprint = hashlib.sha256(json.dumps(material, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        audit.update(status='EXACT_MAPPED_FUNCTION_BINDINGS_OBSERVED', scope_material=material, fingerprint=fingerprint)
        return actual, fingerprint
    except (OSError, ValueError, TypeError, AttributeError, KeyError) as error:
        audit['refusal'] = str(error)
        audit['readback_before_failure'] = progress
        return actual, None
