# V4 0.30 只读噪声审查补充

不修改r7.4.1或旧0.32工具，不包含D2注入资格；黄区完整数组尚未回传。
目标为A3、V4-Flash-0731-W8A8、vLLM0.30.0（保留实际+empty后缀）、
vllm-ascend0.30.0、CANN9.2.1、TP8/DP1。EP必须是实际bool并给ep_source。
不能将版本改写为旧0.32或将未知EP填True。

Python3.12；离线审查/提取只需标准库。可信Worker采集另需部署本身的torch/torch_npu，
通过部署已有的鉴权RPC调用，不创建Worker，不暴露任意代码RPC。
本包携带完整冻结fault_injection源码以避免Python常规包遮蔽新增模块，
所有旧文件逐字节来自r7.4.1 Git blob；不复制到现有安装目录，独立解压运行。

```bash
export PYTHONPATH="$PWD:$PWD/tests/worker_extension"
python -m unittest discover -s tests/worker_extension -p 'test_dsv4_noise*.py' -v
python tools/review_dsv4_noise_v030.py /private/calibration.json --output /private/summary.json
python tools/extract_dsv4_v030_record.py noise /private/summary.json
python tools/extract_dsv4_v030_record.py observe /private/observe.json
```

calibration.json是{combination,calibration}，每条prompt两个独立Worker组各至少5次、
每rank四步完整hidden/logits和top5，数组只留黄区。可选phases为normal/fault/off/health，
原文件格式与旧噪声工具一致，仅组合身份和summary schema区分0.30。
全有限、token稳定，两两最大距离×1.5；字节恢复和资源清零不放宽。
提取每段≤4096字节，超长拒绝、不截断；逐段原样粘贴，原件留黄区。
不包含缺失的dispatch/combine动态行映射，不能把只观测摘要当8或13已适配。
完整只读步骤及router两分支陷阱见docs中的交接单。
